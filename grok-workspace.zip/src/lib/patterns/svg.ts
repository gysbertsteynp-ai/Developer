import { bboxOf } from "./geometry.ts";
import type { Piece, Pt, UnitSystem } from "./types.ts";

function n(v: number): string {
  return v.toFixed(4);
}

function esc(value: string): string {
  return value.replace(/[&<>"]/g, (ch) => {
    if (ch === "&") return "&" + "amp;";
    if (ch === "<") return "&" + "lt;";
    if (ch === ">") return "&" + "gt;";
    return "&" + "quot;";
  });
}

function pathOf(pts: Pt[], close: boolean): string {
  if (pts.length === 0) return "";
  const cmds = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${n(p.x)} ${n(-p.y)}`);
  return close ? `${cmds.join(" ")} Z` : cmds.join(" ");
}

/** Full-size SVG, Y-up geometry flipped into SVG space. 1 user unit = 1 mm or 1 inch. */
export function buildSvg(options: {
  pieces: Piece[];
  unit: UnitSystem;
  title: string;
  includeFolds: boolean;
}): string {
  const pts: Pt[] = [];
  for (const piece of options.pieces) {
    pts.push(...piece.outline);
    if (options.includeFolds) {
      for (const [a, b] of piece.folds ?? []) pts.push(a, b);
    }
  }
  const box = pts.length ? bboxOf(pts.map((p) => ({ x: p.x, y: -p.y }))) : { minX: 0, minY: 0, maxX: 1, maxY: 1 };
  const span = Math.max(box.maxX - box.minX, box.maxY - box.minY, 1);
  const pad = span * 0.06;
  const minX = box.minX - pad;
  const minY = box.minY - pad;
  const width = box.maxX - box.minX + pad * 2;
  const height = box.maxY - box.minY + pad * 2;
  const font = span * 0.032;
  const cuts = options.pieces.map((piece) => pathOf(piece.outline, true)).filter(Boolean);
  const folds = options.includeFolds
    ? options.pieces.flatMap((piece) => (piece.folds ?? []).map(([a, b]) => pathOf([a, b], false)))
    : [];

  const labels = options.pieces
    .filter((piece) => piece.label)
    .map((piece) => {
      const b = bboxOf(piece.outline);
      const x = (b.minX + b.maxX) / 2;
      const y = -((b.minY + b.maxY) / 2);
      return `<text x="${n(x)}" y="${n(y)}" text-anchor="middle" dominant-baseline="middle" font-family="sans-serif" font-size="${n(font)}" fill="#1c1a16">${esc(piece.label ?? "")}</text>`;
    });

  return [
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${n(minX)} ${n(minY)} ${n(width)} ${n(height)}" fill="none">`,
    `<title>${esc(options.title)}</title>`,
    `<desc>Full size. 1 user unit = 1 ${options.unit}. Solid paths are the cut. Dashed paths are layout lines.</desc>`,
    `<g stroke="#1a1a1a" stroke-width="1.5" stroke-linejoin="round" vector-effect="non-scaling-stroke">`,
    ...cuts.map((d) => `<path d="${d}"/>`),
    `</g>`,
    folds.length
      ? `<g stroke="#2c4c7c" stroke-width="1" stroke-dasharray="5 4" vector-effect="non-scaling-stroke">${folds.map((d) => `<path d="${d}"/>`).join("")}</g>`
      : "",
    ...labels,
    `</svg>`,
    ``,
  ].join("\n");
}
