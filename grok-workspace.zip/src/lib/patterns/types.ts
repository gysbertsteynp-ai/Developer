export type UnitSystem = "mm" | "in";
export type Basis = "outside" | "inside";

export type Shop = {
  unit: UnitSystem;
  /** Neutral-axis fraction measured from the inside face. 0.5 is mid-thickness. */
  k: number;
  density: number;
  material: string;
};

export type Pt = { x: number; y: number };

export type Sector = {
  cx: number;
  cy: number;
  innerR: number;
  outerR: number;
  /** Mathematical degrees, 0 at +X, CCW, Y-up. */
  startDeg: number;
  sweepDeg: number;
};

export type Piece = {
  outline: Pt[];
  folds?: [Pt, Pt][];
  sector?: Sector;
  label?: string;
};

export type Guide = {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  label: string;
  /** Label anchor in Y-up space. */
  lx: number;
  ly: number;
  /** Read the label along the dimension. Vertical dims rotate so they don’t cross the witness line. */
  along?: "x" | "y";
};

export type Stat = {
  label: string;
  value: string;
  hero?: boolean;
};

export type TrueLength = { label: string; value: string };

export type ExportGroup = { piece: Piece; count: number };

export type Pattern = {
  stats: Stat[];
  display: Piece[];
  guides: Guide[];
  exportGroups: ExportGroup[];
  notes: string[];
  trueLengths?: TrueLength[];
};

export type PatternResult = { ok: true; pattern: Pattern } | { ok: false; error: string };
