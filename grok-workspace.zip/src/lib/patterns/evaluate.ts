import { calcAuger } from "./auger.ts";
import { calcCone } from "./cone.ts";
import { calcCylinder } from "./cylinder.ts";
import { calcElbow, type SeamPlace } from "./elbow.ts";
import { materialById, type MaterialId } from "./format.ts";
import { bboxOf } from "./geometry.ts";
import { smallestPlate } from "./stock.ts";
import { calcTransition, type TransitionPart } from "./transition.ts";
import type { Basis, PatternResult, Shop, UnitSystem } from "./types.ts";

export type TabId = "cylinder" | "cone" | "auger" | "transition" | "elbow";

export type CylinderFields = {
  diameter: string;
  length: string;
  thickness: string;
  allowance: string;
  basis: Basis;
  plateWidth: string;
};

export type ConeFields = {
  large: string;
  small: string;
  height: string;
  thickness: string;
  allowance: string;
  pieces: string;
  basis: Basis;
};

export type AugerFields = {
  od: string;
  id: string;
  pitch: string;
  thickness: string;
  flights: string;
};

export type TransitionFields = {
  length: string;
  width: string;
  round: string;
  height: string;
  thickness: string;
  basis: Basis;
  segments: string;
  part: TransitionPart;
  folds: boolean;
};

export type ElbowFields = {
  diameter: string;
  clr: string;
  angle: string;
  gores: string;
  thickness: string;
  allowance: string;
  basis: Basis;
  seam: SeamPlace;
};

export type ShopState = {
  unit: UnitSystem;
  material: MaterialId;
  kFactor: string;
  /** Shop mark stamped on the ticket and the DXF comment. */
  mark: string;
  tab: TabId;
  cylinder: CylinderFields;
  cone: ConeFields;
  auger: AugerFields;
  transition: TransitionFields;
  elbow: ElbowFields;
};

export const DEFAULT_STATE: ShopState = {
  unit: "mm",
  material: "mild",
  kFactor: "0.5",
  mark: "",
  tab: "cylinder",
  cylinder: {
    diameter: "500",
    length: "800",
    thickness: "5",
    allowance: "0",
    basis: "outside",
    plateWidth: "",
  },
  cone: {
    large: "600",
    small: "250",
    height: "450",
    thickness: "5",
    allowance: "0",
    pieces: "1",
    basis: "inside",
  },
  auger: {
    od: "400",
    id: "100",
    pitch: "300",
    thickness: "5",
    flights: "1",
  },
  transition: {
    length: "800",
    width: "500",
    round: "300",
    height: "400",
    thickness: "5",
    basis: "inside",
    segments: "12",
    part: "half",
    folds: false,
  },
  elbow: {
    diameter: "500",
    clr: "750",
    angle: "90",
    gores: "5",
    thickness: "6",
    allowance: "0",
    basis: "outside",
    seam: "throat",
  },
};

const LINEAR: { tab: TabId; key: string }[] = [
  { tab: "cylinder", key: "diameter" },
  { tab: "cylinder", key: "length" },
  { tab: "cylinder", key: "thickness" },
  { tab: "cylinder", key: "allowance" },
  { tab: "cylinder", key: "plateWidth" },
  { tab: "cone", key: "large" },
  { tab: "cone", key: "small" },
  { tab: "cone", key: "height" },
  { tab: "cone", key: "thickness" },
  { tab: "cone", key: "allowance" },
  { tab: "auger", key: "od" },
  { tab: "auger", key: "id" },
  { tab: "auger", key: "pitch" },
  { tab: "auger", key: "thickness" },
  { tab: "transition", key: "length" },
  { tab: "transition", key: "width" },
  { tab: "transition", key: "round" },
  { tab: "transition", key: "height" },
  { tab: "transition", key: "thickness" },
  { tab: "elbow", key: "diameter" },
  { tab: "elbow", key: "clr" },
  { tab: "elbow", key: "thickness" },
  { tab: "elbow", key: "allowance" },
];

export function readNumber(value: string): number | null {
  const trimmed = value.trim();
  if (trimmed === "") return null;
  const n = Number(trimmed);
  return Number.isFinite(n) ? n : null;
}

export function convertUnits(state: ShopState, to: UnitSystem): ShopState {
  if (state.unit === to) return state;
  const factor = state.unit === "mm" ? 1 / 25.4 : 25.4;
  const digits = to === "mm" ? 2 : 3;
  const next = structuredClone(state);
  next.unit = to;
  for (const field of LINEAR) {
    const group = next[field.tab] as Record<string, string | boolean>;
    const raw = group[field.key];
    if (typeof raw !== "string") continue;
    const n = readNumber(raw);
    if (n === null) continue;
    group[field.key] = String(Number((n * factor).toFixed(digits)));
  }
  return next;
}

function req(value: string, label: string): number | string {
  const n = readNumber(value);
  if (n === null) return `${label} needs a number.`;
  return n;
}

function shopOf(state: ShopState): Shop | string {
  const k = readNumber(state.kFactor);
  if (k === null) return "K-factor needs a number.";
  const mat = materialById(state.material);
  return { unit: state.unit, k, density: mat.density, material: mat.name };
}

export function evaluate(state: ShopState): PatternResult {
  const shop = shopOf(state);
  if (typeof shop === "string") return { ok: false, error: shop };
  return withPlate(evaluateTab(state, shop), shop.unit);
}

function withPlate(result: PatternResult, unit: UnitSystem): PatternResult {
  if (!result.ok) return result;
  const sizes = result.pattern.exportGroups.map((group) => {
    const box = bboxOf(group.piece.outline);
    return { w: box.maxX - box.minX, h: box.maxY - box.minY };
  });
  const plate = smallestPlate(sizes, unit);
  return {
    ok: true,
    pattern: {
      ...result.pattern,
      stats: [...result.pattern.stats, { label: "Common plate", value: plate.label }],
      notes: [...result.pattern.notes, plate.note],
    },
  };
}

function evaluateTab(state: ShopState, shop: Shop): PatternResult {

  if (state.tab === "cylinder") {
    const f = state.cylinder;
    const diameter = req(f.diameter, "Diameter");
    const length = req(f.length, "Length");
    const thickness = req(f.thickness, "Thickness");
    const allowance = req(f.allowance, "Seam allowance");
    const plate = f.plateWidth.trim() === "" ? 0 : readNumber(f.plateWidth);
    if (typeof diameter === "string") return { ok: false, error: diameter };
    if (typeof length === "string") return { ok: false, error: length };
    if (typeof thickness === "string") return { ok: false, error: thickness };
    if (typeof allowance === "string") return { ok: false, error: allowance };
    if (plate === null) return { ok: false, error: "Max course length needs a number, or leave it blank." };
    return calcCylinder(
      { diameter, length, thickness, allowance, basis: f.basis, plateWidth: plate },
      shop,
    );
  }

  if (state.tab === "cone") {
    const f = state.cone;
    const large = req(f.large, "Large end");
    const small = req(f.small, "Small end");
    const height = req(f.height, "Height");
    const thickness = req(f.thickness, "Thickness");
    const allowance = req(f.allowance, "Seam allowance");
    const pieces = req(f.pieces, "Pieces");
    if (typeof large === "string") return { ok: false, error: large };
    if (typeof small === "string") return { ok: false, error: small };
    if (typeof height === "string") return { ok: false, error: height };
    if (typeof thickness === "string") return { ok: false, error: thickness };
    if (typeof allowance === "string") return { ok: false, error: allowance };
    if (typeof pieces === "string") return { ok: false, error: pieces };
    return calcCone(
      { large, small, height, thickness, allowance, pieces, basis: f.basis },
      shop,
    );
  }

  if (state.tab === "auger") {
    const f = state.auger;
    const od = req(f.od, "Outside diameter");
    const id = req(f.id, "Shaft hole");
    const pitch = req(f.pitch, "Pitch");
    const thickness = req(f.thickness, "Thickness");
    const flights = req(f.flights, "Flights");
    if (typeof od === "string") return { ok: false, error: od };
    if (typeof id === "string") return { ok: false, error: id };
    if (typeof pitch === "string") return { ok: false, error: pitch };
    if (typeof thickness === "string") return { ok: false, error: thickness };
    if (typeof flights === "string") return { ok: false, error: flights };
    return calcAuger({ od, id, pitch, thickness, flights }, shop);
  }

  if (state.tab === "transition") {
    const f = state.transition;
    const length = req(f.length, "Base length");
    const width = req(f.width, "Base width");
    const round = req(f.round, "Round");
    const height = req(f.height, "Height");
    const thickness = req(f.thickness, "Thickness");
    const segments = req(f.segments, "Arc steps");
    if (typeof length === "string") return { ok: false, error: length };
    if (typeof width === "string") return { ok: false, error: width };
    if (typeof round === "string") return { ok: false, error: round };
    if (typeof height === "string") return { ok: false, error: height };
    if (typeof thickness === "string") return { ok: false, error: thickness };
    if (typeof segments === "string") return { ok: false, error: segments };
    return calcTransition(
      { length, width, round, height, thickness, basis: f.basis, segments, part: f.part },
      shop,
    );
  }

  const f = state.elbow;
  const diameter = req(f.diameter, "Diameter");
  const clr = req(f.clr, "Centerline radius");
  const angle = req(f.angle, "Bend angle");
  const gores = req(f.gores, "Gores");
  const thickness = req(f.thickness, "Thickness");
  const allowance = req(f.allowance, "Seam allowance");
  if (typeof diameter === "string") return { ok: false, error: diameter };
  if (typeof clr === "string") return { ok: false, error: clr };
  if (typeof angle === "string") return { ok: false, error: angle };
  if (typeof gores === "string") return { ok: false, error: gores };
  if (typeof thickness === "string") return { ok: false, error: thickness };
  if (typeof allowance === "string") return { ok: false, error: allowance };
  return calcElbow(
    { diameter, clr, angle, gores, thickness, allowance, basis: f.basis, seam: f.seam },
    shop,
  );
}

export function mergeSaved(raw: unknown): ShopState {
  if (!raw || typeof raw !== "object") return DEFAULT_STATE;
  const saved = raw as Partial<ShopState>;
  const savedT = (saved.transition ?? {}) as Partial<TransitionFields> & { square?: string };
  const legacySide = typeof savedT.square === "string" ? savedT.square : undefined;
  const transition: TransitionFields = {
    ...DEFAULT_STATE.transition,
    ...savedT,
    length: typeof savedT.length === "string" ? savedT.length : (legacySide ?? DEFAULT_STATE.transition.length),
    width: typeof savedT.width === "string" ? savedT.width : (legacySide ?? DEFAULT_STATE.transition.width),
  };
  delete (transition as { square?: string }).square;
  const next: ShopState = {
    ...DEFAULT_STATE,
    ...saved,
    mark: typeof saved.mark === "string" ? saved.mark.slice(0, 40) : "",
    cylinder: { ...DEFAULT_STATE.cylinder, ...(saved.cylinder ?? {}) },
    cone: { ...DEFAULT_STATE.cone, ...(saved.cone ?? {}) },
    auger: { ...DEFAULT_STATE.auger, ...(saved.auger ?? {}) },
    transition,
    elbow: { ...DEFAULT_STATE.elbow, ...(saved.elbow ?? {}) },
  };
  if (next.unit !== "mm" && next.unit !== "in") next.unit = "mm";
  if (next.material !== "mild" && next.material !== "ss" && next.material !== "alu") next.material = "mild";
  if (!["cylinder", "cone", "auger", "transition", "elbow"].includes(next.tab)) next.tab = "cylinder";
  for (const group of [next.cylinder, next.cone, next.transition, next.elbow]) {
    if (group.basis !== "outside" && group.basis !== "inside") group.basis = "outside";
  }
  if (!["quarter", "half", "half-cross", "full"].includes(next.transition.part)) next.transition.part = "half";
  if (!["throat", "cheek", "back"].includes(next.elbow.seam)) next.elbow.seam = "throat";
  if (typeof next.transition.folds !== "boolean") next.transition.folds = false;
  return next;
}
