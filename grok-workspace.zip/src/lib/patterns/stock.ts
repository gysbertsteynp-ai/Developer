import { fmt } from "./format.ts";
import type { UnitSystem } from "./types.ts";

export type BoxSize = { w: number; h: number };

type Plate = { w: number; h: number; name: string };

const PLATES_MM: Plate[] = [
  { w: 1000, h: 2000, name: "1000 × 2000 mm" },
  { w: 1250, h: 2500, name: "1250 × 2500 mm" },
  { w: 1500, h: 3000, name: "1500 × 3000 mm" },
  { w: 1500, h: 6000, name: "1500 × 6000 mm" },
  { w: 2000, h: 6000, name: "2000 × 6000 mm" },
  { w: 2500, h: 6000, name: "2500 × 6000 mm" },
  { w: 3000, h: 12000, name: "3000 × 12000 mm" },
];

const PLATES_IN: Plate[] = [
  { w: 48, h: 96, name: "4×8 (48 × 96 in)" },
  { w: 48, h: 120, name: "4×10 (48 × 120 in)" },
  { w: 60, h: 120, name: "5×10 (60 × 120 in)" },
  { w: 72, h: 144, name: "6×12 (72 × 144 in)" },
  { w: 96, h: 240, name: "8×20 (96 × 240 in)" },
  { w: 96, h: 480, name: "8×40 (96 × 480 in)" },
];

type Way = "as drawn" | "turned 90°" | "either way";

function wayOf(piece: BoxSize, plate: Plate): Way | null {
  const tol = 0.05;
  const upright = piece.w <= plate.w + tol && piece.h <= plate.h + tol;
  const turned = piece.w <= plate.h + tol && piece.h <= plate.w + tol;
  if (upright && turned) return "either way";
  if (upright) return "as drawn";
  if (turned) return "turned 90°";
  return null;
}

/**
 * Smallest common plate that can hold every piece, each one rotated on its own.
 */
export function smallestPlate(sizes: BoxSize[], unit: UnitSystem): { label: string; note: string } {
  const plates = unit === "mm" ? PLATES_MM : PLATES_IN;
  const usable = sizes.filter((size) => size.w > 0 && size.h > 0);
  if (usable.length === 0) return { label: "—", note: "No piece to fit on a plate." };

  let best: { plate: Plate; ways: Way[] } | null = null;
  for (const plate of plates) {
    const ways = usable.map((size) => wayOf(size, plate));
    if (ways.some((way) => way === null)) continue;
    if (!best || plate.w * plate.h < best.plate.w * best.plate.h) {
      best = { plate, ways: ways as Way[] };
    }
  }

  const largest = usable.reduce((a, b) => (a.w * a.h >= b.w * b.h ? a : b));
  const sizeText = `${fmt(largest.w, unit)} × ${fmt(largest.h, unit)}`;
  if (!best) {
    return {
      label: "Special",
      note: `Largest piece is ${sizeText}. That is past common stock — plan a splice or a special plate.`,
    };
  }

  const unique = new Set(best.ways);
  const how = unique.size === 1 ? [...unique][0] : "turned as needed";
  const pieceWord = usable.length > 1 ? "Each piece fits" : "It fits";
  return {
    label: best.plate.name,
    note: `Largest piece is ${sizeText}. ${pieceWord} a ${best.plate.name} sheet, ${how}.`,
  };
}
