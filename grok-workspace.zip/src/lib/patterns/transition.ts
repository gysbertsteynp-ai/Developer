import { bboxOf, selfIntersects, shoelace } from "./geometry.ts";
import { fmt, fmtArea, fmtMass, massKg, neutralDiameter } from "./format.ts";
import type { Basis, PatternResult, Pt, Shop } from "./types.ts";

export type TransitionPart = "quarter" | "half" | "half-cross" | "full";

export type TransitionInput = {
  length: number;
  width: number;
  round: number;
  height: number;
  thickness: number;
  basis: Basis;
  segments: number;
  part: TransitionPart;
};

type Built = {
  outline: Pt[];
  folds: [Pt, Pt][];
  trueLengths: { label: string; length: number }[];
  /** Side-center seam of the side the pattern starts on. */
  seam: number;
  /** True length from a corner to the circle point on that starting side. */
  corner: number;
  seamCross: number;
  cornerCross: number;
};

function intersect(p1: Pt, r1: number, p2: Pt, r2: number, side: 1 | -1): Pt {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const d = Math.hypot(dx, dy);
  if (d < 1e-8 || d > r1 + r2 + 1e-2 || d < Math.abs(r1 - r2) - 1e-2) {
    throw new Error("close");
  }
  const a = (r1 * r1 - r2 * r2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, r1 * r1 - a * a));
  const x3 = p1.x + (a * dx) / d;
  const y3 = p1.y + (a * dy) / d;
  return { x: x3 + (side * dy * h) / d, y: y3 - (side * dx * h) / d };
}

/**
 * Concentric rectangle-to-round by triangulation.
 * `startSide` is the full length of the side whose center the blank starts on.
 * `crossSide` is the full length of the adjacent side. Equal sides are a square.
 * Built in a Y-down construction space, then flipped to Y-up for CAD.
 * `quarters` is 1, 2, or 4 — seams fall on side centerlines.
 */
export function developRectTransition(
  startSide: number,
  crossSide: number,
  diameter: number,
  height: number,
  segments: number,
  quarters: 1 | 2 | 4,
): Built {
  const A = startSide / 2;
  const B = crossSide / 2;
  const r = diameter / 2;
  const h = height;
  const seam = Math.hypot(B - r, h);
  const seamCross = Math.hypot(A - r, h);
  const corner = Math.hypot(A, B - r, h);
  const cornerCross = Math.hypot(B, A - r, h);
  const step = (Math.PI * r) / 2 / segments;

  const defs = [
    {
      tl: (theta: number) => Math.hypot(A - r * Math.sin(theta), B - r * Math.cos(theta), h),
      endSeam: seamCross,
      endCorner: cornerCross,
      nextFull: crossSide,
      endHalf: B,
    },
    {
      tl: (theta: number) => Math.hypot(A - r * Math.cos(theta), -B + r * Math.sin(theta), h),
      endSeam: seam,
      endCorner: corner,
      nextFull: startSide,
      endHalf: A,
    },
    {
      tl: (theta: number) => Math.hypot(-A + r * Math.sin(theta), -B + r * Math.cos(theta), h),
      endSeam: seamCross,
      endCorner: cornerCross,
      nextFull: crossSide,
      endHalf: B,
    },
    {
      tl: (theta: number) => Math.hypot(-A + r * Math.cos(theta), B - r * Math.sin(theta), h),
      endSeam: seam,
      endCorner: corner,
      nextFull: startSide,
      endHalf: A,
    },
  ];

  const tops: Pt[] = [{ x: 0, y: 0 }];
  const bots: Pt[] = [
    { x: 0, y: seam },
    { x: A, y: seam },
  ];
  const folds: [Pt, Pt][] = [
    [tops[0], bots[0]],
    [tops[0], bots[1]],
  ];
  const elementLengths: { label: string; length: number }[] = [
    { label: "Starting side-center seam", length: seam },
    { label: "Half of the starting side", length: A },
    { label: "Corner to the starting side-center", length: corner },
    { label: "Adjacent side-center seam", length: seamCross },
    { label: "Corner to the adjacent side-center", length: cornerCross },
  ];

  let apex = bots[1];
  for (let q = 0; q < quarters; q++) {
    const def = defs[q];
    for (let i = 1; i <= segments; i++) {
      const theta = (i / segments) * (Math.PI / 2);
      const length = def.tl(theta);
      const prev = tops[tops.length - 1];
      const next = intersect(prev, step, apex, length, 1);
      tops.push(next);
      folds.push([next, apex]);
      if (q === 0 || (q === 1 && Math.abs(corner - cornerCross) > 0.05)) {
        elementLengths.push({
          label: `${q === 0 ? "First" : "Second"} corner, arc step ${i} of ${segments}`,
          length,
        });
      }
    }
    const endTop = tops[tops.length - 1];
    const last = q === quarters - 1;
    if (last) {
      const endBase = intersect(bots[bots.length - 1], def.endHalf, endTop, def.endSeam, -1);
      bots.push(endBase);
      folds.push([endTop, endBase]);
    } else {
      const nextCorner = intersect(apex, def.nextFull, endTop, def.endCorner, -1);
      bots.push(nextCorner);
      folds.push([endTop, nextCorner]);
      const mid = {
        x: (apex.x + nextCorner.x) / 2,
        y: (apex.y + nextCorner.y) / 2,
      };
      folds.push([endTop, mid]);
      apex = nextCorner;
    }
  }

  const outlineDown: Pt[] = [...tops, ...[...bots].reverse()];
  const flip = (p: Pt): Pt => ({ x: p.x, y: -p.y });
  const outline = outlineDown.map(flip);
  const foldsUp = folds.map(([a, b]) => [flip(a), flip(b)] as [Pt, Pt]);

  const cleaned: Pt[] = [];
  for (const p of outline) {
    const last = cleaned[cleaned.length - 1];
    if (!last || Math.hypot(last.x - p.x, last.y - p.y) > 1e-6) cleaned.push(p);
  }

  if (selfIntersects(cleaned)) throw new Error("cross");

  for (let i = 1; i < tops.length; i++) {
    const d = Math.hypot(tops[i].x - tops[i - 1].x, tops[i].y - tops[i - 1].y);
    if (Math.abs(d - step) > Math.max(0.05, step * 0.01)) throw new Error("chord");
  }

  return {
    outline: cleaned,
    folds: foldsUp,
    trueLengths: elementLengths,
    seam,
    corner,
    seamCross,
    cornerCross,
  };
}

/** Square-to-round. Kept so older call sites stay valid. */
export function developTransition(
  side: number,
  diameter: number,
  height: number,
  segments: number,
  quarters: 1 | 2 | 4,
): Built {
  return developRectTransition(side, side, diameter, height, segments, quarters);
}

function partQuarters(part: TransitionPart): 1 | 2 | 4 {
  if (part === "quarter") return 1;
  if (part === "full") return 4;
  return 2;
}

export function calcTransition(input: TransitionInput, shop: Shop): PatternResult {
  const { length, width, round, height, thickness, basis, segments, part } = input;
  if (!(length > 0) || !(width > 0) || !(round > 0) || !(height > 0)) {
    return { ok: false, error: "Length, width, round, and height all have to be greater than zero." };
  }
  if (thickness < 0) return { ok: false, error: "Thickness can’t be negative." };
  if (![6, 8, 12, 16, 24].includes(segments)) {
    return { ok: false, error: "Use 6, 8, 12, 16, or 24 arc steps per quarter." };
  }
  if (shop.k < 0.2 || shop.k > 0.5) return { ok: false, error: "K-factor needs to sit between 0.20 and 0.50." };

  const sideL = neutralDiameter(length, thickness, shop.k, basis);
  const sideW = neutralDiameter(width, thickness, shop.k, basis);
  const diameter = neutralDiameter(round, thickness, shop.k, basis);
  if (!(sideL > 0) || !(sideW > 0) || !(diameter > 0)) {
    return { ok: false, error: "Thickness wipes out a neutral size. Check inside versus outside." };
  }

  const rectangular = Math.abs(sideL - sideW) > Math.max(sideL, sideW) * 1e-4;
  if (rectangular && part === "quarter") {
    return {
      ok: false,
      error: "A rectangle doesn’t repeat as four identical quarters. Use a half, or cut it as one piece.",
    };
  }

  const onWidth = part === "half-cross";
  const startSide = onWidth ? sideW : sideL;
  const crossSide = onWidth ? sideL : sideW;
  const quarters = partQuarters(part);
  let built: Built;
  try {
    built = developRectTransition(startSide, crossSide, diameter, height, segments, quarters);
  } catch {
    return {
      ok: false,
      error: "These sizes won’t triangulate cleanly. Add height, or bring the round and the base closer in plan.",
    };
  }

  const lengthSeam = onWidth ? built.seamCross : built.seam;
  const widthSeam = onWidth ? built.seam : built.seamCross;
  const lengthCorner = onWidth ? built.cornerCross : built.corner;
  const widthCorner = onWidth ? built.corner : built.cornerCross;

  const box = bboxOf(built.outline);
  const patW = box.maxX - box.minX;
  const patH = box.maxY - box.minY;
  const pieceArea = shoelace(built.outline);
  const copies = 4 / quarters;
  const fullArea = pieceArea * copies;
  const pieceKg = massKg(pieceArea, thickness, shop.unit, shop.density);
  const fullKg = massKg(fullArea, thickness, shop.unit, shop.density);
  const partLabel =
    part === "quarter"
      ? "Quarter"
      : part === "full"
        ? "Full"
        : onWidth
          ? "Half, seam on widths"
          : rectangular
            ? "Half, seam on lengths"
            : "Half";
  const sheetLabel =
    part === "quarter"
      ? "Quarter pattern"
      : part === "full"
        ? "Full pattern"
        : onWidth
          ? "Width-seam half"
          : rectangular
            ? "Length-seam half"
            : "Half pattern";
  const m = Math.max(patW, patH) * 0.06;
  const squareLike = !rectangular;

  const heroes: { label: string; value: string; hero: true }[] = [
    { label: "Piece width", value: fmt(patW, shop.unit), hero: true },
    { label: "Piece height", value: fmt(patH, shop.unit), hero: true },
  ];
  if (squareLike) {
    heroes.push(
      { label: "Side-center length", value: fmt(built.seam, shop.unit), hero: true },
      { label: "Corner length", value: fmt(built.corner, shop.unit), hero: true },
    );
  } else {
    heroes.push(
      { label: "Seam on lengths", value: fmt(lengthSeam, shop.unit), hero: true },
      { label: "Seam on widths", value: fmt(widthSeam, shop.unit), hero: true },
    );
  }

  return {
    ok: true,
    pattern: {
      stats: [
        ...heroes,
        { label: "Neutral base", value: `${fmt(sideL, shop.unit)} × ${fmt(sideW, shop.unit)}` },
        { label: "Neutral round Ø", value: fmt(diameter, shop.unit) },
        ...(squareLike
          ? []
          : [
              { label: "To length-side center", value: fmt(lengthCorner, shop.unit) },
              { label: "To width-side center", value: fmt(widthCorner, shop.unit) },
            ]),
        { label: "Pattern", value: `${partLabel} · cut ${copies}` },
        { label: "This piece", value: fmtArea(pieceArea, shop.unit) },
        { label: "Full fitting", value: fmtArea(fullArea, shop.unit) },
        { label: `This piece · ${shop.material}`, value: fmtMass(pieceKg, shop.unit) },
        { label: "Full fitting weight", value: fmtMass(fullKg, shop.unit) },
      ],
      display: [
        {
          outline: built.outline,
          folds: built.folds,
          label: sheetLabel,
        },
      ],
      guides: [
        {
          x1: box.minX,
          y1: box.minY - m,
          x2: box.maxX,
          y2: box.minY - m,
          label: `Width ${fmt(patW, shop.unit)}`,
          lx: (box.minX + box.maxX) / 2,
          ly: box.minY - m * 1.8,
        },
        {
          x1: box.minX - m,
          y1: box.minY,
          x2: box.minX - m,
          y2: box.maxY,
          label: `Height ${fmt(patH, shop.unit)}`,
          lx: box.minX - m * 1.7,
          ly: (box.minY + box.maxY) / 2,
          along: "y",
        },
      ],
      exportGroups: [{ piece: { outline: built.outline, folds: built.folds }, count: 1 }],
      trueLengths: built.trueLengths.map((row) => ({
        label: row.label,
        value: fmt(row.length, shop.unit),
      })),
      notes: [
        rectangular
          ? `Concentric rectangle-to-round on the neutral surface (${basis}, k = ${shop.k.toFixed(2)}).`
          : `Concentric square-to-round on the neutral surface (${basis}, k = ${shop.k.toFixed(2)}).`,
        "Dashed lines are triangulation layout lines. They are not a cut unless you turn on layer FOLD in the DXF.",
        copies > 1
          ? `Cut ${copies} of this piece to close the fitting. The DXF is one piece — step it off again rather than stretching it.`
          : "This piece is the whole fitting, seamed on a side center.",
        rectangular && part === "half"
          ? "This half is seamed on the center of the length sides and includes one full width side."
          : rectangular && part === "half-cross"
            ? "This half is seamed on the center of the width sides and includes one full length side."
            : "Seams fall on side centers, not on the corners.",
        `Round edge uses ${segments} equal steps per quarter. More steps, smoother curve, same corner length.`,
        "Net blank only — no kerf, no corner notch.",
      ],
    },
  };
}
