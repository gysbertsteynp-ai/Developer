import { tileGroups } from "./geometry.ts";
import type { ExportGroup, Piece, Pt, UnitSystem } from "./types.ts";

function norm360(deg: number): number {
  const x = deg % 360;
  return x < 0 ? x + 360 : x;
}

function n(v: number): string {
  return v.toFixed(4);
}

function line(layer: string, a: Pt, b: Pt, out: string[]) {
  out.push(
    "0",
    "LINE",
    "8",
    layer,
    "10",
    n(a.x),
    "20",
    n(a.y),
    "30",
    "0",
    "11",
    n(b.x),
    "21",
    n(b.y),
    "31",
    "0",
  );
}

function arc(layer: string, cx: number, cy: number, r: number, startDeg: number, sweepDeg: number, out: string[]) {
  if (r < 1e-6 || sweepDeg <= 0) return;
  const start = norm360(startDeg);
  const end = norm360(startDeg + sweepDeg);
  out.push(
    "0",
    "ARC",
    "8",
    layer,
    "10",
    n(cx),
    "20",
    n(cy),
    "30",
    "0",
    "40",
    n(r),
    "50",
    n(start),
    "51",
    n(end),
  );
}

function polyline(layer: string, pts: Pt[], out: string[]) {
  if (pts.length < 2) return;
  out.push("0", "POLYLINE", "8", layer, "66", "1", "70", "1", "10", "0", "20", "0", "30", "0");
  for (const p of pts) {
    out.push("0", "VERTEX", "8", layer, "10", n(p.x), "20", n(p.y), "30", "0");
  }
  out.push("0", "SEQEND", "8", layer);
}

function emitPiece(piece: Piece, includeFolds: boolean, out: string[]) {
  if (piece.sector && piece.sector.sweepDeg > 0 && piece.sector.sweepDeg < 360) {
    const s = piece.sector;
    arc("CUT", s.cx, s.cy, s.outerR, s.startDeg, s.sweepDeg, out);
    const start = (s.startDeg * Math.PI) / 180;
    const end = ((s.startDeg + s.sweepDeg) * Math.PI) / 180;
    const outerA = { x: s.cx + s.outerR * Math.cos(start), y: s.cy + s.outerR * Math.sin(start) };
    const outerB = { x: s.cx + s.outerR * Math.cos(end), y: s.cy + s.outerR * Math.sin(end) };
    if (s.innerR < 1e-6) {
      const c = { x: s.cx, y: s.cy };
      line("CUT", outerA, c, out);
      line("CUT", c, outerB, out);
    } else {
      arc("CUT", s.cx, s.cy, s.innerR, s.startDeg, s.sweepDeg, out);
      const innerA = { x: s.cx + s.innerR * Math.cos(start), y: s.cy + s.innerR * Math.sin(start) };
      const innerB = { x: s.cx + s.innerR * Math.cos(end), y: s.cy + s.innerR * Math.sin(end) };
      line("CUT", innerA, outerA, out);
      line("CUT", innerB, outerB, out);
    }
  } else {
    polyline("CUT", piece.outline, out);
  }
  if (includeFolds && piece.folds) {
    for (const [a, b] of piece.folds) line("FOLD", a, b, out);
  }
}

export function buildDxf(options: {
  groups: ExportGroup[];
  unit: UnitSystem;
  comment: string;
  includeFolds: boolean;
  gap: number;
}): string {
  const pieces = tileGroups(options.groups, options.gap);
  const units = options.unit === "mm" ? 4 : 1;
  const measurement = options.unit === "mm" ? 1 : 0;
  const out: string[] = [
    "999",
    options.comment,
    "0",
    "SECTION",
    "2",
    "HEADER",
    "9",
    "$ACADVER",
    "1",
    "AC1009",
    "9",
    "$INSUNITS",
    "70",
    String(units),
    "9",
    "$MEASUREMENT",
    "70",
    String(measurement),
    "0",
    "ENDSEC",
    "0",
    "SECTION",
    "2",
    "TABLES",
    "0",
    "TABLE",
    "2",
    "LTYPE",
    "70",
    "1",
    "0",
    "LTYPE",
    "2",
    "CONTINUOUS",
    "70",
    "0",
    "3",
    "Solid line",
    "72",
    "65",
    "73",
    "0",
    "40",
    "0.0",
    "0",
    "ENDTAB",
    "0",
    "TABLE",
    "2",
    "LAYER",
    "70",
    "3",
    "0",
    "LAYER",
    "2",
    "0",
    "70",
    "0",
    "62",
    "7",
    "6",
    "CONTINUOUS",
    "0",
    "LAYER",
    "2",
    "CUT",
    "70",
    "0",
    "62",
    "1",
    "6",
    "CONTINUOUS",
    "0",
    "LAYER",
    "2",
    "FOLD",
    "70",
    "0",
    "62",
    "5",
    "6",
    "CONTINUOUS",
    "0",
    "ENDTAB",
    "0",
    "ENDSEC",
    "0",
    "SECTION",
    "2",
    "ENTITIES",
  ];

  for (const piece of pieces) emitPiece(piece, options.includeFolds, out);

  out.push("0", "ENDSEC", "0", "EOF");
  return out.join("\n") + "\n";
}
