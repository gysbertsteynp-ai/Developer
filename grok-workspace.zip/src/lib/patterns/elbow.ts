import { bboxOf, shoelace } from "./geometry.ts";
import { fmt, fmtAngle, fmtArea, fmtMass, massKg, neutralDiameter } from "./format.ts";
import type { Basis, PatternResult, Piece, Pt, Shop } from "./types.ts";

export type SeamPlace = "throat" | "cheek" | "back";

export type ElbowInput = {
  diameter: number;
  clr: number;
  /** Bend angle, degrees. */
  angle: number;
  gores: number;
  thickness: number;
  allowance: number;
  basis: Basis;
  seam: SeamPlace;
};

const STEPS = 72;

function seamShift(seam: SeamPlace): number {
  if (seam === "back") return 0;
  if (seam === "cheek") return Math.PI / 2;
  return Math.PI;
}

/** Generator length factor (CLR + r cos ψ), ψ measured from the extrados. */
function radiusAt(clr: number, r: number, psi: number): number {
  return clr + r * Math.cos(psi);
}

function goreOutline(
  clr: number,
  r: number,
  tanBeta: number,
  kind: "end" | "middle",
  seam: SeamPlace,
  allowance: number,
): Pt[] {
  const shift = seamShift(seam);
  const circ = 2 * Math.PI * r;
  const lenAt = (i: number) => {
    const psi = shift + (i / STEPS) * Math.PI * 2;
    return radiusAt(clr, r, psi) * tanBeta * (kind === "middle" ? 2 : 1);
  };
  const xAt = (i: number) => (r * (i / STEPS) * Math.PI * 2);

  const pts: Pt[] = [];
  if (kind === "end") {
    for (let i = 0; i <= STEPS; i++) pts.push({ x: xAt(i), y: 0 });
    if (allowance > 0) pts.push({ x: circ + allowance, y: 0 });
    const seamLen = lenAt(0);
    if (allowance > 0) pts.push({ x: circ + allowance, y: seamLen });
    for (let i = STEPS; i >= 0; i--) pts.push({ x: xAt(i), y: lenAt(i) });
  } else {
    for (let i = 0; i <= STEPS; i++) pts.push({ x: xAt(i), y: lenAt(i) / 2 });
    const halfSeam = lenAt(0) / 2;
    if (allowance > 0) pts.push({ x: circ + allowance, y: halfSeam });
    if (allowance > 0) pts.push({ x: circ + allowance, y: -halfSeam });
    for (let i = STEPS; i >= 0; i--) pts.push({ x: xAt(i), y: -lenAt(i) / 2 });
  }
  return pts;
}

export function calcElbow(input: ElbowInput, shop: Shop): PatternResult {
  const { diameter, clr, angle, gores, thickness, allowance, basis, seam } = input;
  if (!(diameter > 0) || !(clr > 0) || !(angle > 0)) {
    return { ok: false, error: "Diameter, centerline radius, and bend angle all have to be greater than zero." };
  }
  if (angle > 180) return { ok: false, error: "Bend angle is limited to 180° in this layout." };
  if (!Number.isInteger(gores) || gores < 2 || gores > 12) {
    return { ok: false, error: "Use 2 to 12 gores." };
  }
  if (thickness < 0 || allowance < 0) return { ok: false, error: "Thickness and seam allowance can’t be negative." };
  if (shop.k < 0.2 || shop.k > 0.5) return { ok: false, error: "K-factor needs to sit between 0.20 and 0.50." };

  const dn = neutralDiameter(diameter, thickness, shop.k, basis);
  if (!(dn > 0)) return { ok: false, error: "Thickness wipes out the neutral diameter. Check the size basis." };
  const r = dn / 2;
  if (clr <= r) {
    return {
      ok: false,
      error: "Centerline radius has to be larger than half the neutral diameter, or the throat has no metal.",
    };
  }

  const betaDeg = angle / (2 * (gores - 1));
  const beta = (betaDeg * Math.PI) / 180;
  const tanBeta = Math.tan(beta);
  if (!(tanBeta > 0) || betaDeg >= 75) {
    return { ok: false, error: "That gore angle is too steep to be a practical miter. Add gores or reduce the bend." };
  }

  const end = goreOutline(clr, r, tanBeta, "end", seam, allowance);
  const middles = gores - 2;
  const middle = middles > 0 ? goreOutline(clr, r, tanBeta, "middle", seam, allowance) : null;

  const outside = (clr + r) * tanBeta;
  const inside = (clr - r) * tanBeta;
  const midOutside = outside * 2;
  const midInside = inside * 2;
  const endArea = shoelace(end);
  const midArea = middle ? shoelace(middle) : 0;
  const totalArea = endArea * 2 + midArea * middles;
  const kg = massKg(totalArea, thickness, shop.unit, shop.density);

  const endBox = bboxOf(end);
  const gap = Math.max(shop.unit === "mm" ? 40 : 2, (endBox.maxY - endBox.minY) * 0.12);
  const display: Piece[] = [{ outline: end, label: "End gore · cut 2" }];
  if (middle) {
    const midBox = bboxOf(middle);
    const dx = endBox.maxX + gap - midBox.minX;
    const dy = -midBox.minY;
    // Keep the end sitting on y=0 as drawn; shift middle up to share a baseline.
    const endDy = -endBox.minY;
    display[0] = {
      outline: end.map((p) => ({ x: p.x, y: p.y + endDy })),
      label: "End gore · cut 2",
    };
    display.push({
      outline: middle.map((p) => ({ x: p.x + dx, y: p.y + dy })),
      label: `Middle gore · cut ${middles}`,
    });
  }

  const seamName = seam === "throat" ? "throat (inside)" : seam === "cheek" ? "cheek (side)" : "back (outside)";
  const notes = [
    "Straight mitred gores — a lobsterback — not a smooth bent tube. Lengths use tan of the miter angle.",
    `End gores are ${fmtAngle(betaDeg)} off square. ${middles > 0 ? `Each middle gore turns ${fmtAngle(betaDeg * 2)}.` : "Two end gores only."}`,
    `Longitudinal seam is on the ${seamName}. Allowance, if any, is a lap along that seam.`,
    `Neutral pipe ${fmt(dn, shop.unit)} from the ${basis} size, k = ${shop.k.toFixed(2)}. Centerline radius is the bend radius you asked for, not shifted by thickness.`,
    "The DXF contains every gore, spaced apart. The gap is not a cut. Square edge of an end gore welds to straight pipe.",
    "Net blank only — no kerf, no bevel land.",
  ];
  if (clr < dn) notes.push("Tight bend: centerline radius is under one diameter. Expect a cramped throat weld.");

  const stats = [
    { label: "End, outside", value: fmt(outside, shop.unit), hero: true },
    { label: "End, inside", value: fmt(inside, shop.unit), hero: true },
    ...(middle
      ? [
          { label: "Middle, outside", value: fmt(midOutside, shop.unit), hero: true },
          { label: "Middle, inside", value: fmt(midInside, shop.unit), hero: true },
        ]
      : [{ label: "Gore angle", value: fmtAngle(betaDeg), hero: true }]),
    { label: "End gore angle", value: fmtAngle(betaDeg) },
    { label: "Middle gore angle", value: middles > 0 ? fmtAngle(betaDeg * 2) : "—" },
    { label: "Neutral Ø", value: fmt(dn, shop.unit) },
    { label: "Stretch-out", value: fmt(Math.PI * dn + allowance, shop.unit) },
    { label: "Gores", value: `${gores} (${2} end${middles ? ` + ${middles} middle` : ""})` },
    { label: "Area, full elbow", value: fmtArea(totalArea, shop.unit) },
    { label: `Weight · ${shop.material}`, value: fmtMass(kg, shop.unit) },
  ];

  const exportGroups = [
    { piece: { outline: end }, count: 2 },
    ...(middle ? [{ piece: { outline: middle }, count: middles }] : []),
  ];

  return {
    ok: true,
    pattern: {
      stats,
      display,
      guides: [],
      exportGroups,
      notes,
    },
  };
}

/** Miter rays in degrees, measured along the bend from the incoming tangent. */
export function miterAngles(angle: number, gores: number): number[] {
  const beta = angle / (2 * (gores - 1));
  const rays: number[] = [];
  let a = beta;
  while (a < angle - beta * 0.25) {
    rays.push(a);
    a += 2 * beta;
  }
  return rays;
}

