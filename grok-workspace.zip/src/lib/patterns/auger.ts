import { degToRad, sectorOutline } from "./geometry.ts";
import { fmt, fmtAngle, fmtArea, fmtMass, massKg } from "./format.ts";
import type { PatternResult, Sector, Shop } from "./types.ts";

export type AugerInput = {
  od: number;
  id: number;
  pitch: number;
  thickness: number;
  flights: number;
};

/**
 * One pitch of a flat helical flight.
 * Thickness is plate weight only — a flight is not a rolled shell, so it
 * does not get a neutral-diameter shrink.
 */
export function calcAuger(input: AugerInput, shop: Shop): PatternResult {
  const { od, id, pitch, thickness, flights } = input;
  if (!(od > id) || !(id > 0) || !(pitch > 0)) {
    return { ok: false, error: "Outside diameter has to be larger than the shaft hole, and pitch has to be greater than zero." };
  }
  if (thickness < 0) return { ok: false, error: "Thickness can’t be negative." };
  if (!Number.isInteger(flights) || flights < 1 || flights > 24) {
    return { ok: false, error: "Flight count must be a whole number from 1 to 24." };
  }

  const rO = od / 2;
  const rI = id / 2;
  const lenInner = Math.hypot(2 * Math.PI * rI, pitch);
  const lenOuter = Math.hypot(2 * Math.PI * rO, pitch);
  const width = rO - rI;
  const ratio = lenOuter / lenInner;
  if (!(ratio > 1.0000001)) {
    return { ok: false, error: "This pitch is so long the blank radius blows up. Check the pitch against the diameters." };
  }
  const innerR = width / (ratio - 1);
  const outerR = innerR + width;
  if (outerR > 1e7) {
    return { ok: false, error: "The blank would be enormous. Check the pitch and the two diameters." };
  }
  const sweepDeg = (lenInner / innerR) * (180 / Math.PI);
  if (sweepDeg >= 359.95) {
    return { ok: false, error: "Pitch is so small this is basically a flat washer. Increase the pitch." };
  }
  if (!(sweepDeg > 1)) return { ok: false, error: "Sweep angle collapsed. Check the inputs." };

  const startDeg = 90 - sweepDeg / 2;
  const sector: Sector = { cx: 0, cy: 0, innerR, outerR, startDeg, sweepDeg };
  const outline = sectorOutline(sector);
  const gap = 360 - sweepDeg;
  const areaOne = (degToRad(sweepDeg) / 2) * (outerR ** 2 - innerR ** 2);
  const area = areaOne * flights;
  const kg = massKg(area, thickness, shop.unit, shop.density);

  return {
    ok: true,
    pattern: {
      stats: [
        { label: "Blank outer R", value: fmt(outerR, shop.unit), hero: true },
        { label: "Blank inner R", value: fmt(innerR, shop.unit), hero: true },
        { label: "Sweep", value: fmtAngle(sweepDeg), hero: true },
        { label: "Gap to cut out", value: fmtAngle(gap), hero: true },
        { label: "Outer helix", value: fmt(lenOuter, shop.unit) },
        { label: "Inner helix", value: fmt(lenInner, shop.unit) },
        { label: "Radial width", value: fmt(width, shop.unit) },
        { label: "Blank outside Ø", value: fmt(outerR * 2, shop.unit) },
        { label: flights > 1 ? "Area, all flights" : "Area, one pitch", value: fmtArea(area, shop.unit) },
        { label: `Weight · ${shop.material}`, value: fmtMass(kg, shop.unit) },
      ],
      display: [{ outline, sector, label: flights > 1 ? `One pitch · cut ${flights}` : "One pitch" }],
      guides: [
        {
          x1: 0,
          y1: 0,
          x2: 0,
          y2: outerR,
          label: `R ${fmt(outerR, shop.unit)}`,
          lx: outerR * 0.12,
          ly: outerR * 0.72,
        },
        {
          x1: 0,
          y1: 0,
          x2: innerR * Math.cos(degToRad(90 + 28)),
          y2: innerR * Math.sin(degToRad(90 + 28)),
          label: `r ${fmt(innerR, shop.unit)}`,
          lx: innerR * Math.cos(degToRad(90 + 36)),
          ly: innerR * Math.sin(degToRad(90 + 36)),
        },
      ],
      exportGroups: [{ piece: { outline, sector }, count: flights }],
      notes: [
        "Flat flight, not a rolled shell. Outside and inside diameters are the finished flight; thickness is only used for weight.",
        "Outer and inner edges keep their true helical lengths. The gap is the wedge you cut out of the ring.",
        "One revolution per blank. A longer screw is this piece repeated.",
        flights > 1 ? `DXF contains ${flights} copies, spaced apart. The gap between copies is not a cut.` : "DXF is one flight.",
        "Net blank only — no kerf.",
      ],
    },
  };
}
