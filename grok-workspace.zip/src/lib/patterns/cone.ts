import { degToRad, sectorOutline } from "./geometry.ts";
import { fmt, fmtAngle, fmtArea, fmtMass, massKg, neutralDiameter } from "./format.ts";
import type { Basis, PatternResult, Sector, Shop } from "./types.ts";

export type ConeInput = {
  large: number;
  small: number;
  height: number;
  thickness: number;
  allowance: number;
  pieces: number;
  basis: Basis;
};

export function calcCone(input: ConeInput, shop: Shop): PatternResult {
  const { height, thickness, allowance, basis } = input;
  let { large, small, pieces } = input;
  if (!(large > 0) || !(height > 0) || small < 0) {
    return { ok: false, error: "Height and the large end must be greater than zero. The small end can be zero for a true cone." };
  }
  if (thickness < 0 || allowance < 0) return { ok: false, error: "Thickness and seam allowance can’t be negative." };
  if (!Number.isInteger(pieces) || pieces < 1 || pieces > 8) {
    return { ok: false, error: "Pieces must be a whole number from 1 to 8." };
  }
  if (shop.k < 0.2 || shop.k > 0.5) return { ok: false, error: "K-factor needs to sit between 0.20 and 0.50." };

  const notes: string[] = [];
  if (small > large) {
    const swap = large;
    large = small;
    small = swap;
    notes.push("The two ends were ordered large to small for the blank. Height is unchanged.");
  }

  const dLarge = neutralDiameter(large, thickness, shop.k, basis);
  const dSmall = small === 0 ? 0 : neutralDiameter(small, thickness, shop.k, basis);
  if (!(dLarge > dSmall) || !(dLarge > 0) || dSmall < 0) {
    return { ok: false, error: "After the thickness allowance the ends are equal or inverted. Use the pipe pattern, or check inside versus outside." };
  }
  if (dLarge - dSmall < Math.max(dLarge, 1) * 1e-4) {
    return { ok: false, error: "The ends are essentially equal. That’s a cylinder — use the pipe pattern." };
  }

  const rLarge = dLarge / 2;
  const rSmall = dSmall / 2;
  const slant = Math.hypot(rLarge - rSmall, height);
  const outerR = (rLarge * slant) / (rLarge - rSmall);
  const innerR = outerR - slant;
  if (!(outerR > innerR) || innerR < -1e-6) {
    return { ok: false, error: "The sector radii didn’t come out positive. Check the height and the two ends." };
  }

  const largeCirc = Math.PI * dLarge;
  const smallCirc = Math.PI * dSmall;
  const sweepDeg = ((largeCirc / pieces + allowance) / outerR) * (180 / Math.PI);
  if (!(sweepDeg > 0.5)) return { ok: false, error: "The sweep angle is essentially zero." };
  if (sweepDeg >= 360) {
    return {
      ok: false,
      error: "Seam allowance makes one piece wrap into a full circle. Use more pieces or a smaller lap.",
    };
  }

  const startDeg = 90 - sweepDeg / 2;
  const sector: Sector = {
    cx: 0,
    cy: 0,
    innerR: Math.max(0, innerR),
    outerR,
    startDeg,
    sweepDeg,
  };
  const outline = sectorOutline(sector);
  const mid = degToRad(90);
  const labelR = outerR * 1.04;
  const areaOne = (degToRad(sweepDeg) / 2) * (outerR ** 2 - Math.max(0, innerR) ** 2);
  const area = areaOne * pieces;
  const kg = massKg(area, thickness, shop.unit, shop.density);
  const largeArc = outerR * degToRad(sweepDeg);
  const smallArc = Math.max(0, innerR) * degToRad(sweepDeg);

  notes.push(
    `Neutral ends ${fmt(dLarge, shop.unit)} and ${fmt(dSmall, shop.unit)} from the ${basis} sizes, k = ${shop.k.toFixed(2)}.`,
    "Tape the outer arc — it should match the large-end neutral circumference split across the pieces, plus one lap per piece.",
    pieces > 1 ? `DXF contains ${pieces} identical pieces, spaced apart. The gap is not a cut.` : "One piece, full sweep.",
    innerR <= 1e-4 ? "True cone: the blank runs to the apex." : "Frustum: keep the inner arc — that is the small end.",
    "Net blank only — no kerf.",
  );

  return {
    ok: true,
    pattern: {
      stats: [
        { label: "Outer radius", value: fmt(outerR, shop.unit), hero: true },
        { label: innerR <= 1e-4 ? "Inner radius" : "Inner radius", value: fmt(Math.max(0, innerR), shop.unit), hero: true },
        { label: pieces > 1 ? "Sweep / piece" : "Sweep", value: fmtAngle(sweepDeg), hero: true },
        { label: "Slant height", value: fmt(slant, shop.unit), hero: true },
        { label: "Large-end arc", value: fmt(largeArc, shop.unit) },
        { label: "Small-end arc", value: fmt(smallArc, shop.unit) },
        { label: "Neutral large Ø", value: fmt(dLarge, shop.unit) },
        { label: "Neutral small Ø", value: fmt(dSmall, shop.unit) },
        { label: "Pieces", value: String(pieces) },
        { label: pieces > 1 ? "Area, all pieces" : "Area", value: fmtArea(area, shop.unit) },
        { label: `Weight · ${shop.material}`, value: fmtMass(kg, shop.unit) },
      ],
      display: [{ outline, sector, label: pieces > 1 ? `One piece · cut ${pieces}` : "Cone blank" }],
      guides: [
        {
          x1: 0,
          y1: 0,
          x2: labelR * Math.cos(mid),
          y2: labelR * Math.sin(mid),
          label: `R ${fmt(outerR, shop.unit)}`,
          lx: (outerR * 0.62) * Math.cos(mid) + outerR * 0.08,
          ly: (outerR * 0.62) * Math.sin(mid),
        },
        {
          x1: 0,
          y1: 0,
          x2: Math.max(innerR, outerR * 0.08) * Math.cos(mid + 0.35),
          y2: Math.max(innerR, outerR * 0.08) * Math.sin(mid + 0.35),
          label: innerR > 1 ? `r ${fmt(innerR, shop.unit)}` : "Apex",
          lx: Math.max(innerR, outerR * 0.15) * Math.cos(mid + 0.55),
          ly: Math.max(innerR, outerR * 0.15) * Math.sin(mid + 0.55),
        },
      ],
      exportGroups: [{ piece: { outline, sector }, count: pieces }],
      notes,
    },
  };
}
