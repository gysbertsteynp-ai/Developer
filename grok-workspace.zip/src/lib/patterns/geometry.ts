import type { Piece, Pt, Sector } from "./types.ts";

export function hypot(a: number, b: number, c = 0): number {
  return Math.hypot(a, b, c);
}

export function shoelace(pts: Pt[]): number {
  let sum = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    sum += a.x * b.y - b.x * a.y;
  }
  return Math.abs(sum) / 2;
}

export function bboxOf(pts: Pt[]): { minX: number; minY: number; maxX: number; maxY: number } {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const p of pts) {
    if (p.x < minX) minX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.x > maxX) maxX = p.x;
    if (p.y > maxY) maxY = p.y;
  }
  return { minX, minY, maxX, maxY };
}

export function sectorOutline(sector: Sector): Pt[] {
  const { cx, cy, innerR, outerR, startDeg, sweepDeg } = sector;
  const steps = Math.max(24, Math.ceil(Math.abs(sweepDeg) / 2.5));
  const start = (startDeg * Math.PI) / 180;
  const sweep = (sweepDeg * Math.PI) / 180;
  const pts: Pt[] = [];
  const pushArc = (r: number, from: number, dir: number) => {
    if (r < 1e-6) {
      pts.push({ x: cx, y: cy });
      return;
    }
    for (let i = 0; i <= steps; i++) {
      const a = from + dir * sweep * (i / steps);
      pts.push({ x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) });
    }
  };
  pushArc(outerR, start, 1);
  if (innerR < 1e-6) {
    pts.push({ x: cx, y: cy });
  } else {
    pushArc(innerR, start + sweep, -1);
  }
  return pts;
}

export function translatePiece(piece: Piece, dx: number, dy: number): Piece {
  const move = (p: Pt): Pt => ({ x: p.x + dx, y: p.y + dy });
  const sector = piece.sector
    ? { ...piece.sector, cx: piece.sector.cx + dx, cy: piece.sector.cy + dy }
    : undefined;
  return {
    ...piece,
    outline: piece.outline.map(move),
    folds: piece.folds?.map(([a, b]) => [move(a), move(b)]),
    sector,
  };
}

/** Lay copies in a row, origin at the lower-left of the first piece. Y-up. */
export function tileGroups(
  groups: { piece: Piece; count: number }[],
  gap: number,
): Piece[] {
  const out: Piece[] = [];
  let cursor = 0;
  for (const group of groups) {
    for (let i = 0; i < group.count; i++) {
      const box = bboxOf(group.piece.outline);
      const dx = cursor - box.minX;
      const dy = -box.minY;
      out.push(translatePiece(group.piece, dx, dy));
      cursor += box.maxX - box.minX + gap;
    }
  }
  return out;
}

function cross(a: Pt, b: Pt, c: Pt): number {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

/** True when non-adjacent edges properly cross. */
export function selfIntersects(pts: Pt[]): boolean {
  const n = pts.length;
  if (n < 4) return false;
  for (let i = 0; i < n; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % n];
    for (let j = i + 1; j < n; j++) {
      const adjacent = j === i || (j + 1) % n === i || (i + 1) % n === j || (j + 1) % n === (i + 1) % n;
      if (adjacent) continue;
      // Skip the closing-edge neighbour of the first edge.
      if (i === 0 && j === n - 1) continue;
      const c = pts[j];
      const d = pts[(j + 1) % n];
      const c1 = cross(a, b, c);
      const c2 = cross(a, b, d);
      const c3 = cross(c, d, a);
      const c4 = cross(c, d, b);
      if (c1 * c2 < 0 && c3 * c4 < 0) return true;
    }
  }
  return false;
}

export function degToRad(d: number): number {
  return (d * Math.PI) / 180;
}

export function radToDeg(r: number): number {
  return (r * 180) / Math.PI;
}
