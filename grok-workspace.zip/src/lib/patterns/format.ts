import type { UnitSystem } from "./types.ts";

export function decimals(unit: UnitSystem): number {
  return unit === "mm" ? 2 : 3;
}

export function fmt(n: number, unit: UnitSystem, digits?: number): string {
  const d = digits ?? decimals(unit);
  const body = n.toLocaleString("en-US", {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  });
  return `${body} ${unit}`;
}

export function fmtAngle(deg: number): string {
  return `${deg.toFixed(2)}°`;
}

export function massKg(area: number, thickness: number, unit: UnitSystem, density: number): number {
  const volumeM3 =
    unit === "mm" ? (area * thickness) / 1e9 : area * thickness * 0.0254 ** 3;
  return volumeM3 * density;
}

export function fmtMass(kg: number, unit: UnitSystem): string {
  if (unit === "in") return `${(kg * 2.2046226218).toFixed(2)} lb`;
  if (kg >= 1000) return `${(kg / 1000).toFixed(3)} t`;
  return `${kg.toFixed(2)} kg`;
}

export function fmtArea(area: number, unit: UnitSystem): string {
  if (unit === "mm") {
    if (area >= 1_000_000) return `${(area / 1_000_000).toFixed(3)} m²`;
    return `${Math.round(area).toLocaleString("en-US")} mm²`;
  }
  return `${area.toFixed(2)} in²`;
}

export function neutralDiameter(
  measured: number,
  thickness: number,
  k: number,
  basis: "outside" | "inside",
): number {
  if (basis === "outside") return measured - 2 * (1 - k) * thickness;
  return measured + 2 * k * thickness;
}

export const MATERIALS = [
  { id: "mild", name: "Mild steel", density: 7850 },
  { id: "ss", name: "Stainless", density: 8000 },
  { id: "alu", name: "Aluminum", density: 2700 },
] as const;

export type MaterialId = (typeof MATERIALS)[number]["id"];

export function materialById(id: string): (typeof MATERIALS)[number] {
  return MATERIALS.find((m) => m.id === id) ?? MATERIALS[0];
}
