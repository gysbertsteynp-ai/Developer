import { bboxOf } from "./geometry.ts";
import { fmt, fmtArea, fmtMass, massKg, neutralDiameter } from "./format.ts";
import type { Basis, PatternResult, Pt, Shop } from "./types.ts";

export type CylinderInput = {
  diameter: number;
  length: number;
  thickness: number;
  allowance: number;
  basis: Basis;
  /** Max axial length of one course. 0 = one piece. */
  plateWidth: number;
};

export function calcCylinder(input: CylinderInput, shop: Shop): PatternResult {
  const { diameter, length, thickness, allowance, basis, plateWidth } = input;
  if (!(diameter > 0) || !(length > 0)) return { ok: false, error: "Diameter and length have to be greater than zero." };
  if (thickness < 0 || allowance < 0) return { ok: false, error: "Thickness and seam allowance can’t be negative." };
  if (shop.k < 0.2 || shop.k > 0.5) return { ok: false, error: "K-factor needs to sit between 0.20 and 0.50." };

  const dn = neutralDiameter(diameter, thickness, shop.k, basis);
  if (!(dn > 0)) {
    return { ok: false, error: "Thickness is large enough to wipe out the neutral diameter. Check the size basis." };
  }

  const circ = Math.PI * dn;
  const stretch = circ + allowance;
  let courses = 1;
  if (plateWidth > 0) {
    if (plateWidth < length / 24) {
      return { ok: false, error: "That plate width would chop the shell into too many courses." };
    }
    courses = Math.ceil(length / plateWidth - 1e-9);
  }
  const courseLen = length / courses;
  const areaOne = stretch * courseLen;
  const area = areaOne * courses;
  const kgOne = massKg(areaOne, thickness, shop.unit, shop.density);
  const kg = kgOne * courses;

  const outline: Pt[] = [
    { x: 0, y: 0 },
    { x: stretch, y: 0 },
    { x: stretch, y: courseLen },
    { x: 0, y: courseLen },
  ];
  const box = bboxOf(outline);
  const m = Math.max(box.maxX, box.maxY) * 0.08;

  const notes = [
    `Neutral diameter ${fmt(dn, shop.unit)} from the ${basis} size, k = ${shop.k.toFixed(2)}.`,
    "Roll the stretch-out. The short dimension is the axis of the pipe and does not grow.",
    courses > 1
      ? `${courses} equal courses. The DXF has one rectangle per course, spaced apart — the gap is not a cut.`
      : "One course.",
    allowance > 0 ? `Each course includes ${fmt(allowance, shop.unit)} of seam allowance on the stretch-out.` : "No seam allowance added.",
    "Net blank only — no kerf, no bevel land.",
  ];
  if (shop.unit === "mm" && stretch > 6000) {
    notes.push("Stretch-out is over 6 m. Confirm you can buy and roll a plate that long.");
  }
  if (shop.unit === "in" && stretch > 240) {
    notes.push("Stretch-out is over 20 ft. Confirm plate length before you nest it.");
  }

  return {
    ok: true,
    pattern: {
      stats: [
        { label: "Stretch-out", value: fmt(stretch, shop.unit), hero: true },
        { label: courses > 1 ? "Length / course" : "Axial length", value: fmt(courseLen, shop.unit), hero: true },
        { label: "Neutral Ø", value: fmt(dn, shop.unit) },
        { label: "Courses", value: String(courses) },
        { label: "Bare circumference", value: fmt(circ, shop.unit) },
        { label: "Plate for one course", value: `${fmt(stretch, shop.unit)} × ${fmt(courseLen, shop.unit)}` },
        { label: courses > 1 ? "Area, all courses" : "Area", value: fmtArea(area, shop.unit) },
        { label: courses > 1 ? `Weight, all · ${shop.material}` : `Weight · ${shop.material}`, value: fmtMass(kg, shop.unit) },
      ],
      display: [{ outline, label: courses > 1 ? `One course · cut ${courses}` : "Shell blank" }],
      guides: [
        {
          x1: 0,
          y1: courseLen + m,
          x2: stretch,
          y2: courseLen + m,
          label: `Stretch-out ${fmt(stretch, shop.unit)}`,
          lx: stretch / 2,
          ly: courseLen + m * 1.7,
        },
        {
          x1: -m,
          y1: 0,
          x2: -m,
          y2: courseLen,
          label: `Axial ${fmt(courseLen, shop.unit)}`,
          lx: -m * 1.55,
          ly: courseLen / 2,
          along: "y",
        },
      ],
      exportGroups: [{ piece: { outline }, count: courses }],
      notes,
    },
  };
}

