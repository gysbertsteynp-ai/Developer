import assert from "node:assert/strict";
import test from "node:test";
import { calcAuger } from "./auger.ts";
import { calcCone } from "./cone.ts";
import { calcCylinder } from "./cylinder.ts";
import { buildDxf } from "./dxf.ts";
import { calcElbow, miterAngles } from "./elbow.ts";
import { neutralDiameter } from "./format.ts";
import { shoelace } from "./geometry.ts";
import { calcTransition, developRectTransition, developTransition } from "./transition.ts";
import { smallestPlate } from "./stock.ts";
import { buildSvg } from "./svg.ts";
import { tileGroups } from "./geometry.ts";
import { DEFAULT_STATE, evaluate, mergeSaved } from "./evaluate.ts";
import type { Shop } from "./types.ts";

const shop: Shop = { unit: "mm", k: 0.5, density: 7850, material: "Mild steel" };

test("neutral diameter matches mid-thickness shop practice", () => {
  assert.equal(neutralDiameter(500, 5, 0.5, "outside"), 495);
  assert.equal(neutralDiameter(500, 5, 0.5, "inside"), 505);
  assert.equal(neutralDiameter(500, 10, 0.33, "inside"), 500 + 2 * 0.33 * 10);
});

test("cylinder stretch-out is pi times neutral diameter plus lap", () => {
  const result = calcCylinder(
    { diameter: 500, length: 800, thickness: 5, allowance: 10, basis: "outside", plateWidth: 0 },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  const stretch = Math.PI * 495 + 10;
  const hero = result.pattern.stats.find((s) => s.label === "Stretch-out");
  assert.ok(hero);
  assert.equal(hero.value, `${stretch.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} mm`);
  assert.ok(Math.abs(shoelace(result.pattern.display[0].outline) - stretch * 800) < 1e-6);
});

test("cylinder splits equal courses", () => {
  const result = calcCylinder(
    { diameter: 200, length: 1000, thickness: 0, allowance: 0, basis: "outside", plateWidth: 400 },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.pattern.exportGroups[0].count, 3);
});

test("cone sector arcs match the neutral circumferences", () => {
  const result = calcCone(
    { large: 600, small: 250, height: 450, thickness: 5, allowance: 0, pieces: 1, basis: "inside" },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  const sector = result.pattern.display[0].sector;
  assert.ok(sector);
  const dLarge = 605;
  const dSmall = 255;
  const rLarge = dLarge / 2;
  const rSmall = dSmall / 2;
  const slant = Math.hypot(rLarge - rSmall, 450);
  const outerR = (rLarge * slant) / (rLarge - rSmall);
  const sweep = (Math.PI * dLarge) / outerR;
  assert.ok(Math.abs(sector.outerR - outerR) < 1e-6);
  assert.ok(Math.abs(sector.outerR - sector.innerR - slant) < 1e-6);
  assert.ok(Math.abs((sector.sweepDeg * Math.PI) / 180 - sweep) < 1e-6);
  assert.ok(sector.sweepDeg < 360);
});

test("cone lap is added once per piece and can refuse a full wrap", () => {
  const ok = calcCone(
    { large: 1000, small: 100, height: 80, thickness: 0, allowance: 5, pieces: 2, basis: "outside" },
    shop,
  );
  assert.equal(ok.ok, true);
  if (!ok.ok) return;
  assert.equal(ok.pattern.exportGroups[0].count, 2);
  const tooMuch = calcCone(
    { large: 1000, small: 900, height: 40, thickness: 0, allowance: 5000, pieces: 1, basis: "outside" },
    shop,
  );
  assert.equal(tooMuch.ok, false);
});

test("auger blank keeps both helical lengths and ignores thickness", () => {
  const bare = calcAuger({ od: 400, id: 100, pitch: 300, thickness: 0, flights: 1 }, shop);
  const thick = calcAuger({ od: 400, id: 100, pitch: 300, thickness: 12, flights: 3 }, shop);
  assert.equal(bare.ok, true);
  assert.equal(thick.ok, true);
  if (!bare.ok || !thick.ok) return;
  const a = bare.pattern.display[0].sector;
  const b = thick.pattern.display[0].sector;
  assert.ok(a && b);
  assert.ok(Math.abs(a.outerR - b.outerR) < 1e-9);
  const rO = 200;
  const rI = 50;
  const lenInner = Math.hypot(2 * Math.PI * rI, 300);
  const lenOuter = Math.hypot(2 * Math.PI * rO, 300);
  const sweep = (a.sweepDeg * Math.PI) / 180;
  assert.ok(Math.abs(a.innerR * sweep - lenInner) < 1e-6);
  assert.ok(Math.abs(a.outerR * sweep - lenOuter) < 1e-6);
  assert.ok(Math.abs(a.outerR - a.innerR - (rO - rI)) < 1e-6);
  assert.ok(a.sweepDeg < 360);
  assert.equal(thick.pattern.exportGroups[0].count, 3);
});

test("square-to-round half pattern is a simple polygon with the right base", () => {
  for (const quarters of [1, 2, 4] as const) {
    for (const sample of [
      { side: 600, dia: 300, h: 400 },
      { side: 400, dia: 500, h: 350 },
      { side: 800, dia: 200, h: 100 },
    ]) {
      const built = developTransition(sample.side, sample.dia, sample.h, 12, quarters);
      const topCount = 12 * quarters + 1;
      const baseCount = quarters + 2;
      assert.equal(built.outline.length, topCount + baseCount);
      let base = 0;
      for (let i = 0; i < baseCount - 1; i++) {
        const a = built.outline[topCount + i];
        const b = built.outline[topCount + i + 1];
        base += Math.hypot(a.x - b.x, a.y - b.y);
      }
      assert.ok(Math.abs(base - quarters * sample.side) < 0.05, `base ${base} vs ${quarters * sample.side}`);
      const area = shoelace(built.outline);
      assert.ok(area > 1000);
    }
  }
});

test("elbow lengths follow the miter tangent, not the smooth arc", () => {
  const result = calcElbow(
    {
      diameter: 500,
      clr: 750,
      angle: 90,
      gores: 5,
      thickness: 0,
      allowance: 0,
      basis: "outside",
      seam: "throat",
    },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  const beta = (11.25 * Math.PI) / 180;
  const outside = (750 + 250) * Math.tan(beta);
  const inside = (750 - 250) * Math.tan(beta);
  const hero = result.pattern.stats.find((s) => s.label === "End, outside");
  assert.equal(
    hero?.value,
    `${outside.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} mm`,
  );
  const insideStat = result.pattern.stats.find((s) => s.label === "End, inside");
  assert.equal(
    insideStat?.value,
    `${inside.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} mm`,
  );
  assert.equal(result.pattern.exportGroups[0].count, 2);
  assert.equal(result.pattern.exportGroups[1].count, 3);
  const rays = miterAngles(90, 5);
  assert.deepEqual(
    rays.map((n) => Math.round(n * 100) / 100),
    [11.25, 33.75, 56.25, 78.75],
  );
  assert.equal(calcElbow(
    { diameter: 500, clr: 250, angle: 90, gores: 3, thickness: 0, allowance: 0, basis: "outside", seam: "back" },
    shop,
  ).ok, false);
});

test("dxf is full size, layered, and uses real arcs for a cone", () => {
  const result = calcCone(
    { large: 600, small: 250, height: 450, thickness: 0, allowance: 0, pieces: 1, basis: "outside" },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  const dxf = buildDxf({
    groups: result.pattern.exportGroups,
    unit: "mm",
    comment: "test",
    includeFolds: false,
    gap: 20,
  });
  assert.match(dxf, /AC1009/);
  assert.match(dxf, /\$INSUNITS\s+70\s+4/);
  assert.match(dxf, /\nARC\n/);
  assert.match(dxf, /\nCUT\n/);
  const sector = result.pattern.display[0].sector;
  assert.ok(sector);
  assert.match(dxf, new RegExp(sector.outerR.toFixed(4)));
});

test("transition shop wrapper reports a half pattern", () => {
  const result = calcTransition(
    { length: 600, width: 600, round: 300, height: 400, thickness: 5, basis: "inside", segments: 12, part: "half" },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.match(result.pattern.stats.find((s) => s.label === "Pattern")?.value ?? "", /Half/);
  assert.ok((result.pattern.trueLengths?.length ?? 0) > 4);
});

test("rectangle-to-round keeps the base perimeter and both seams", () => {
  const length = 800;
  const width = 500;
  const round = 300;
  const height = 400;
  const r = round / 2;
  const half = developRectTransition(length, width, round, height, 12, 2);
  const topCount = 12 * 2 + 1;
  const baseCount = 4;
  assert.equal(half.outline.length, topCount + baseCount);
  let base = 0;
  for (let i = 0; i < baseCount - 1; i++) {
    const a = half.outline[topCount + i];
    const b = half.outline[topCount + i + 1];
    base += Math.hypot(a.x - b.x, a.y - b.y);
  }
  assert.ok(Math.abs(base - (length + width)) < 0.05, `base ${base}`);
  const startSeam = Math.hypot(half.outline[0].x - half.outline.at(-1)!.x, half.outline[0].y - half.outline.at(-1)!.y);
  assert.ok(Math.abs(startSeam - Math.hypot(width / 2 - r, height)) < 0.05);
  const crossSeam = Math.hypot(length / 2 - r, height);
  const folds = half.folds.map(([a, b]) => Math.hypot(a.x - b.x, a.y - b.y));
  assert.ok(folds.some((len) => Math.abs(len - crossSeam) < 0.05), folds.map((n) => n.toFixed(2)).join(", "));

  const full = developRectTransition(length, width, round, height, 12, 4);
  const other = developRectTransition(width, length, round, height, 12, 2);
  const fullArea = shoelace(full.outline);
  assert.ok(Math.abs(shoelace(half.outline) * 2 - fullArea) / fullArea < 0.002);
  assert.ok(Math.abs(shoelace(other.outline) * 2 - fullArea) / fullArea < 0.002);

  const wrapped = calcTransition(
    { length, width, round, height, thickness: 0, basis: "outside", segments: 12, part: "half" },
    shop,
  );
  assert.equal(wrapped.ok, true);
  if (!wrapped.ok) return;
  assert.match(wrapped.pattern.stats.find((s) => s.label === "Seam on lengths")?.value ?? "", /mm/);
  assert.equal(
    calcTransition(
      { length, width, round, height, thickness: 0, basis: "outside", segments: 12, part: "quarter" },
      shop,
    ).ok,
    false,
  );
});

test("a pipe blank names a common plate, and a saved square stays square", () => {
  const result = evaluate(DEFAULT_STATE);
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.match(result.pattern.stats.find((s) => s.label === "Common plate")?.value ?? "", /1000 × 2000/);
  const restored = mergeSaved({ transition: { square: "600", part: "quarter" } });
  assert.equal(restored.transition.length, "600");
  assert.equal(restored.transition.width, "600");
  assert.equal(restored.transition.part, "quarter");
  const huge = smallestPlate([{ w: 4000, h: 4000 }], "mm");
  assert.equal(huge.label, "Special");
});

test("svg export is full-size geometry", () => {
  const result = calcCone(
    { large: 600, small: 250, height: 450, thickness: 0, allowance: 0, pieces: 1, basis: "outside" },
    shop,
  );
  assert.equal(result.ok, true);
  if (!result.ok) return;
  const svg = buildSvg({
    pieces: tileGroups(result.pattern.exportGroups, 25),
    unit: "mm",
    title: "cone",
    includeFolds: false,
  });
  assert.match(svg, /<path/);
  assert.match(svg, /viewBox/);
  assert.match(svg, /1 user unit = 1 mm/);
});
