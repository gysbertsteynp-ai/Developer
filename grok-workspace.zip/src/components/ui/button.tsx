import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md font-semibold transition-colors duration-200 disabled:pointer-events-none disabled:opacity-40",
  {
    variants: {
      variant: {
        brass: "bg-brass text-brass-ink hover:bg-brass/90",
        line: "border border-line bg-panel text-fg hover:border-brass",
        ghost: "bg-transparent text-mist hover:bg-panel-2 hover:text-fg",
      },
      size: {
        md: "h-11 px-4 text-sm",
        sm: "h-9 px-3 text-xs",
      },
    },
    defaultVariants: { variant: "brass", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants>) {
  return <button type={type} className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}
