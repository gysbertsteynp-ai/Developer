import { useEffect, useMemo, useRef, useState } from "react";
import { LocateFixed, ZoomIn, ZoomOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Pattern, Pt } from "@/lib/patterns/types";

function pointsOf(pattern: Pattern): Pt[] {
  const pts: Pt[] = [];
  for (const piece of pattern.display) {
    pts.push(...piece.outline);
    for (const [a, b] of piece.folds ?? []) pts.push(a, b);
  }
  for (const guide of pattern.guides) {
    pts.push({ x: guide.x1, y: guide.y1 }, { x: guide.x2, y: guide.y2 }, { x: guide.lx, y: guide.ly });
  }
  return pts;
}

export function LayoutSheet({
  pattern,
  error,
  resetKey,
}: {
  pattern: Pattern | null;
  error: string | null;
  resetKey: string;
}) {
  const stageRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });

  useEffect(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, [resetKey]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      const factor = event.deltaY > 0 ? 0.92 : 1.08;
      setZoom((value) => Math.min(8, Math.max(0.6, value * factor)));
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  const view = useMemo(() => {
    if (!pattern) return null;
    const pts = pointsOf(pattern);
    if (pts.length === 0) return null;
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const point of pts) {
      const x = point.x;
      const y = -point.y;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
    const width = Math.max(maxX - minX, 1);
    const height = Math.max(maxY - minY, 1);
    const span = Math.max(width, height);
    const fontSize = Math.min(width, height) * 0.055;
    const pad = span * 0.14 + fontSize * 2;
    return {
      viewBox: `${minX - pad} ${minY - pad} ${width + pad * 2} ${height + pad * 2}`,
      fontSize,
    };
  }, [pattern]);

  const fit = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  return (
    <div className="layout-sheet relative overflow-hidden rounded-md border border-line">
      <div className="pointer-events-none absolute top-3 right-3 left-3 z-10 flex items-start justify-between gap-2">
        <p className="rounded-sm bg-sheet/90 px-2 py-1 text-xs font-medium tracking-wide text-sheet-ink">
          Full-size geometry
        </p>
        <div className="pointer-events-auto flex gap-1">
          <Button variant="line" size="sm" aria-label="Zoom out" onClick={() => setZoom((z) => Math.max(0.6, z / 1.2))}>
            <ZoomOut className="size-4" aria-hidden="true" />
          </Button>
          <Button variant="line" size="sm" aria-label="Zoom in" onClick={() => setZoom((z) => Math.min(8, z * 1.2))}>
            <ZoomIn className="size-4" aria-hidden="true" />
          </Button>
          <Button variant="line" size="sm" aria-label="Fit pattern" onClick={fit}>
            <LocateFixed className="size-4" aria-hidden="true" />
          </Button>
        </div>
      </div>

      <div
        ref={stageRef}
        className="sheet-stage h-full w-full cursor-grab active:cursor-grabbing"
        onPointerDown={(event) => {
          if (event.button !== 0) return;
          event.currentTarget.setPointerCapture(event.pointerId);
          drag.current = { x: event.clientX, y: event.clientY, px: pan.x, py: pan.y };
        }}
        onPointerMove={(event) => {
          if (!drag.current) return;
          setPan({
            x: drag.current.px + (event.clientX - drag.current.x),
            y: drag.current.py + (event.clientY - drag.current.y),
          });
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
        onPointerCancel={() => {
          drag.current = null;
        }}
      >
        {pattern && view ? (
          <svg
            viewBox={view.viewBox}
            preserveAspectRatio="xMidYMid meet"
            role="img"
            aria-label="Flat pattern layout"
            className="h-full w-full"
            style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: "center" }}
          >
            {pattern.display.map((piece, index) => (
              <g key={piece.label ?? index}>
                <polygon
                  points={piece.outline.map((point) => `${point.x},${-point.y}`).join(" ")}
                  className="fill-sheet-ink/10 stroke-cut"
                  strokeWidth={1.75}
                  strokeLinejoin="round"
                  vectorEffect="non-scaling-stroke"
                />
                {piece.folds?.map(([a, b], foldIndex) => (
                  <line
                    key={foldIndex}
                    x1={a.x}
                    y1={-a.y}
                    x2={b.x}
                    y2={-b.y}
                    className="stroke-fold"
                    strokeWidth={1.25}
                    strokeDasharray="5 4"
                    vectorEffect="non-scaling-stroke"
                  />
                ))}
                {piece.label ? (
                  <PieceLabel piece={piece} fontSize={view.fontSize} />
                ) : null}
              </g>
            ))}
            {pattern.guides.map((guide) => {
              const x1 = guide.x1;
              const y1 = -guide.y1;
              const x2 = guide.x2;
              const y2 = -guide.y2;
              const verticalLine = Math.abs(guide.y2 - guide.y1) > Math.abs(guide.x2 - guide.x1);
              const tick = view.fontSize * 0.28;
              const lx = guide.lx;
              const ly = -guide.ly;
              return (
                <g key={guide.label}>
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    className="stroke-dim"
                    strokeWidth={1.25}
                    vectorEffect="non-scaling-stroke"
                  />
                  {verticalLine ? (
                    <>
                      <line x1={x1 - tick} y1={y1} x2={x1 + tick} y2={y1} className="stroke-dim" strokeWidth={1.25} vectorEffect="non-scaling-stroke" />
                      <line x1={x2 - tick} y1={y2} x2={x2 + tick} y2={y2} className="stroke-dim" strokeWidth={1.25} vectorEffect="non-scaling-stroke" />
                    </>
                  ) : (
                    <>
                      <line x1={x1} y1={y1 - tick} x2={x1} y2={y1 + tick} className="stroke-dim" strokeWidth={1.25} vectorEffect="non-scaling-stroke" />
                      <line x1={x2} y1={y2 - tick} x2={x2} y2={y2 + tick} className="stroke-dim" strokeWidth={1.25} vectorEffect="non-scaling-stroke" />
                    </>
                  )}
                  <text
                    x={lx}
                    y={ly}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    transform={guide.along === "y" ? `rotate(-90 ${lx} ${ly})` : undefined}
                    fontSize={view.fontSize * 0.72}
                    className="font-sans"
                    fill="var(--color-dim)"
                    stroke="var(--color-sheet)"
                    strokeWidth={view.fontSize * 0.18}
                    paintOrder="stroke"
                  >
                    {guide.label}
                  </text>
                </g>
              );
            })}
          </svg>
        ) : (
          <div className="flex h-full items-center justify-center px-8 text-center">
            <p className="max-w-sm text-sm text-dim">{error ?? "Enter the sizes to lay out the blank."}</p>
          </div>
        )}
      </div>

      <div className="pointer-events-none absolute right-3 bottom-3 left-3 flex items-end justify-between gap-3 text-xs text-sheet-ink">
        <p className="rounded-sm bg-sheet/90 px-2 py-1">
          Solid line cuts. {pattern?.display.some((piece) => piece.folds?.length) ? "Blue dashes are layout lines, not cuts." : "Drag to pan. Scroll to zoom."}
        </p>
      </div>

      {error && pattern ? (
        <p className="absolute right-3 bottom-12 left-3 rounded-sm bg-sheet/95 px-3 py-2 text-sm text-dim">{error}</p>
      ) : null}
    </div>
  );
}

function PieceLabel({
  piece,
  fontSize,
}: {
  piece: Pattern["display"][number];
  fontSize: number;
}) {
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;
  for (const point of piece.outline) {
    if (point.x < minX) minX = point.x;
    if (point.x > maxX) maxX = point.x;
    if (point.y < minY) minY = point.y;
    if (point.y > maxY) maxY = point.y;
  }
  return (
    <text
      x={(minX + maxX) / 2}
      y={-((minY + maxY) / 2)}
      textAnchor="middle"
      dominantBaseline="middle"
      fontSize={fontSize * 0.8}
      className="font-display"
      fill="var(--color-sheet-ink)"
      stroke="var(--color-sheet)"
      strokeWidth={fontSize * 0.22}
      paintOrder="stroke"
    >
      {piece.label}
    </text>
  );
}
