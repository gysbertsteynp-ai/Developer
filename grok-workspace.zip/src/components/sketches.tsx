import type { ReactNode } from "react";

import { miterAngles } from "@/lib/patterns/elbow.ts";

function Frame({ children, label }: { children: ReactNode; label: string }) {
  return (
    <figure className="rounded-md border border-line bg-ink px-3 py-2">
      <figcaption className="mb-1 text-xs tracking-wide text-mist">{label}</figcaption>
      <svg viewBox="0 0 160 72" className="h-16 w-full" aria-hidden="true">
        {children}
      </svg>
    </figure>
  );
}

const stroke = { fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinejoin: "round" as const };

export function CylinderSketch() {
  return (
    <Frame label="Side of the shell">
      <g className="text-brass" {...stroke}>
        <rect x="28" y="16" width="104" height="36" rx="18" />
        <line x1="28" y1="16" x2="28" y2="52" />
        <line x1="132" y1="16" x2="132" y2="52" />
      </g>
      <g className="text-mist" stroke="currentColor" strokeWidth="1">
        <line x1="18" y1="16" x2="18" y2="52" />
        <line x1="14" y1="16" x2="22" y2="16" />
        <line x1="14" y1="52" x2="22" y2="52" />
        <line x1="28" y1="62" x2="132" y2="62" />
        <line x1="28" y1="58" x2="28" y2="66" />
        <line x1="132" y1="58" x2="132" y2="66" />
      </g>
    </Frame>
  );
}

export function ConeSketch({ large, small }: { large: number; small: number }) {
  const big = Math.max(large, small, 1);
  const top = 18 + (1 - Math.min(small, big) / big) * 22;
  const bot = 54;
  return (
    <Frame label="Elevation, either end up">
      <g className="text-brass" {...stroke}>
        <path d={`M46 ${bot} L64 ${top} L96 ${top} L114 ${bot} Z`} />
      </g>
      <g className="text-mist" stroke="currentColor" strokeWidth="1">
        <line x1="46" y1={bot + 8} x2="114" y2={bot + 8} />
        <line x1="78" y1={top} x2="78" y2={bot} strokeDasharray="3 3" />
      </g>
    </Frame>
  );
}

export function AugerSketch() {
  return (
    <Frame label="One pitch of flight">
      <g className="text-brass" {...stroke}>
        <circle cx="80" cy="36" r="24" />
        <circle cx="80" cy="36" r="8" />
        <path d="M80 12 L92 36 L80 60" />
      </g>
      <g className="text-mist" stroke="currentColor" strokeWidth="1">
        <line x1="112" y1="20" x2="112" y2="52" />
        <line x1="108" y1="20" x2="116" y2="20" />
        <line x1="108" y1="52" x2="116" y2="52" />
      </g>
    </Frame>
  );
}

export function TransitionSketch() {
  return (
    <Frame label="Concentric base to round">
      <g className="text-brass" {...stroke}>
        <path d="M36 56 H124 L104 20 H56 Z" />
        <path d="M62 20 H98" />
        <path d="M62 20 Q80 12 98 20" />
      </g>
      <line x1="80" y1="18" x2="80" y2="56" className="text-mist" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
    </Frame>
  );
}

export function ElbowSketch({
  angle,
  gores,
  clr,
  radius,
}: {
  angle: number;
  gores: number;
  clr: number;
  radius: number;
}) {
  const safeAngle = Number.isFinite(angle) && angle > 0 && angle <= 180 ? angle : 90;
  const safeGores = Number.isInteger(gores) && gores >= 2 ? gores : 5;
  const safeClr = clr > 0 ? clr : 1;
  const safeR = radius > 0 ? radius : safeClr * 0.4;
  const cx = 28;
  const cy = 64;
  const R = 46;
  const wall = Math.max(5, Math.min(14, (safeR / safeClr) * R));
  const a0 = -Math.PI / 2;
  const sweep = (safeAngle * Math.PI) / 180;
  const a1 = a0 + sweep;
  const large = sweep > Math.PI ? 1 : 0;
  const arc = (radiusLine: number) => {
    const x0 = cx + radiusLine * Math.cos(a0);
    const y0 = cy + radiusLine * Math.sin(a0);
    const x1 = cx + radiusLine * Math.cos(a1);
    const y1 = cy + radiusLine * Math.sin(a1);
    return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${radiusLine} ${radiusLine} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
  };
  const rays = miterAngles(safeAngle, safeGores);

  return (
    <Frame label="Mitres around the centerline">
      <g className="text-brass" fill="none" stroke="currentColor" strokeWidth="1.6">
        <path d={arc(R - wall)} />
        <path d={arc(R + wall)} />
      </g>
      <path d={arc(R)} className="text-mist" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
      {rays.map((deg) => {
        const a = a0 + (deg * Math.PI) / 180;
        const x0 = cx + (R - wall) * Math.cos(a);
        const y0 = cy + (R - wall) * Math.sin(a);
        const x1 = cx + (R + wall) * Math.cos(a);
        const y1 = cy + (R + wall) * Math.sin(a);
        return (
          <line
            key={deg}
            x1={x0}
            y1={y0}
            x2={x1}
            y2={y1}
            className="text-dim"
            stroke="currentColor"
            strokeWidth="1.2"
          />
        );
      })}
    </Frame>
  );
}
