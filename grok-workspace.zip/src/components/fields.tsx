import { useId, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Field({
  label,
  value,
  onChange,
  suffix,
  hint,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  suffix?: string;
  hint?: string;
}) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium tracking-wide text-mist">
        {label}
      </label>
      <div className="relative">
        <input
          id={id}
          inputMode="decimal"
          autoComplete="off"
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className={cn(
            "h-11 w-full rounded-md border border-line bg-ink px-3 font-sans text-base text-fg tabular-nums outline-none transition-colors duration-200 focus:border-brass",
            suffix ? "pr-12" : "",
          )}
        />
        {suffix ? (
          <span className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-xs text-mist">
            {suffix}
          </span>
        ) : null}
      </div>
      {hint ? <p className="mt-1 text-xs leading-snug text-mist">{hint}</p> : null}
    </div>
  );
}

export function SelectField({
  label,
  value,
  onChange,
  children,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: ReactNode;
}) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium tracking-wide text-mist">
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="h-11 w-full rounded-md border border-line bg-ink px-3 text-base text-fg outline-none transition-colors duration-200 focus:border-brass"
      >
        {children}
      </select>
    </div>
  );
}

export function Segmented<T extends string>({
  label,
  value,
  options,
  onChange,
  hideLabel = false,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (value: T) => void;
  hideLabel?: boolean;
}) {
  return (
    <div>
      {hideLabel ? null : <p className="mb-1.5 text-xs font-medium tracking-wide text-mist">{label}</p>}
      <div
        role="group"
        aria-label={label}
        className={cn(
          "grid gap-1 rounded-md border border-line bg-ink p-1",
          options.length === 3 ? "grid-cols-3" : options.length === 4 ? "grid-cols-4" : "grid-cols-2",
        )}
      >
        {options.map((option) => {
          const on = option.value === value;
          return (
            <button
              key={option.value}
              type="button"
              aria-pressed={on}
              onClick={() => onChange(option.value)}
              className={cn(
                "h-11 rounded-sm px-2 text-sm font-medium transition-colors duration-200",
                on ? "bg-brass text-brass-ink" : "text-mist hover:text-fg",
              )}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
