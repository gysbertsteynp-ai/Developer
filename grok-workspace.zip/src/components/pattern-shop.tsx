import { useEffect, useMemo, useState } from "react";
import { Copy, Download, Printer, RotateCcw } from "lucide-react";
import { Field, Segmented, SelectField } from "@/components/fields";
import { LayoutSheet } from "@/components/layout-sheet";
import { AugerSketch, ConeSketch, CylinderSketch, ElbowSketch, TransitionSketch } from "@/components/sketches";
import { Button } from "@/components/ui/button";
import { buildDxf } from "@/lib/patterns/dxf";
import {
  convertUnits,
  DEFAULT_STATE,
  evaluate,
  mergeSaved,
  readNumber,
  type ElbowFields,
  type ShopState,
  type TabId,
} from "@/lib/patterns/evaluate";
import { MATERIALS } from "@/lib/patterns/format";
import { tileGroups } from "@/lib/patterns/geometry";
import { buildSvg } from "@/lib/patterns/svg";
import type { Basis, Pattern } from "@/lib/patterns/types";

const STORAGE_KEY = "pattern-shop-v1";

const TABS: { id: TabId; label: string }[] = [
  { id: "cylinder", label: "Pipe" },
  { id: "cone", label: "Cone" },
  { id: "auger", label: "Auger" },
  { id: "transition", label: "Transition" },
  { id: "elbow", label: "Elbow" },
];

const HOW: Record<TabId, { title: string; body: string }> = {
  cylinder: {
    title: "How the pipe blank is figured",
    body: "Stretch-out is the neutral circumference, π × Dn, plus any lap you add for the long seam. Dn sits at fraction k of the wall, measured from the inside — 0.50 is mid-plate. The axial length does not stretch. A max course length splits the shell into equal rings.",
  },
  cone: {
    title: "How the cone blank is figured",
    body: "Both ends become neutral circles. Slant height is the true length along the plate. Outer radius = large radius × slant ÷ (large − small). Sweep = (large circumference ÷ pieces + one lap) ÷ outer radius. A zero small end is a true cone and the blank runs to the apex.",
  },
  auger: {
    title: "How the flight blank is figured",
    body: "A flight is flat plate wrapped into a helix, not a rolled shell, so thickness does not change the blank. Each edge keeps its helical length, √((πD)² + pitch²). The sector width is (OD − ID) ÷ 2. The gap is what you cut out of the ring. One blank is one pitch.",
  },
  transition: {
    title: "How the transition is figured",
    body: "Concentric rectangle-to-round, or a square when the two sides match. The round is split into equal arc steps and each step is a triangle back to a corner. A half is seamed on the center of the sides you pick, and you cut two of them. Dashed lines are for laying out by hand — they stay off the cut unless you include layer FOLD.",
  },
  elbow: {
    title: "How the lobsterback is figured",
    body: "These are straight pipe gores mitred together, not a smooth bent tube. End gores are half the angle of a middle gore. The length of each generator is (centerline radius ± neutral radius) × tan(half-angle). The curved edge is the unrolled miter. The straight edge on an end gore welds to straight pipe.",
  },
};

function ticket(pattern: Pattern, mark: string): string {
  const lines = [
    ...(mark.trim() ? [`Mark: ${mark.trim()}`, ""] : []),
    ...pattern.stats.map((stat) => `${stat.label}: ${stat.value}`),
    "",
    ...pattern.notes,
  ];
  if (pattern.trueLengths?.length) {
    lines.push("", "True lengths");
    for (const row of pattern.trueLengths) lines.push(`${row.label}: ${row.value}`);
  }
  return lines.join("\n");
}

function fileSlug(mark: string, tab: string): string {
  const cleaned = mark
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return cleaned ? `${cleaned}-${tab}` : tab;
}

function download(filename: string, text: string, type: string) {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function rectangularBase(length: string, width: string): boolean {
  const L = readNumber(length);
  const W = readNumber(width);
  if (L === null || W === null) return false;
  return Math.abs(L - W) > Math.max(Math.abs(L), Math.abs(W), 1) * 1e-4;
}

export function PatternShop() {
  const [state, setState] = useState<ShopState>(DEFAULT_STATE);
  const [ready, setReady] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setState(mergeSaved(JSON.parse(raw)));
    } catch {
      /* keep the defaults */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state, ready]);

  const result = useMemo(() => evaluate(state), [state]);
  const pattern = result.ok ? result.pattern : null;
  const error = result.ok ? null : result.error;
  const unit = state.unit;

  const setTab = <K extends TabId>(tab: K, patch: Partial<ShopState[K]>) => {
    setState((current) => ({ ...current, [tab]: { ...current[tab], ...patch } }));
  };

  const exportDxf = () => {
    if (!pattern) return;
    const comment = ["Pattern Shop", state.mark.trim(), state.tab, ...pattern.stats.map((stat) => `${stat.label}: ${stat.value}`)]
      .filter(Boolean)
      .join(" | ")
      .slice(0, 240);
    const dxf = buildDxf({
      groups: pattern.exportGroups,
      unit,
      comment,
      includeFolds: state.tab === "transition" && state.transition.folds,
      gap: unit === "mm" ? 25 : 1,
    });
    download(`${fileSlug(state.mark, state.tab)}.dxf`, dxf, "application/dxf");
  };

  const exportSvg = () => {
    if (!pattern) return;
    const gap = unit === "mm" ? 25 : 1;
    const svg = buildSvg({
      pieces: tileGroups(pattern.exportGroups, gap),
      unit,
      title: [state.mark.trim(), state.tab].filter(Boolean).join(" "),
      includeFolds: state.tab === "transition" && state.transition.folds,
    });
    download(`${fileSlug(state.mark, state.tab)}.svg`, svg, "image/svg+xml");
  };

  const copyTicket = async () => {
    if (!pattern) return;
    const text = ticket(pattern, state.mark);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  const printSvg = useMemo(() => {
    if (!pattern) return "";
    return buildSvg({
      pieces: pattern.display,
      unit,
      title: [state.mark.trim() || "Pattern Shop", state.tab].filter(Boolean).join(" "),
      includeFolds: true,
    });
  }, [pattern, unit, state.mark, state.tab]);

  return (
    <div className="min-h-screen bg-ink text-fg">
      <article className="ticket-print">
        <p className="font-display text-3xl leading-none tracking-wide">Pattern Shop</p>
        <p className="mt-1 text-sm">
          {[state.mark.trim(), TABS.find((tab) => tab.id === state.tab)?.label, unit].filter(Boolean).join(" · ")}
        </p>
        {pattern ? (
          <>
            <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-1 text-sm">
              {pattern.stats.map((stat) => (
                <div key={stat.label} className="flex justify-between gap-3 border-b border-sheet-grid py-1">
                  <dt>{stat.label}</dt>
                  <dd className="text-right font-medium tabular-nums">{stat.value}</dd>
                </div>
              ))}
            </dl>
            <div className="ticket-drawing mt-4" dangerouslySetInnerHTML={{ __html: printSvg }} />
            <ul className="mt-4 space-y-1 text-sm">
              {pattern.notes.map((note) => (
                <li key={note}>{note}</li>
              ))}
            </ul>
          </>
        ) : (
          <p className="mt-4 text-sm">{error}</p>
        )}
      </article>

      <div className="app-screen">
      <header className="border-b border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div className="flex items-center gap-3">
            <Mark />
            <div>
              <h1 className="font-display text-4xl leading-none tracking-wide text-fg">Pattern Shop</h1>
              <p className="text-sm text-mist">Flat patterns for plate and pipe</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="w-36 shrink-0">
              <Segmented
                label="Units"
                hideLabel
                value={unit}
                options={[
                  { value: "mm", label: "mm" },
                  { value: "in", label: "inch" },
                ]}
                onChange={(next) => setState((current) => convertUnits(current, next))}
              />
            </div>
            <Button variant="line" onClick={exportSvg} disabled={!pattern}>
              SVG
            </Button>
            <Button onClick={exportDxf} disabled={!pattern}>
              <Download className="size-4" aria-hidden="true" />
              Export DXF
            </Button>
          </div>
        </div>
      </header>

      <div className="border-b border-line">
        <div className="mx-auto max-w-6xl overflow-x-auto px-4 sm:px-6" role="tablist" aria-label="Pattern">
          <div className="flex min-w-max gap-1">
            {TABS.map((tab) => {
              const on = state.tab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  onClick={() => setState((current) => ({ ...current, tab: tab.id }))}
                  className={
                    on
                      ? "h-11 border-b-2 border-brass px-3 text-sm font-semibold text-brass"
                      : "h-11 border-b-2 border-transparent px-3 text-sm font-semibold text-mist hover:text-fg"
                  }
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <main className="mx-auto grid max-w-6xl gap-6 px-4 py-5 sm:px-6 lg:grid-cols-12 lg:gap-8 lg:py-6">
        <section className="space-y-4 lg:col-span-5">
          <Field
            label="Job mark"
            value={state.mark}
            hint="Stamped on the printout and written into the file."
            onChange={(mark) => setState((current) => ({ ...current, mark: mark.slice(0, 40) }))}
          />
          <JobForm state={state} setTab={setTab} />
          <div className="grid gap-3 sm:grid-cols-2">
            <Field
              label="Neutral axis, k"
              value={state.kFactor}
              suffix="k"
              hint="0.50 is mid-plate. Lower moves the axis toward the inside."
              onChange={(kFactor) => setState((current) => ({ ...current, kFactor }))}
            />
            <SelectField
              label="Metal, for weight"
              value={state.material}
              onChange={(material) =>
                setState((current) => ({
                  ...current,
                  material: material === "ss" || material === "alu" ? material : "mild",
                }))
              }
            >
              {MATERIALS.map((material) => (
                <option key={material.id} value={material.id}>
                  {material.name}
                </option>
              ))}
            </SelectField>
          </div>

          {pattern ? (
            <div aria-live="polite">
              <div className="grid grid-cols-2 gap-3">
                {pattern.stats
                  .filter((stat) => stat.hero)
                  .map((stat) => (
                    <div key={stat.label} className="rounded-md border border-line bg-panel px-3 py-3">
                      <p className="text-xs tracking-wide text-mist">{stat.label}</p>
                      <p className="mt-1 font-display text-2xl leading-none text-brass tabular-nums sm:text-3xl">
                        {stat.value}
                      </p>
                    </div>
                  ))}
              </div>
              <dl className="mt-3 divide-y divide-line rounded-md border border-line">
                {pattern.stats
                  .filter((stat) => !stat.hero)
                  .map((stat) => (
                    <div key={stat.label} className="flex items-baseline justify-between gap-3 px-3 py-2">
                      <dt className="text-sm text-mist">{stat.label}</dt>
                      <dd className="text-right text-sm font-medium text-fg tabular-nums">{stat.value}</dd>
                    </div>
                  ))}
              </dl>
              {pattern.trueLengths ? (
                <details className="mt-3 rounded-md border border-line px-3 py-2">
                  <summary className="text-sm font-medium text-fg">True lengths</summary>
                  <dl className="mt-2 space-y-1">
                    {pattern.trueLengths.map((row) => (
                      <div key={row.label} className="flex justify-between gap-3 text-sm">
                        <dt className="text-mist">{row.label}</dt>
                        <dd className="tabular-nums text-fg">{row.value}</dd>
                      </div>
                    ))}
                  </dl>
                </details>
              ) : null}
              <ul className="mt-4 space-y-2">
                {pattern.notes.map((note) => (
                  <li key={note} className="flex gap-2 text-sm leading-snug text-mist">
                    <span className="mt-1.5 size-1 shrink-0 rounded-full bg-brass" aria-hidden="true" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button variant="line" onClick={copyTicket}>
                  <Copy className="size-4" aria-hidden="true" />
                  {copied ? "Copied" : "Copy ticket"}
                </Button>
                <Button variant="line" onClick={() => window.print()}>
                  <Printer className="size-4" aria-hidden="true" />
                  Print
                </Button>
                <Button
                  variant="ghost"
                  onClick={() =>
                    setState((current) => ({
                      ...current,
                      [current.tab]: DEFAULT_STATE[current.tab],
                    }))
                  }
                >
                  <RotateCcw className="size-4" aria-hidden="true" />
                  Reset
                </Button>
              </div>
            </div>
          ) : (
            <p className="rounded-md border border-rust/40 bg-rust/10 px-3 py-3 text-sm text-fg" role="alert">
              {error}
            </p>
          )}
        </section>

        <section className="lg:col-span-7">
          <LayoutSheet pattern={pattern} error={error} resetKey={`${state.tab}:${pattern ? "ok" : error}`} />
          <details className="mt-4 rounded-md border border-line px-4 py-3">
            <summary className="text-sm font-medium text-fg">{HOW[state.tab].title}</summary>
            <p className="mt-2 text-sm leading-relaxed text-mist">{HOW[state.tab].body}</p>
          </details>
          <p className="mt-3 text-xs leading-relaxed text-mist">
            Layouts are the neutral surface, full size, in the units on the ticket. They are a marking aid, not a
            checked shop drawing — tape the first piece before you cut the batch.
          </p>
        </section>
      </main>
      </div>
    </div>
  );
}

function Mark() {
  return (
    <svg viewBox="0 0 36 36" className="size-11 shrink-0" aria-hidden="true">
      <rect width="36" height="36" rx="6" className="fill-panel stroke-line" strokeWidth="1" />
      <path d="M18 30 7 16.5A13 13 0 0 1 29 16.5L18 30Z" className="stroke-brass" fill="none" strokeWidth="1.6" />
      <path d="M18 22.5 11.5 16.8a7 7 0 0 1 13 0L18 22.5Z" className="stroke-brass" fill="none" strokeWidth="1.6" />
    </svg>
  );
}

function BasisField({ value, onChange }: { value: Basis; onChange: (basis: Basis) => void }) {
  return (
    <Segmented
      label="Diameters are"
      value={value}
      onChange={onChange}
      options={[
        { value: "outside", label: "Outside" },
        { value: "inside", label: "Inside" },
      ]}
    />
  );
}

function JobForm({
  state,
  setTab,
}: {
  state: ShopState;
  setTab: <K extends TabId>(tab: K, patch: Partial<ShopState[K]>) => void;
}) {
  const unit = state.unit;

  if (state.tab === "cylinder") {
    const f = state.cylinder;
    return (
      <div className="space-y-3">
        <CylinderSketch />
        <BasisField value={f.basis} onChange={(basis) => setTab("cylinder", { basis })} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Diameter" suffix={unit} value={f.diameter} onChange={(diameter) => setTab("cylinder", { diameter })} />
          <Field label="Axial length" suffix={unit} value={f.length} onChange={(length) => setTab("cylinder", { length })} />
          <Field label="Thickness" suffix={unit} value={f.thickness} onChange={(thickness) => setTab("cylinder", { thickness })} />
          <Field
            label="Seam allowance"
            suffix={unit}
            value={f.allowance}
            hint="Added once, on the stretch-out."
            onChange={(allowance) => setTab("cylinder", { allowance })}
          />
          <div className="col-span-2">
            <Field
              label="Max length per course"
              suffix={unit}
              value={f.plateWidth}
              hint="Blank for one piece. Splits the axis into equal rings."
              onChange={(plateWidth) => setTab("cylinder", { plateWidth })}
            />
          </div>
        </div>
      </div>
    );
  }

  if (state.tab === "cone") {
    const f = state.cone;
    return (
      <div className="space-y-3">
        <ConeSketch large={readNumber(f.large) ?? 1} small={readNumber(f.small) ?? 0} />
        <BasisField value={f.basis} onChange={(basis) => setTab("cone", { basis })} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Large end" suffix={unit} value={f.large} onChange={(large) => setTab("cone", { large })} />
          <Field label="Small end" suffix={unit} value={f.small} hint="Zero for a true cone." onChange={(small) => setTab("cone", { small })} />
          <Field label="Vertical height" suffix={unit} value={f.height} onChange={(height) => setTab("cone", { height })} />
          <Field label="Thickness" suffix={unit} value={f.thickness} onChange={(thickness) => setTab("cone", { thickness })} />
          <Field label="Seam allowance" suffix={unit} value={f.allowance} hint="Added to each piece." onChange={(allowance) => setTab("cone", { allowance })} />
          <SelectField label="Pieces" value={f.pieces} onChange={(pieces) => setTab("cone", { pieces })}>
            {["1", "2", "3", "4", "6"].map((n) => (
              <option key={n} value={n}>
                {n === "1" ? "1 — full" : n}
              </option>
            ))}
          </SelectField>
        </div>
      </div>
    );
  }

  if (state.tab === "auger") {
    const f = state.auger;
    return (
      <div className="space-y-3">
        <AugerSketch />
        <p className="text-sm text-mist">Outside diameter and shaft hole are the finished flight. Thickness is weight only.</p>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Outside diameter" suffix={unit} value={f.od} onChange={(od) => setTab("auger", { od })} />
          <Field label="Shaft hole" suffix={unit} value={f.id} onChange={(id) => setTab("auger", { id })} />
          <Field label="Pitch" suffix={unit} value={f.pitch} hint="Advance in one turn." onChange={(pitch) => setTab("auger", { pitch })} />
          <Field label="Thickness" suffix={unit} value={f.thickness} onChange={(thickness) => setTab("auger", { thickness })} />
          <div className="col-span-2">
            <Field label="Flights to cut" value={f.flights} onChange={(flights) => setTab("auger", { flights })} />
          </div>
        </div>
      </div>
    );
  }

  if (state.tab === "transition") {
    const f = state.transition;
    return (
      <div className="space-y-3">
        <TransitionSketch />
        <BasisField value={f.basis} onChange={(basis) => setTab("transition", { basis })} />
        <Segmented
          label={rectangularBase(f.length, f.width) ? "Half seam through" : "Piece"}
          value={rectangularBase(f.length, f.width) && f.part === "quarter" ? "half" : f.part}
          onChange={(part) => setTab("transition", { part })}
          options={
            rectangularBase(f.length, f.width)
              ? [
                  { value: "half", label: "Lengths" },
                  { value: "half-cross", label: "Widths" },
                  { value: "full", label: "One piece" },
                ]
              : [
                  { value: "quarter", label: "Quarter" },
                  { value: "half", label: "Half" },
                  { value: "full", label: "Full" },
                ]
          }
        />
        <p className="text-xs leading-snug text-mist">
          {rectangularBase(f.length, f.width)
            ? "Two identical halves. The seam runs through the middle of the sides you pick. One piece is the whole fitting."
            : "Equal sides are a square. Quarter and half patterns are cut on the side centers."}
        </p>
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="Base length"
            suffix={unit}
            value={f.length}
            onChange={(length) =>
              setTab("transition", {
                length,
                ...(rectangularBase(length, f.width) && f.part === "quarter" ? { part: "half" as const } : {}),
              })
            }
          />
          <Field
            label="Base width"
            suffix={unit}
            value={f.width}
            hint="Match the length for a square."
            onChange={(width) =>
              setTab("transition", {
                width,
                ...(rectangularBase(f.length, width) && f.part === "quarter" ? { part: "half" as const } : {}),
              })
            }
          />
          <Field label="Round diameter" suffix={unit} value={f.round} onChange={(round) => setTab("transition", { round })} />
          <Field label="Vertical height" suffix={unit} value={f.height} onChange={(height) => setTab("transition", { height })} />
          <Field label="Thickness" suffix={unit} value={f.thickness} onChange={(thickness) => setTab("transition", { thickness })} />
          <SelectField label="Arc steps per quarter" value={f.segments} onChange={(segments) => setTab("transition", { segments })}>
            {["6", "8", "12", "16", "24"].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </SelectField>
        </div>
        <label className="flex min-h-11 items-start gap-3 text-sm text-fg">
          <input
            type="checkbox"
            className="mt-1 size-4 accent-brass"
            checked={f.folds}
            onChange={(event) => setTab("transition", { folds: event.target.checked })}
          />
          <span>Include layout lines in the export. On a DXF they sit on layer FOLD — leave that layer off the cutter.</span>
        </label>
      </div>
    );
  }

  const f: ElbowFields = state.elbow;
  return (
    <div className="space-y-3">
      <ElbowSketch
        angle={readNumber(f.angle) ?? 90}
        gores={readNumber(f.gores) ?? 5}
        clr={readNumber(f.clr) ?? 1}
        radius={(readNumber(f.diameter) ?? 1) / 2}
      />
      <BasisField value={f.basis} onChange={(basis) => setTab("elbow", { basis })} />
      <Segmented
        label="Long seam"
        value={f.seam}
        onChange={(seam) => setTab("elbow", { seam })}
        options={[
          { value: "throat", label: "Throat" },
          { value: "cheek", label: "Cheek" },
          { value: "back", label: "Back" },
        ]}
      />
      <div className="grid grid-cols-2 gap-3">
        <Field label="Pipe diameter" suffix={unit} value={f.diameter} onChange={(diameter) => setTab("elbow", { diameter })} />
        <Field label="Centerline radius" suffix={unit} value={f.clr} onChange={(clr) => setTab("elbow", { clr })} />
        <Field label="Bend angle" suffix="°" value={f.angle} onChange={(angle) => setTab("elbow", { angle })} />
        <SelectField label="Gores" value={f.gores} onChange={(gores) => setTab("elbow", { gores })}>
          {["2", "3", "4", "5", "6", "7", "8"].map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </SelectField>
        <Field label="Thickness" suffix={unit} value={f.thickness} onChange={(thickness) => setTab("elbow", { thickness })} />
        <Field
          label="Seam allowance"
          suffix={unit}
          value={f.allowance}
          hint="Lap along the long seam."
          onChange={(allowance) => setTab("elbow", { allowance })}
        />
      </div>
    </div>
  );
}
