import { createFileRoute } from "@tanstack/react-router";
import { PatternShop } from "@/components/pattern-shop";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PatternShop />;
}
