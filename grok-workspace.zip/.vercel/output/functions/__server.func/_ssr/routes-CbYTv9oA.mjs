import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Printer, c as Copy, i as RotateCcw, n as ZoomOut, o as LocateFixed, s as Download, t as ZoomIn } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CbYTv9oA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Field({ label, value, onChange, suffix, hint }) {
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			htmlFor: id,
			className: "mb-1.5 block text-xs font-medium tracking-wide text-mist",
			children: label
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				inputMode: "decimal",
				autoComplete: "off",
				value,
				onChange: (event) => onChange(event.target.value),
				className: cn("h-11 w-full rounded-md border border-line bg-ink px-3 font-sans text-base text-fg tabular-nums outline-none transition-colors duration-200 focus:border-brass", suffix ? "pr-12" : "")
			}), suffix ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-xs text-mist",
				children: suffix
			}) : null]
		}),
		hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs leading-snug text-mist",
			children: hint
		}) : null
	] });
}
function SelectField({ label, value, onChange, children }) {
	const id = (0, import_react.useId)();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor: id,
		className: "mb-1.5 block text-xs font-medium tracking-wide text-mist",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		id,
		value,
		onChange: (event) => onChange(event.target.value),
		className: "h-11 w-full rounded-md border border-line bg-ink px-3 text-base text-fg outline-none transition-colors duration-200 focus:border-brass",
		children
	})] });
}
function Segmented({ label, value, options, onChange, hideLabel = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [hideLabel ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-1.5 text-xs font-medium tracking-wide text-mist",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"aria-label": label,
		className: cn("grid gap-1 rounded-md border border-line bg-ink p-1", options.length === 3 ? "grid-cols-3" : options.length === 4 ? "grid-cols-4" : "grid-cols-2"),
		children: options.map((option) => {
			const on = option.value === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-pressed": on,
				onClick: () => onChange(option.value),
				className: cn("h-11 rounded-sm px-2 text-sm font-medium transition-colors duration-200", on ? "bg-brass text-brass-ink" : "text-mist hover:text-fg"),
				children: option.label
			}, option.value);
		})
	})] });
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-md font-semibold transition-colors duration-200 disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			brass: "bg-brass text-brass-ink hover:bg-brass/90",
			line: "border border-line bg-panel text-fg hover:border-brass",
			ghost: "bg-transparent text-mist hover:bg-panel-2 hover:text-fg"
		},
		size: {
			md: "h-11 px-4 text-sm",
			sm: "h-9 px-3 text-xs"
		}
	},
	defaultVariants: {
		variant: "brass",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function pointsOf(pattern) {
	const pts = [];
	for (const piece of pattern.display) {
		pts.push(...piece.outline);
		for (const [a, b] of piece.folds ?? []) pts.push(a, b);
	}
	for (const guide of pattern.guides) pts.push({
		x: guide.x1,
		y: guide.y1
	}, {
		x: guide.x2,
		y: guide.y2
	}, {
		x: guide.lx,
		y: guide.ly
	});
	return pts;
}
function LayoutSheet({ pattern, error, resetKey }) {
	const stageRef = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(null);
	const [zoom, setZoom] = (0, import_react.useState)(1);
	const [pan, setPan] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	(0, import_react.useEffect)(() => {
		setZoom(1);
		setPan({
			x: 0,
			y: 0
		});
	}, [resetKey]);
	(0, import_react.useEffect)(() => {
		const el = stageRef.current;
		if (!el) return;
		const onWheel = (event) => {
			event.preventDefault();
			const factor = event.deltaY > 0 ? .92 : 1.08;
			setZoom((value) => Math.min(8, Math.max(.6, value * factor)));
		};
		el.addEventListener("wheel", onWheel, { passive: false });
		return () => el.removeEventListener("wheel", onWheel);
	}, []);
	const view = (0, import_react.useMemo)(() => {
		if (!pattern) return null;
		const pts = pointsOf(pattern);
		if (pts.length === 0) return null;
		let minX = Infinity;
		let minY = Infinity;
		let maxX = -Infinity;
		let maxY = -Infinity;
		for (const point of pts) {
			const x = point.x;
			const y = -point.y;
			if (x < minX) minX = x;
			if (y < minY) minY = y;
			if (x > maxX) maxX = x;
			if (y > maxY) maxY = y;
		}
		const width = Math.max(maxX - minX, 1);
		const height = Math.max(maxY - minY, 1);
		const span = Math.max(width, height);
		const fontSize = Math.min(width, height) * .055;
		const pad = span * .14 + fontSize * 2;
		return {
			viewBox: `${minX - pad} ${minY - pad} ${width + pad * 2} ${height + pad * 2}`,
			fontSize
		};
	}, [pattern]);
	const fit = () => {
		setZoom(1);
		setPan({
			x: 0,
			y: 0
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "layout-sheet relative overflow-hidden rounded-md border border-line",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute top-3 right-3 left-3 z-10 flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-sm bg-sheet/90 px-2 py-1 text-xs font-medium tracking-wide text-sheet-ink",
					children: "Full-size geometry"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "line",
							size: "sm",
							"aria-label": "Zoom out",
							onClick: () => setZoom((z) => Math.max(.6, z / 1.2)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, {
								className: "size-4",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "line",
							size: "sm",
							"aria-label": "Zoom in",
							onClick: () => setZoom((z) => Math.min(8, z * 1.2)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, {
								className: "size-4",
								"aria-hidden": "true"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "line",
							size: "sm",
							"aria-label": "Fit pattern",
							onClick: fit,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, {
								className: "size-4",
								"aria-hidden": "true"
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: stageRef,
				className: "sheet-stage h-full w-full cursor-grab active:cursor-grabbing",
				onPointerDown: (event) => {
					if (event.button !== 0) return;
					event.currentTarget.setPointerCapture(event.pointerId);
					drag.current = {
						x: event.clientX,
						y: event.clientY,
						px: pan.x,
						py: pan.y
					};
				},
				onPointerMove: (event) => {
					if (!drag.current) return;
					setPan({
						x: drag.current.px + (event.clientX - drag.current.x),
						y: drag.current.py + (event.clientY - drag.current.y)
					});
				},
				onPointerUp: () => {
					drag.current = null;
				},
				onPointerCancel: () => {
					drag.current = null;
				},
				children: pattern && view ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: view.viewBox,
					preserveAspectRatio: "xMidYMid meet",
					role: "img",
					"aria-label": "Flat pattern layout",
					className: "h-full w-full",
					style: {
						transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
						transformOrigin: "center"
					},
					children: [pattern.display.map((piece, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
							points: piece.outline.map((point) => `${point.x},${-point.y}`).join(" "),
							className: "fill-sheet-ink/10 stroke-cut",
							strokeWidth: 1.75,
							strokeLinejoin: "round",
							vectorEffect: "non-scaling-stroke"
						}),
						piece.folds?.map(([a, b], foldIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: a.x,
							y1: -a.y,
							x2: b.x,
							y2: -b.y,
							className: "stroke-fold",
							strokeWidth: 1.25,
							strokeDasharray: "5 4",
							vectorEffect: "non-scaling-stroke"
						}, foldIndex)),
						piece.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PieceLabel, {
							piece,
							fontSize: view.fontSize
						}) : null
					] }, piece.label ?? index)), pattern.guides.map((guide) => {
						const x1 = guide.x1;
						const y1 = -guide.y1;
						const x2 = guide.x2;
						const y2 = -guide.y2;
						const verticalLine = Math.abs(guide.y2 - guide.y1) > Math.abs(guide.x2 - guide.x1);
						const tick = view.fontSize * .28;
						const lx = guide.lx;
						const ly = -guide.ly;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1,
								y1,
								x2,
								y2,
								className: "stroke-dim",
								strokeWidth: 1.25,
								vectorEffect: "non-scaling-stroke"
							}),
							verticalLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: x1 - tick,
								y1,
								x2: x1 + tick,
								y2: y1,
								className: "stroke-dim",
								strokeWidth: 1.25,
								vectorEffect: "non-scaling-stroke"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: x2 - tick,
								y1: y2,
								x2: x2 + tick,
								y2,
								className: "stroke-dim",
								strokeWidth: 1.25,
								vectorEffect: "non-scaling-stroke"
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1,
								y1: y1 - tick,
								x2: x1,
								y2: y1 + tick,
								className: "stroke-dim",
								strokeWidth: 1.25,
								vectorEffect: "non-scaling-stroke"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: x2,
								y1: y2 - tick,
								x2,
								y2: y2 + tick,
								className: "stroke-dim",
								strokeWidth: 1.25,
								vectorEffect: "non-scaling-stroke"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x: lx,
								y: ly,
								textAnchor: "middle",
								dominantBaseline: "middle",
								transform: guide.along === "y" ? `rotate(-90 ${lx} ${ly})` : void 0,
								fontSize: view.fontSize * .72,
								className: "font-sans",
								fill: "var(--color-dim)",
								stroke: "var(--color-sheet)",
								strokeWidth: view.fontSize * .18,
								paintOrder: "stroke",
								children: guide.label
							})
						] }, guide.label);
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full items-center justify-center px-8 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm text-dim",
						children: error ?? "Enter the sizes to lay out the blank."
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute right-3 bottom-3 left-3 flex items-end justify-between gap-3 text-xs text-sheet-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-sm bg-sheet/90 px-2 py-1",
					children: ["Solid line cuts. ", pattern?.display.some((piece) => piece.folds?.length) ? "Blue dashes are layout lines, not cuts." : "Drag to pan. Scroll to zoom."]
				})
			}),
			error && pattern ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute right-3 bottom-12 left-3 rounded-sm bg-sheet/95 px-3 py-2 text-sm text-dim",
				children: error
			}) : null
		]
	});
}
function PieceLabel({ piece, fontSize }) {
	let minX = Infinity;
	let maxX = -Infinity;
	let minY = Infinity;
	let maxY = -Infinity;
	for (const point of piece.outline) {
		if (point.x < minX) minX = point.x;
		if (point.x > maxX) maxX = point.x;
		if (point.y < minY) minY = point.y;
		if (point.y > maxY) maxY = point.y;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
		x: (minX + maxX) / 2,
		y: -((minY + maxY) / 2),
		textAnchor: "middle",
		dominantBaseline: "middle",
		fontSize: fontSize * .8,
		className: "font-display",
		fill: "var(--color-sheet-ink)",
		stroke: "var(--color-sheet)",
		strokeWidth: fontSize * .22,
		paintOrder: "stroke",
		children: piece.label
	});
}
function shoelace(pts) {
	let sum = 0;
	for (let i = 0; i < pts.length; i++) {
		const a = pts[i];
		const b = pts[(i + 1) % pts.length];
		sum += a.x * b.y - b.x * a.y;
	}
	return Math.abs(sum) / 2;
}
function bboxOf(pts) {
	let minX = Infinity;
	let minY = Infinity;
	let maxX = -Infinity;
	let maxY = -Infinity;
	for (const p of pts) {
		if (p.x < minX) minX = p.x;
		if (p.y < minY) minY = p.y;
		if (p.x > maxX) maxX = p.x;
		if (p.y > maxY) maxY = p.y;
	}
	return {
		minX,
		minY,
		maxX,
		maxY
	};
}
function sectorOutline(sector) {
	const { cx, cy, innerR, outerR, startDeg, sweepDeg } = sector;
	const steps = Math.max(24, Math.ceil(Math.abs(sweepDeg) / 2.5));
	const start = startDeg * Math.PI / 180;
	const sweep = sweepDeg * Math.PI / 180;
	const pts = [];
	const pushArc = (r, from, dir) => {
		if (r < 1e-6) {
			pts.push({
				x: cx,
				y: cy
			});
			return;
		}
		for (let i = 0; i <= steps; i++) {
			const a = from + dir * sweep * (i / steps);
			pts.push({
				x: cx + r * Math.cos(a),
				y: cy + r * Math.sin(a)
			});
		}
	};
	pushArc(outerR, start, 1);
	if (innerR < 1e-6) pts.push({
		x: cx,
		y: cy
	});
	else pushArc(innerR, start + sweep, -1);
	return pts;
}
function translatePiece(piece, dx, dy) {
	const move = (p) => ({
		x: p.x + dx,
		y: p.y + dy
	});
	const sector = piece.sector ? {
		...piece.sector,
		cx: piece.sector.cx + dx,
		cy: piece.sector.cy + dy
	} : void 0;
	return {
		...piece,
		outline: piece.outline.map(move),
		folds: piece.folds?.map(([a, b]) => [move(a), move(b)]),
		sector
	};
}
/** Lay copies in a row, origin at the lower-left of the first piece. Y-up. */
function tileGroups(groups, gap) {
	const out = [];
	let cursor = 0;
	for (const group of groups) for (let i = 0; i < group.count; i++) {
		const box = bboxOf(group.piece.outline);
		const dx = cursor - box.minX;
		const dy = -box.minY;
		out.push(translatePiece(group.piece, dx, dy));
		cursor += box.maxX - box.minX + gap;
	}
	return out;
}
function cross(a, b, c) {
	return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}
/** True when non-adjacent edges properly cross. */
function selfIntersects(pts) {
	const n = pts.length;
	if (n < 4) return false;
	for (let i = 0; i < n; i++) {
		const a = pts[i];
		const b = pts[(i + 1) % n];
		for (let j = i + 1; j < n; j++) {
			if (j === i || (j + 1) % n === i || (i + 1) % n === j || (j + 1) % n === (i + 1) % n) continue;
			if (i === 0 && j === n - 1) continue;
			const c = pts[j];
			const d = pts[(j + 1) % n];
			const c1 = cross(a, b, c);
			const c2 = cross(a, b, d);
			const c3 = cross(c, d, a);
			const c4 = cross(c, d, b);
			if (c1 * c2 < 0 && c3 * c4 < 0) return true;
		}
	}
	return false;
}
function degToRad(d) {
	return d * Math.PI / 180;
}
function decimals(unit) {
	return unit === "mm" ? 2 : 3;
}
function fmt(n, unit, digits) {
	const d = digits ?? decimals(unit);
	return `${n.toLocaleString("en-US", {
		minimumFractionDigits: d,
		maximumFractionDigits: d
	})} ${unit}`;
}
function fmtAngle(deg) {
	return `${deg.toFixed(2)}°`;
}
function massKg(area, thickness, unit, density) {
	return (unit === "mm" ? area * thickness / 1e9 : area * thickness * .0254 ** 3) * density;
}
function fmtMass(kg, unit) {
	if (unit === "in") return `${(kg * 2.2046226218).toFixed(2)} lb`;
	if (kg >= 1e3) return `${(kg / 1e3).toFixed(3)} t`;
	return `${kg.toFixed(2)} kg`;
}
function fmtArea(area, unit) {
	if (unit === "mm") {
		if (area >= 1e6) return `${(area / 1e6).toFixed(3)} m²`;
		return `${Math.round(area).toLocaleString("en-US")} mm²`;
	}
	return `${area.toFixed(2)} in²`;
}
function neutralDiameter(measured, thickness, k, basis) {
	if (basis === "outside") return measured - 2 * (1 - k) * thickness;
	return measured + 2 * k * thickness;
}
var MATERIALS = [
	{
		id: "mild",
		name: "Mild steel",
		density: 7850
	},
	{
		id: "ss",
		name: "Stainless",
		density: 8e3
	},
	{
		id: "alu",
		name: "Aluminum",
		density: 2700
	}
];
function materialById(id) {
	return MATERIALS.find((m) => m.id === id) ?? MATERIALS[0];
}
var STEPS = 72;
function seamShift(seam) {
	if (seam === "back") return 0;
	if (seam === "cheek") return Math.PI / 2;
	return Math.PI;
}
/** Generator length factor (CLR + r cos ψ), ψ measured from the extrados. */
function radiusAt(clr, r, psi) {
	return clr + r * Math.cos(psi);
}
function goreOutline(clr, r, tanBeta, kind, seam, allowance) {
	const shift = seamShift(seam);
	const circ = 2 * Math.PI * r;
	const lenAt = (i) => {
		return radiusAt(clr, r, shift + i / STEPS * Math.PI * 2) * tanBeta * (kind === "middle" ? 2 : 1);
	};
	const xAt = (i) => r * (i / STEPS) * Math.PI * 2;
	const pts = [];
	if (kind === "end") {
		for (let i = 0; i <= STEPS; i++) pts.push({
			x: xAt(i),
			y: 0
		});
		if (allowance > 0) pts.push({
			x: circ + allowance,
			y: 0
		});
		const seamLen = lenAt(0);
		if (allowance > 0) pts.push({
			x: circ + allowance,
			y: seamLen
		});
		for (let i = STEPS; i >= 0; i--) pts.push({
			x: xAt(i),
			y: lenAt(i)
		});
	} else {
		for (let i = 0; i <= STEPS; i++) pts.push({
			x: xAt(i),
			y: lenAt(i) / 2
		});
		const halfSeam = lenAt(0) / 2;
		if (allowance > 0) pts.push({
			x: circ + allowance,
			y: halfSeam
		});
		if (allowance > 0) pts.push({
			x: circ + allowance,
			y: -halfSeam
		});
		for (let i = STEPS; i >= 0; i--) pts.push({
			x: xAt(i),
			y: -lenAt(i) / 2
		});
	}
	return pts;
}
function calcElbow(input, shop) {
	const { diameter, clr, angle, gores, thickness, allowance, basis, seam } = input;
	if (!(diameter > 0) || !(clr > 0) || !(angle > 0)) return {
		ok: false,
		error: "Diameter, centerline radius, and bend angle all have to be greater than zero."
	};
	if (angle > 180) return {
		ok: false,
		error: "Bend angle is limited to 180° in this layout."
	};
	if (!Number.isInteger(gores) || gores < 2 || gores > 12) return {
		ok: false,
		error: "Use 2 to 12 gores."
	};
	if (thickness < 0 || allowance < 0) return {
		ok: false,
		error: "Thickness and seam allowance can’t be negative."
	};
	if (shop.k < .2 || shop.k > .5) return {
		ok: false,
		error: "K-factor needs to sit between 0.20 and 0.50."
	};
	const dn = neutralDiameter(diameter, thickness, shop.k, basis);
	if (!(dn > 0)) return {
		ok: false,
		error: "Thickness wipes out the neutral diameter. Check the size basis."
	};
	const r = dn / 2;
	if (clr <= r) return {
		ok: false,
		error: "Centerline radius has to be larger than half the neutral diameter, or the throat has no metal."
	};
	const betaDeg = angle / (2 * (gores - 1));
	const beta = betaDeg * Math.PI / 180;
	const tanBeta = Math.tan(beta);
	if (!(tanBeta > 0) || betaDeg >= 75) return {
		ok: false,
		error: "That gore angle is too steep to be a practical miter. Add gores or reduce the bend."
	};
	const end = goreOutline(clr, r, tanBeta, "end", seam, allowance);
	const middles = gores - 2;
	const middle = middles > 0 ? goreOutline(clr, r, tanBeta, "middle", seam, allowance) : null;
	const outside = (clr + r) * tanBeta;
	const inside = (clr - r) * tanBeta;
	const midOutside = outside * 2;
	const midInside = inside * 2;
	const endArea = shoelace(end);
	const midArea = middle ? shoelace(middle) : 0;
	const totalArea = endArea * 2 + midArea * middles;
	const kg = massKg(totalArea, thickness, shop.unit, shop.density);
	const endBox = bboxOf(end);
	const gap = Math.max(shop.unit === "mm" ? 40 : 2, (endBox.maxY - endBox.minY) * .12);
	const display = [{
		outline: end,
		label: "End gore · cut 2"
	}];
	if (middle) {
		const midBox = bboxOf(middle);
		const dx = endBox.maxX + gap - midBox.minX;
		const dy = -midBox.minY;
		const endDy = -endBox.minY;
		display[0] = {
			outline: end.map((p) => ({
				x: p.x,
				y: p.y + endDy
			})),
			label: "End gore · cut 2"
		};
		display.push({
			outline: middle.map((p) => ({
				x: p.x + dx,
				y: p.y + dy
			})),
			label: `Middle gore · cut ${middles}`
		});
	}
	const seamName = seam === "throat" ? "throat (inside)" : seam === "cheek" ? "cheek (side)" : "back (outside)";
	const notes = [
		"Straight mitred gores — a lobsterback — not a smooth bent tube. Lengths use tan of the miter angle.",
		`End gores are ${fmtAngle(betaDeg)} off square. ${middles > 0 ? `Each middle gore turns ${fmtAngle(betaDeg * 2)}.` : "Two end gores only."}`,
		`Longitudinal seam is on the ${seamName}. Allowance, if any, is a lap along that seam.`,
		`Neutral pipe ${fmt(dn, shop.unit)} from the ${basis} size, k = ${shop.k.toFixed(2)}. Centerline radius is the bend radius you asked for, not shifted by thickness.`,
		"The DXF contains every gore, spaced apart. The gap is not a cut. Square edge of an end gore welds to straight pipe.",
		"Net blank only — no kerf, no bevel land."
	];
	if (clr < dn) notes.push("Tight bend: centerline radius is under one diameter. Expect a cramped throat weld.");
	return {
		ok: true,
		pattern: {
			stats: [
				{
					label: "End, outside",
					value: fmt(outside, shop.unit),
					hero: true
				},
				{
					label: "End, inside",
					value: fmt(inside, shop.unit),
					hero: true
				},
				...middle ? [{
					label: "Middle, outside",
					value: fmt(midOutside, shop.unit),
					hero: true
				}, {
					label: "Middle, inside",
					value: fmt(midInside, shop.unit),
					hero: true
				}] : [{
					label: "Gore angle",
					value: fmtAngle(betaDeg),
					hero: true
				}],
				{
					label: "End gore angle",
					value: fmtAngle(betaDeg)
				},
				{
					label: "Middle gore angle",
					value: middles > 0 ? fmtAngle(betaDeg * 2) : "—"
				},
				{
					label: "Neutral Ø",
					value: fmt(dn, shop.unit)
				},
				{
					label: "Stretch-out",
					value: fmt(Math.PI * dn + allowance, shop.unit)
				},
				{
					label: "Gores",
					value: `${gores} (2 end${middles ? ` + ${middles} middle` : ""})`
				},
				{
					label: "Area, full elbow",
					value: fmtArea(totalArea, shop.unit)
				},
				{
					label: `Weight · ${shop.material}`,
					value: fmtMass(kg, shop.unit)
				}
			],
			display,
			guides: [],
			exportGroups: [{
				piece: { outline: end },
				count: 2
			}, ...middle ? [{
				piece: { outline: middle },
				count: middles
			}] : []],
			notes
		}
	};
}
/** Miter rays in degrees, measured along the bend from the incoming tangent. */
function miterAngles(angle, gores) {
	const beta = angle / (2 * (gores - 1));
	const rays = [];
	let a = beta;
	while (a < angle - beta * .25) {
		rays.push(a);
		a += 2 * beta;
	}
	return rays;
}
function Frame({ children, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-md border border-line bg-ink px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "mb-1 text-xs tracking-wide text-mist",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 160 72",
			className: "h-16 w-full",
			"aria-hidden": "true",
			children
		})]
	});
}
var stroke = {
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 1.6,
	strokeLinejoin: "round"
};
function CylinderSketch() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
		label: "Side of the shell",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "text-brass",
			...stroke,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "28",
					y: "16",
					width: "104",
					height: "36",
					rx: "18"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "28",
					y1: "16",
					x2: "28",
					y2: "52"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "132",
					y1: "16",
					x2: "132",
					y2: "52"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "text-mist",
			stroke: "currentColor",
			strokeWidth: "1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "18",
					y1: "16",
					x2: "18",
					y2: "52"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "14",
					y1: "16",
					x2: "22",
					y2: "16"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "14",
					y1: "52",
					x2: "22",
					y2: "52"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "28",
					y1: "62",
					x2: "132",
					y2: "62"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "28",
					y1: "58",
					x2: "28",
					y2: "66"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "132",
					y1: "58",
					x2: "132",
					y2: "66"
				})
			]
		})]
	});
}
function ConeSketch({ large, small }) {
	const big = Math.max(large, small, 1);
	const top = 18 + (1 - Math.min(small, big) / big) * 22;
	const bot = 54;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
		label: "Elevation, either end up",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			className: "text-brass",
			...stroke,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: `M46 ${bot} L64 ${top} L96 ${top} L114 ${bot} Z` })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "text-mist",
			stroke: "currentColor",
			strokeWidth: "1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "46",
				y1: 62,
				x2: "114",
				y2: 62
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "78",
				y1: top,
				x2: "78",
				y2: bot,
				strokeDasharray: "3 3"
			})]
		})]
	});
}
function AugerSketch() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
		label: "One pitch of flight",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "text-brass",
			...stroke,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "36",
					r: "24"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "80",
					cy: "36",
					r: "8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M80 12 L92 36 L80 60" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "text-mist",
			stroke: "currentColor",
			strokeWidth: "1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "112",
					y1: "20",
					x2: "112",
					y2: "52"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "108",
					y1: "20",
					x2: "116",
					y2: "20"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "108",
					y1: "52",
					x2: "116",
					y2: "52"
				})
			]
		})]
	});
}
function TransitionSketch() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
		label: "Concentric base to round",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			className: "text-brass",
			...stroke,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M36 56 H124 L104 20 H56 Z" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M62 20 H98" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M62 20 Q80 12 98 20" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "80",
			y1: "18",
			x2: "80",
			y2: "56",
			className: "text-mist",
			stroke: "currentColor",
			strokeWidth: "1",
			strokeDasharray: "3 3"
		})]
	});
}
function ElbowSketch({ angle, gores, clr, radius }) {
	const safeAngle = Number.isFinite(angle) && angle > 0 && angle <= 180 ? angle : 90;
	const safeGores = Number.isInteger(gores) && gores >= 2 ? gores : 5;
	const safeClr = clr > 0 ? clr : 1;
	const safeR = radius > 0 ? radius : safeClr * .4;
	const cx = 28;
	const cy = 64;
	const R = 46;
	const wall = Math.max(5, Math.min(14, safeR / safeClr * R));
	const a0 = -Math.PI / 2;
	const sweep = safeAngle * Math.PI / 180;
	const a1 = a0 + sweep;
	const large = sweep > Math.PI ? 1 : 0;
	const arc = (radiusLine) => {
		const x0 = cx + radiusLine * Math.cos(a0);
		const y0 = cy + radiusLine * Math.sin(a0);
		const x1 = cx + radiusLine * Math.cos(a1);
		const y1 = cy + radiusLine * Math.sin(a1);
		return `M ${x0.toFixed(2)} ${y0.toFixed(2)} A ${radiusLine} ${radiusLine} 0 ${large} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
	};
	const rays = miterAngles(safeAngle, safeGores);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
		label: "Mitres around the centerline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "text-brass",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: arc(R - wall) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: arc(R + wall) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: arc(R),
				className: "text-mist",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1",
				strokeDasharray: "3 3"
			}),
			rays.map((deg) => {
				const a = a0 + deg * Math.PI / 180;
				const x0 = cx + (R - wall) * Math.cos(a);
				const y0 = cy + (R - wall) * Math.sin(a);
				const x1 = cx + (R + wall) * Math.cos(a);
				const y1 = cy + (R + wall) * Math.sin(a);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: x0,
					y1: y0,
					x2: x1,
					y2: y1,
					className: "text-dim",
					stroke: "currentColor",
					strokeWidth: "1.2"
				}, deg);
			})
		]
	});
}
function norm360(deg) {
	const x = deg % 360;
	return x < 0 ? x + 360 : x;
}
function n$1(v) {
	return v.toFixed(4);
}
function line(layer, a, b, out) {
	out.push("0", "LINE", "8", layer, "10", n$1(a.x), "20", n$1(a.y), "30", "0", "11", n$1(b.x), "21", n$1(b.y), "31", "0");
}
function arc(layer, cx, cy, r, startDeg, sweepDeg, out) {
	if (r < 1e-6 || sweepDeg <= 0) return;
	const start = norm360(startDeg);
	const end = norm360(startDeg + sweepDeg);
	out.push("0", "ARC", "8", layer, "10", n$1(cx), "20", n$1(cy), "30", "0", "40", n$1(r), "50", n$1(start), "51", n$1(end));
}
function polyline(layer, pts, out) {
	if (pts.length < 2) return;
	out.push("0", "POLYLINE", "8", layer, "66", "1", "70", "1", "10", "0", "20", "0", "30", "0");
	for (const p of pts) out.push("0", "VERTEX", "8", layer, "10", n$1(p.x), "20", n$1(p.y), "30", "0");
	out.push("0", "SEQEND", "8", layer);
}
function emitPiece(piece, includeFolds, out) {
	if (piece.sector && piece.sector.sweepDeg > 0 && piece.sector.sweepDeg < 360) {
		const s = piece.sector;
		arc("CUT", s.cx, s.cy, s.outerR, s.startDeg, s.sweepDeg, out);
		const start = s.startDeg * Math.PI / 180;
		const end = (s.startDeg + s.sweepDeg) * Math.PI / 180;
		const outerA = {
			x: s.cx + s.outerR * Math.cos(start),
			y: s.cy + s.outerR * Math.sin(start)
		};
		const outerB = {
			x: s.cx + s.outerR * Math.cos(end),
			y: s.cy + s.outerR * Math.sin(end)
		};
		if (s.innerR < 1e-6) {
			const c = {
				x: s.cx,
				y: s.cy
			};
			line("CUT", outerA, c, out);
			line("CUT", c, outerB, out);
		} else {
			arc("CUT", s.cx, s.cy, s.innerR, s.startDeg, s.sweepDeg, out);
			const innerA = {
				x: s.cx + s.innerR * Math.cos(start),
				y: s.cy + s.innerR * Math.sin(start)
			};
			const innerB = {
				x: s.cx + s.innerR * Math.cos(end),
				y: s.cy + s.innerR * Math.sin(end)
			};
			line("CUT", innerA, outerA, out);
			line("CUT", innerB, outerB, out);
		}
	} else polyline("CUT", piece.outline, out);
	if (includeFolds && piece.folds) for (const [a, b] of piece.folds) line("FOLD", a, b, out);
}
function buildDxf(options) {
	const pieces = tileGroups(options.groups, options.gap);
	const units = options.unit === "mm" ? 4 : 1;
	const measurement = options.unit === "mm" ? 1 : 0;
	const out = [
		"999",
		options.comment,
		"0",
		"SECTION",
		"2",
		"HEADER",
		"9",
		"$ACADVER",
		"1",
		"AC1009",
		"9",
		"$INSUNITS",
		"70",
		String(units),
		"9",
		"$MEASUREMENT",
		"70",
		String(measurement),
		"0",
		"ENDSEC",
		"0",
		"SECTION",
		"2",
		"TABLES",
		"0",
		"TABLE",
		"2",
		"LTYPE",
		"70",
		"1",
		"0",
		"LTYPE",
		"2",
		"CONTINUOUS",
		"70",
		"0",
		"3",
		"Solid line",
		"72",
		"65",
		"73",
		"0",
		"40",
		"0.0",
		"0",
		"ENDTAB",
		"0",
		"TABLE",
		"2",
		"LAYER",
		"70",
		"3",
		"0",
		"LAYER",
		"2",
		"0",
		"70",
		"0",
		"62",
		"7",
		"6",
		"CONTINUOUS",
		"0",
		"LAYER",
		"2",
		"CUT",
		"70",
		"0",
		"62",
		"1",
		"6",
		"CONTINUOUS",
		"0",
		"LAYER",
		"2",
		"FOLD",
		"70",
		"0",
		"62",
		"5",
		"6",
		"CONTINUOUS",
		"0",
		"ENDTAB",
		"0",
		"ENDSEC",
		"0",
		"SECTION",
		"2",
		"ENTITIES"
	];
	for (const piece of pieces) emitPiece(piece, options.includeFolds, out);
	out.push("0", "ENDSEC", "0", "EOF");
	return out.join("\n") + "\n";
}
/**
* One pitch of a flat helical flight.
* Thickness is plate weight only — a flight is not a rolled shell, so it
* does not get a neutral-diameter shrink.
*/
function calcAuger(input, shop) {
	const { od, id, pitch, thickness, flights } = input;
	if (!(od > id) || !(id > 0) || !(pitch > 0)) return {
		ok: false,
		error: "Outside diameter has to be larger than the shaft hole, and pitch has to be greater than zero."
	};
	if (thickness < 0) return {
		ok: false,
		error: "Thickness can’t be negative."
	};
	if (!Number.isInteger(flights) || flights < 1 || flights > 24) return {
		ok: false,
		error: "Flight count must be a whole number from 1 to 24."
	};
	const rO = od / 2;
	const rI = id / 2;
	const lenInner = Math.hypot(2 * Math.PI * rI, pitch);
	const lenOuter = Math.hypot(2 * Math.PI * rO, pitch);
	const width = rO - rI;
	const ratio = lenOuter / lenInner;
	if (!(ratio > 1.0000001)) return {
		ok: false,
		error: "This pitch is so long the blank radius blows up. Check the pitch against the diameters."
	};
	const innerR = width / (ratio - 1);
	const outerR = innerR + width;
	if (outerR > 1e7) return {
		ok: false,
		error: "The blank would be enormous. Check the pitch and the two diameters."
	};
	const sweepDeg = lenInner / innerR * (180 / Math.PI);
	if (sweepDeg >= 359.95) return {
		ok: false,
		error: "Pitch is so small this is basically a flat washer. Increase the pitch."
	};
	if (!(sweepDeg > 1)) return {
		ok: false,
		error: "Sweep angle collapsed. Check the inputs."
	};
	const sector = {
		cx: 0,
		cy: 0,
		innerR,
		outerR,
		startDeg: 90 - sweepDeg / 2,
		sweepDeg
	};
	const outline = sectorOutline(sector);
	const gap = 360 - sweepDeg;
	const area = degToRad(sweepDeg) / 2 * (outerR ** 2 - innerR ** 2) * flights;
	const kg = massKg(area, thickness, shop.unit, shop.density);
	return {
		ok: true,
		pattern: {
			stats: [
				{
					label: "Blank outer R",
					value: fmt(outerR, shop.unit),
					hero: true
				},
				{
					label: "Blank inner R",
					value: fmt(innerR, shop.unit),
					hero: true
				},
				{
					label: "Sweep",
					value: fmtAngle(sweepDeg),
					hero: true
				},
				{
					label: "Gap to cut out",
					value: fmtAngle(gap),
					hero: true
				},
				{
					label: "Outer helix",
					value: fmt(lenOuter, shop.unit)
				},
				{
					label: "Inner helix",
					value: fmt(lenInner, shop.unit)
				},
				{
					label: "Radial width",
					value: fmt(width, shop.unit)
				},
				{
					label: "Blank outside Ø",
					value: fmt(outerR * 2, shop.unit)
				},
				{
					label: flights > 1 ? "Area, all flights" : "Area, one pitch",
					value: fmtArea(area, shop.unit)
				},
				{
					label: `Weight · ${shop.material}`,
					value: fmtMass(kg, shop.unit)
				}
			],
			display: [{
				outline,
				sector,
				label: flights > 1 ? `One pitch · cut ${flights}` : "One pitch"
			}],
			guides: [{
				x1: 0,
				y1: 0,
				x2: 0,
				y2: outerR,
				label: `R ${fmt(outerR, shop.unit)}`,
				lx: outerR * .12,
				ly: outerR * .72
			}, {
				x1: 0,
				y1: 0,
				x2: innerR * Math.cos(degToRad(118)),
				y2: innerR * Math.sin(degToRad(118)),
				label: `r ${fmt(innerR, shop.unit)}`,
				lx: innerR * Math.cos(degToRad(126)),
				ly: innerR * Math.sin(degToRad(126))
			}],
			exportGroups: [{
				piece: {
					outline,
					sector
				},
				count: flights
			}],
			notes: [
				"Flat flight, not a rolled shell. Outside and inside diameters are the finished flight; thickness is only used for weight.",
				"Outer and inner edges keep their true helical lengths. The gap is the wedge you cut out of the ring.",
				"One revolution per blank. A longer screw is this piece repeated.",
				flights > 1 ? `DXF contains ${flights} copies, spaced apart. The gap between copies is not a cut.` : "DXF is one flight.",
				"Net blank only — no kerf."
			]
		}
	};
}
function calcCone(input, shop) {
	const { height, thickness, allowance, basis } = input;
	let { large, small, pieces } = input;
	if (!(large > 0) || !(height > 0) || small < 0) return {
		ok: false,
		error: "Height and the large end must be greater than zero. The small end can be zero for a true cone."
	};
	if (thickness < 0 || allowance < 0) return {
		ok: false,
		error: "Thickness and seam allowance can’t be negative."
	};
	if (!Number.isInteger(pieces) || pieces < 1 || pieces > 8) return {
		ok: false,
		error: "Pieces must be a whole number from 1 to 8."
	};
	if (shop.k < .2 || shop.k > .5) return {
		ok: false,
		error: "K-factor needs to sit between 0.20 and 0.50."
	};
	const notes = [];
	if (small > large) {
		const swap = large;
		large = small;
		small = swap;
		notes.push("The two ends were ordered large to small for the blank. Height is unchanged.");
	}
	const dLarge = neutralDiameter(large, thickness, shop.k, basis);
	const dSmall = small === 0 ? 0 : neutralDiameter(small, thickness, shop.k, basis);
	if (!(dLarge > dSmall) || !(dLarge > 0) || dSmall < 0) return {
		ok: false,
		error: "After the thickness allowance the ends are equal or inverted. Use the pipe pattern, or check inside versus outside."
	};
	if (dLarge - dSmall < Math.max(dLarge, 1) * 1e-4) return {
		ok: false,
		error: "The ends are essentially equal. That’s a cylinder — use the pipe pattern."
	};
	const rLarge = dLarge / 2;
	const rSmall = dSmall / 2;
	const slant = Math.hypot(rLarge - rSmall, height);
	const outerR = rLarge * slant / (rLarge - rSmall);
	const innerR = outerR - slant;
	if (!(outerR > innerR) || innerR < -1e-6) return {
		ok: false,
		error: "The sector radii didn’t come out positive. Check the height and the two ends."
	};
	const largeCirc = Math.PI * dLarge;
	Math.PI * dSmall;
	const sweepDeg = (largeCirc / pieces + allowance) / outerR * (180 / Math.PI);
	if (!(sweepDeg > .5)) return {
		ok: false,
		error: "The sweep angle is essentially zero."
	};
	if (sweepDeg >= 360) return {
		ok: false,
		error: "Seam allowance makes one piece wrap into a full circle. Use more pieces or a smaller lap."
	};
	const startDeg = 90 - sweepDeg / 2;
	const sector = {
		cx: 0,
		cy: 0,
		innerR: Math.max(0, innerR),
		outerR,
		startDeg,
		sweepDeg
	};
	const outline = sectorOutline(sector);
	const mid = degToRad(90);
	const labelR = outerR * 1.04;
	const area = degToRad(sweepDeg) / 2 * (outerR ** 2 - Math.max(0, innerR) ** 2) * pieces;
	const kg = massKg(area, thickness, shop.unit, shop.density);
	const largeArc = outerR * degToRad(sweepDeg);
	const smallArc = Math.max(0, innerR) * degToRad(sweepDeg);
	notes.push(`Neutral ends ${fmt(dLarge, shop.unit)} and ${fmt(dSmall, shop.unit)} from the ${basis} sizes, k = ${shop.k.toFixed(2)}.`, "Tape the outer arc — it should match the large-end neutral circumference split across the pieces, plus one lap per piece.", pieces > 1 ? `DXF contains ${pieces} identical pieces, spaced apart. The gap is not a cut.` : "One piece, full sweep.", innerR <= 1e-4 ? "True cone: the blank runs to the apex." : "Frustum: keep the inner arc — that is the small end.", "Net blank only — no kerf.");
	return {
		ok: true,
		pattern: {
			stats: [
				{
					label: "Outer radius",
					value: fmt(outerR, shop.unit),
					hero: true
				},
				{
					label: innerR <= 1e-4 ? "Inner radius" : "Inner radius",
					value: fmt(Math.max(0, innerR), shop.unit),
					hero: true
				},
				{
					label: pieces > 1 ? "Sweep / piece" : "Sweep",
					value: fmtAngle(sweepDeg),
					hero: true
				},
				{
					label: "Slant height",
					value: fmt(slant, shop.unit),
					hero: true
				},
				{
					label: "Large-end arc",
					value: fmt(largeArc, shop.unit)
				},
				{
					label: "Small-end arc",
					value: fmt(smallArc, shop.unit)
				},
				{
					label: "Neutral large Ø",
					value: fmt(dLarge, shop.unit)
				},
				{
					label: "Neutral small Ø",
					value: fmt(dSmall, shop.unit)
				},
				{
					label: "Pieces",
					value: String(pieces)
				},
				{
					label: pieces > 1 ? "Area, all pieces" : "Area",
					value: fmtArea(area, shop.unit)
				},
				{
					label: `Weight · ${shop.material}`,
					value: fmtMass(kg, shop.unit)
				}
			],
			display: [{
				outline,
				sector,
				label: pieces > 1 ? `One piece · cut ${pieces}` : "Cone blank"
			}],
			guides: [{
				x1: 0,
				y1: 0,
				x2: labelR * Math.cos(mid),
				y2: labelR * Math.sin(mid),
				label: `R ${fmt(outerR, shop.unit)}`,
				lx: outerR * .62 * Math.cos(mid) + outerR * .08,
				ly: outerR * .62 * Math.sin(mid)
			}, {
				x1: 0,
				y1: 0,
				x2: Math.max(innerR, outerR * .08) * Math.cos(mid + .35),
				y2: Math.max(innerR, outerR * .08) * Math.sin(mid + .35),
				label: innerR > 1 ? `r ${fmt(innerR, shop.unit)}` : "Apex",
				lx: Math.max(innerR, outerR * .15) * Math.cos(mid + .55),
				ly: Math.max(innerR, outerR * .15) * Math.sin(mid + .55)
			}],
			exportGroups: [{
				piece: {
					outline,
					sector
				},
				count: pieces
			}],
			notes
		}
	};
}
function calcCylinder(input, shop) {
	const { diameter, length, thickness, allowance, basis, plateWidth } = input;
	if (!(diameter > 0) || !(length > 0)) return {
		ok: false,
		error: "Diameter and length have to be greater than zero."
	};
	if (thickness < 0 || allowance < 0) return {
		ok: false,
		error: "Thickness and seam allowance can’t be negative."
	};
	if (shop.k < .2 || shop.k > .5) return {
		ok: false,
		error: "K-factor needs to sit between 0.20 and 0.50."
	};
	const dn = neutralDiameter(diameter, thickness, shop.k, basis);
	if (!(dn > 0)) return {
		ok: false,
		error: "Thickness is large enough to wipe out the neutral diameter. Check the size basis."
	};
	const circ = Math.PI * dn;
	const stretch = circ + allowance;
	let courses = 1;
	if (plateWidth > 0) {
		if (plateWidth < length / 24) return {
			ok: false,
			error: "That plate width would chop the shell into too many courses."
		};
		courses = Math.ceil(length / plateWidth - 1e-9);
	}
	const courseLen = length / courses;
	const areaOne = stretch * courseLen;
	const area = areaOne * courses;
	const kg = massKg(areaOne, thickness, shop.unit, shop.density) * courses;
	const outline = [
		{
			x: 0,
			y: 0
		},
		{
			x: stretch,
			y: 0
		},
		{
			x: stretch,
			y: courseLen
		},
		{
			x: 0,
			y: courseLen
		}
	];
	const box = bboxOf(outline);
	const m = Math.max(box.maxX, box.maxY) * .08;
	const notes = [
		`Neutral diameter ${fmt(dn, shop.unit)} from the ${basis} size, k = ${shop.k.toFixed(2)}.`,
		"Roll the stretch-out. The short dimension is the axis of the pipe and does not grow.",
		courses > 1 ? `${courses} equal courses. The DXF has one rectangle per course, spaced apart — the gap is not a cut.` : "One course.",
		allowance > 0 ? `Each course includes ${fmt(allowance, shop.unit)} of seam allowance on the stretch-out.` : "No seam allowance added.",
		"Net blank only — no kerf, no bevel land."
	];
	if (shop.unit === "mm" && stretch > 6e3) notes.push("Stretch-out is over 6 m. Confirm you can buy and roll a plate that long.");
	if (shop.unit === "in" && stretch > 240) notes.push("Stretch-out is over 20 ft. Confirm plate length before you nest it.");
	return {
		ok: true,
		pattern: {
			stats: [
				{
					label: "Stretch-out",
					value: fmt(stretch, shop.unit),
					hero: true
				},
				{
					label: courses > 1 ? "Length / course" : "Axial length",
					value: fmt(courseLen, shop.unit),
					hero: true
				},
				{
					label: "Neutral Ø",
					value: fmt(dn, shop.unit)
				},
				{
					label: "Courses",
					value: String(courses)
				},
				{
					label: "Bare circumference",
					value: fmt(circ, shop.unit)
				},
				{
					label: "Plate for one course",
					value: `${fmt(stretch, shop.unit)} × ${fmt(courseLen, shop.unit)}`
				},
				{
					label: courses > 1 ? "Area, all courses" : "Area",
					value: fmtArea(area, shop.unit)
				},
				{
					label: courses > 1 ? `Weight, all · ${shop.material}` : `Weight · ${shop.material}`,
					value: fmtMass(kg, shop.unit)
				}
			],
			display: [{
				outline,
				label: courses > 1 ? `One course · cut ${courses}` : "Shell blank"
			}],
			guides: [{
				x1: 0,
				y1: courseLen + m,
				x2: stretch,
				y2: courseLen + m,
				label: `Stretch-out ${fmt(stretch, shop.unit)}`,
				lx: stretch / 2,
				ly: courseLen + m * 1.7
			}, {
				x1: -m,
				y1: 0,
				x2: -m,
				y2: courseLen,
				label: `Axial ${fmt(courseLen, shop.unit)}`,
				lx: -m * 1.55,
				ly: courseLen / 2,
				along: "y"
			}],
			exportGroups: [{
				piece: { outline },
				count: courses
			}],
			notes
		}
	};
}
var PLATES_MM = [
	{
		w: 1e3,
		h: 2e3,
		name: "1000 × 2000 mm"
	},
	{
		w: 1250,
		h: 2500,
		name: "1250 × 2500 mm"
	},
	{
		w: 1500,
		h: 3e3,
		name: "1500 × 3000 mm"
	},
	{
		w: 1500,
		h: 6e3,
		name: "1500 × 6000 mm"
	},
	{
		w: 2e3,
		h: 6e3,
		name: "2000 × 6000 mm"
	},
	{
		w: 2500,
		h: 6e3,
		name: "2500 × 6000 mm"
	},
	{
		w: 3e3,
		h: 12e3,
		name: "3000 × 12000 mm"
	}
];
var PLATES_IN = [
	{
		w: 48,
		h: 96,
		name: "4×8 (48 × 96 in)"
	},
	{
		w: 48,
		h: 120,
		name: "4×10 (48 × 120 in)"
	},
	{
		w: 60,
		h: 120,
		name: "5×10 (60 × 120 in)"
	},
	{
		w: 72,
		h: 144,
		name: "6×12 (72 × 144 in)"
	},
	{
		w: 96,
		h: 240,
		name: "8×20 (96 × 240 in)"
	},
	{
		w: 96,
		h: 480,
		name: "8×40 (96 × 480 in)"
	}
];
function wayOf(piece, plate) {
	const tol = .05;
	const upright = piece.w <= plate.w + tol && piece.h <= plate.h + tol;
	const turned = piece.w <= plate.h + tol && piece.h <= plate.w + tol;
	if (upright && turned) return "either way";
	if (upright) return "as drawn";
	if (turned) return "turned 90°";
	return null;
}
/**
* Smallest common plate that can hold every piece, each one rotated on its own.
*/
function smallestPlate(sizes, unit) {
	const plates = unit === "mm" ? PLATES_MM : PLATES_IN;
	const usable = sizes.filter((size) => size.w > 0 && size.h > 0);
	if (usable.length === 0) return {
		label: "—",
		note: "No piece to fit on a plate."
	};
	let best = null;
	for (const plate of plates) {
		const ways = usable.map((size) => wayOf(size, plate));
		if (ways.some((way) => way === null)) continue;
		if (!best || plate.w * plate.h < best.plate.w * best.plate.h) best = {
			plate,
			ways
		};
	}
	const largest = usable.reduce((a, b) => a.w * a.h >= b.w * b.h ? a : b);
	const sizeText = `${fmt(largest.w, unit)} × ${fmt(largest.h, unit)}`;
	if (!best) return {
		label: "Special",
		note: `Largest piece is ${sizeText}. That is past common stock — plan a splice or a special plate.`
	};
	const unique = new Set(best.ways);
	const how = unique.size === 1 ? [...unique][0] : "turned as needed";
	const pieceWord = usable.length > 1 ? "Each piece fits" : "It fits";
	return {
		label: best.plate.name,
		note: `Largest piece is ${sizeText}. ${pieceWord} a ${best.plate.name} sheet, ${how}.`
	};
}
function intersect(p1, r1, p2, r2, side) {
	const dx = p2.x - p1.x;
	const dy = p2.y - p1.y;
	const d = Math.hypot(dx, dy);
	if (d < 1e-8 || d > r1 + r2 + .01 || d < Math.abs(r1 - r2) - .01) throw new Error("close");
	const a = (r1 * r1 - r2 * r2 + d * d) / (2 * d);
	const h = Math.sqrt(Math.max(0, r1 * r1 - a * a));
	const x3 = p1.x + a * dx / d;
	const y3 = p1.y + a * dy / d;
	return {
		x: x3 + side * dy * h / d,
		y: y3 - side * dx * h / d
	};
}
/**
* Concentric rectangle-to-round by triangulation.
* `startSide` is the full length of the side whose center the blank starts on.
* `crossSide` is the full length of the adjacent side. Equal sides are a square.
* Built in a Y-down construction space, then flipped to Y-up for CAD.
* `quarters` is 1, 2, or 4 — seams fall on side centerlines.
*/
function developRectTransition(startSide, crossSide, diameter, height, segments, quarters) {
	const A = startSide / 2;
	const B = crossSide / 2;
	const r = diameter / 2;
	const h = height;
	const seam = Math.hypot(B - r, h);
	const seamCross = Math.hypot(A - r, h);
	const corner = Math.hypot(A, B - r, h);
	const cornerCross = Math.hypot(B, A - r, h);
	const step = Math.PI * r / 2 / segments;
	const defs = [
		{
			tl: (theta) => Math.hypot(A - r * Math.sin(theta), B - r * Math.cos(theta), h),
			endSeam: seamCross,
			endCorner: cornerCross,
			nextFull: crossSide,
			endHalf: B
		},
		{
			tl: (theta) => Math.hypot(A - r * Math.cos(theta), -B + r * Math.sin(theta), h),
			endSeam: seam,
			endCorner: corner,
			nextFull: startSide,
			endHalf: A
		},
		{
			tl: (theta) => Math.hypot(-A + r * Math.sin(theta), -B + r * Math.cos(theta), h),
			endSeam: seamCross,
			endCorner: cornerCross,
			nextFull: crossSide,
			endHalf: B
		},
		{
			tl: (theta) => Math.hypot(-A + r * Math.cos(theta), B - r * Math.sin(theta), h),
			endSeam: seam,
			endCorner: corner,
			nextFull: startSide,
			endHalf: A
		}
	];
	const tops = [{
		x: 0,
		y: 0
	}];
	const bots = [{
		x: 0,
		y: seam
	}, {
		x: A,
		y: seam
	}];
	const folds = [[tops[0], bots[0]], [tops[0], bots[1]]];
	const elementLengths = [
		{
			label: "Starting side-center seam",
			length: seam
		},
		{
			label: "Half of the starting side",
			length: A
		},
		{
			label: "Corner to the starting side-center",
			length: corner
		},
		{
			label: "Adjacent side-center seam",
			length: seamCross
		},
		{
			label: "Corner to the adjacent side-center",
			length: cornerCross
		}
	];
	let apex = bots[1];
	for (let q = 0; q < quarters; q++) {
		const def = defs[q];
		for (let i = 1; i <= segments; i++) {
			const theta = i / segments * (Math.PI / 2);
			const length = def.tl(theta);
			const prev = tops[tops.length - 1];
			const next = intersect(prev, step, apex, length, 1);
			tops.push(next);
			folds.push([next, apex]);
			if (q === 0 || q === 1 && Math.abs(corner - cornerCross) > .05) elementLengths.push({
				label: `${q === 0 ? "First" : "Second"} corner, arc step ${i} of ${segments}`,
				length
			});
		}
		const endTop = tops[tops.length - 1];
		if (q === quarters - 1) {
			const endBase = intersect(bots[bots.length - 1], def.endHalf, endTop, def.endSeam, -1);
			bots.push(endBase);
			folds.push([endTop, endBase]);
		} else {
			const nextCorner = intersect(apex, def.nextFull, endTop, def.endCorner, -1);
			bots.push(nextCorner);
			folds.push([endTop, nextCorner]);
			const mid = {
				x: (apex.x + nextCorner.x) / 2,
				y: (apex.y + nextCorner.y) / 2
			};
			folds.push([endTop, mid]);
			apex = nextCorner;
		}
	}
	const outlineDown = [...tops, ...[...bots].reverse()];
	const flip = (p) => ({
		x: p.x,
		y: -p.y
	});
	const outline = outlineDown.map(flip);
	const foldsUp = folds.map(([a, b]) => [flip(a), flip(b)]);
	const cleaned = [];
	for (const p of outline) {
		const last = cleaned[cleaned.length - 1];
		if (!last || Math.hypot(last.x - p.x, last.y - p.y) > 1e-6) cleaned.push(p);
	}
	if (selfIntersects(cleaned)) throw new Error("cross");
	for (let i = 1; i < tops.length; i++) {
		const d = Math.hypot(tops[i].x - tops[i - 1].x, tops[i].y - tops[i - 1].y);
		if (Math.abs(d - step) > Math.max(.05, step * .01)) throw new Error("chord");
	}
	return {
		outline: cleaned,
		folds: foldsUp,
		trueLengths: elementLengths,
		seam,
		corner,
		seamCross,
		cornerCross
	};
}
function partQuarters(part) {
	if (part === "quarter") return 1;
	if (part === "full") return 4;
	return 2;
}
function calcTransition(input, shop) {
	const { length, width, round, height, thickness, basis, segments, part } = input;
	if (!(length > 0) || !(width > 0) || !(round > 0) || !(height > 0)) return {
		ok: false,
		error: "Length, width, round, and height all have to be greater than zero."
	};
	if (thickness < 0) return {
		ok: false,
		error: "Thickness can’t be negative."
	};
	if (![
		6,
		8,
		12,
		16,
		24
	].includes(segments)) return {
		ok: false,
		error: "Use 6, 8, 12, 16, or 24 arc steps per quarter."
	};
	if (shop.k < .2 || shop.k > .5) return {
		ok: false,
		error: "K-factor needs to sit between 0.20 and 0.50."
	};
	const sideL = neutralDiameter(length, thickness, shop.k, basis);
	const sideW = neutralDiameter(width, thickness, shop.k, basis);
	const diameter = neutralDiameter(round, thickness, shop.k, basis);
	if (!(sideL > 0) || !(sideW > 0) || !(diameter > 0)) return {
		ok: false,
		error: "Thickness wipes out a neutral size. Check inside versus outside."
	};
	const rectangular = Math.abs(sideL - sideW) > Math.max(sideL, sideW) * 1e-4;
	if (rectangular && part === "quarter") return {
		ok: false,
		error: "A rectangle doesn’t repeat as four identical quarters. Use a half, or cut it as one piece."
	};
	const onWidth = part === "half-cross";
	const startSide = onWidth ? sideW : sideL;
	const crossSide = onWidth ? sideL : sideW;
	const quarters = partQuarters(part);
	let built;
	try {
		built = developRectTransition(startSide, crossSide, diameter, height, segments, quarters);
	} catch {
		return {
			ok: false,
			error: "These sizes won’t triangulate cleanly. Add height, or bring the round and the base closer in plan."
		};
	}
	const lengthSeam = onWidth ? built.seamCross : built.seam;
	const widthSeam = onWidth ? built.seam : built.seamCross;
	const lengthCorner = onWidth ? built.cornerCross : built.corner;
	const widthCorner = onWidth ? built.corner : built.cornerCross;
	const box = bboxOf(built.outline);
	const patW = box.maxX - box.minX;
	const patH = box.maxY - box.minY;
	const pieceArea = shoelace(built.outline);
	const copies = 4 / quarters;
	const fullArea = pieceArea * copies;
	const pieceKg = massKg(pieceArea, thickness, shop.unit, shop.density);
	const fullKg = massKg(fullArea, thickness, shop.unit, shop.density);
	const partLabel = part === "quarter" ? "Quarter" : part === "full" ? "Full" : onWidth ? "Half, seam on widths" : rectangular ? "Half, seam on lengths" : "Half";
	const sheetLabel = part === "quarter" ? "Quarter pattern" : part === "full" ? "Full pattern" : onWidth ? "Width-seam half" : rectangular ? "Length-seam half" : "Half pattern";
	const m = Math.max(patW, patH) * .06;
	const squareLike = !rectangular;
	const heroes = [{
		label: "Piece width",
		value: fmt(patW, shop.unit),
		hero: true
	}, {
		label: "Piece height",
		value: fmt(patH, shop.unit),
		hero: true
	}];
	if (squareLike) heroes.push({
		label: "Side-center length",
		value: fmt(built.seam, shop.unit),
		hero: true
	}, {
		label: "Corner length",
		value: fmt(built.corner, shop.unit),
		hero: true
	});
	else heroes.push({
		label: "Seam on lengths",
		value: fmt(lengthSeam, shop.unit),
		hero: true
	}, {
		label: "Seam on widths",
		value: fmt(widthSeam, shop.unit),
		hero: true
	});
	return {
		ok: true,
		pattern: {
			stats: [
				...heroes,
				{
					label: "Neutral base",
					value: `${fmt(sideL, shop.unit)} × ${fmt(sideW, shop.unit)}`
				},
				{
					label: "Neutral round Ø",
					value: fmt(diameter, shop.unit)
				},
				...squareLike ? [] : [{
					label: "To length-side center",
					value: fmt(lengthCorner, shop.unit)
				}, {
					label: "To width-side center",
					value: fmt(widthCorner, shop.unit)
				}],
				{
					label: "Pattern",
					value: `${partLabel} · cut ${copies}`
				},
				{
					label: "This piece",
					value: fmtArea(pieceArea, shop.unit)
				},
				{
					label: "Full fitting",
					value: fmtArea(fullArea, shop.unit)
				},
				{
					label: `This piece · ${shop.material}`,
					value: fmtMass(pieceKg, shop.unit)
				},
				{
					label: "Full fitting weight",
					value: fmtMass(fullKg, shop.unit)
				}
			],
			display: [{
				outline: built.outline,
				folds: built.folds,
				label: sheetLabel
			}],
			guides: [{
				x1: box.minX,
				y1: box.minY - m,
				x2: box.maxX,
				y2: box.minY - m,
				label: `Width ${fmt(patW, shop.unit)}`,
				lx: (box.minX + box.maxX) / 2,
				ly: box.minY - m * 1.8
			}, {
				x1: box.minX - m,
				y1: box.minY,
				x2: box.minX - m,
				y2: box.maxY,
				label: `Height ${fmt(patH, shop.unit)}`,
				lx: box.minX - m * 1.7,
				ly: (box.minY + box.maxY) / 2,
				along: "y"
			}],
			exportGroups: [{
				piece: {
					outline: built.outline,
					folds: built.folds
				},
				count: 1
			}],
			trueLengths: built.trueLengths.map((row) => ({
				label: row.label,
				value: fmt(row.length, shop.unit)
			})),
			notes: [
				rectangular ? `Concentric rectangle-to-round on the neutral surface (${basis}, k = ${shop.k.toFixed(2)}).` : `Concentric square-to-round on the neutral surface (${basis}, k = ${shop.k.toFixed(2)}).`,
				"Dashed lines are triangulation layout lines. They are not a cut unless you turn on layer FOLD in the DXF.",
				copies > 1 ? `Cut ${copies} of this piece to close the fitting. The DXF is one piece — step it off again rather than stretching it.` : "This piece is the whole fitting, seamed on a side center.",
				rectangular && part === "half" ? "This half is seamed on the center of the length sides and includes one full width side." : rectangular && part === "half-cross" ? "This half is seamed on the center of the width sides and includes one full length side." : "Seams fall on side centers, not on the corners.",
				`Round edge uses ${segments} equal steps per quarter. More steps, smoother curve, same corner length.`,
				"Net blank only — no kerf, no corner notch."
			]
		}
	};
}
var DEFAULT_STATE = {
	unit: "mm",
	material: "mild",
	kFactor: "0.5",
	mark: "",
	tab: "cylinder",
	cylinder: {
		diameter: "500",
		length: "800",
		thickness: "5",
		allowance: "0",
		basis: "outside",
		plateWidth: ""
	},
	cone: {
		large: "600",
		small: "250",
		height: "450",
		thickness: "5",
		allowance: "0",
		pieces: "1",
		basis: "inside"
	},
	auger: {
		od: "400",
		id: "100",
		pitch: "300",
		thickness: "5",
		flights: "1"
	},
	transition: {
		length: "800",
		width: "500",
		round: "300",
		height: "400",
		thickness: "5",
		basis: "inside",
		segments: "12",
		part: "half",
		folds: false
	},
	elbow: {
		diameter: "500",
		clr: "750",
		angle: "90",
		gores: "5",
		thickness: "6",
		allowance: "0",
		basis: "outside",
		seam: "throat"
	}
};
var LINEAR = [
	{
		tab: "cylinder",
		key: "diameter"
	},
	{
		tab: "cylinder",
		key: "length"
	},
	{
		tab: "cylinder",
		key: "thickness"
	},
	{
		tab: "cylinder",
		key: "allowance"
	},
	{
		tab: "cylinder",
		key: "plateWidth"
	},
	{
		tab: "cone",
		key: "large"
	},
	{
		tab: "cone",
		key: "small"
	},
	{
		tab: "cone",
		key: "height"
	},
	{
		tab: "cone",
		key: "thickness"
	},
	{
		tab: "cone",
		key: "allowance"
	},
	{
		tab: "auger",
		key: "od"
	},
	{
		tab: "auger",
		key: "id"
	},
	{
		tab: "auger",
		key: "pitch"
	},
	{
		tab: "auger",
		key: "thickness"
	},
	{
		tab: "transition",
		key: "length"
	},
	{
		tab: "transition",
		key: "width"
	},
	{
		tab: "transition",
		key: "round"
	},
	{
		tab: "transition",
		key: "height"
	},
	{
		tab: "transition",
		key: "thickness"
	},
	{
		tab: "elbow",
		key: "diameter"
	},
	{
		tab: "elbow",
		key: "clr"
	},
	{
		tab: "elbow",
		key: "thickness"
	},
	{
		tab: "elbow",
		key: "allowance"
	}
];
function readNumber(value) {
	const trimmed = value.trim();
	if (trimmed === "") return null;
	const n = Number(trimmed);
	return Number.isFinite(n) ? n : null;
}
function convertUnits(state, to) {
	if (state.unit === to) return state;
	const factor = state.unit === "mm" ? 1 / 25.4 : 25.4;
	const digits = to === "mm" ? 2 : 3;
	const next = structuredClone(state);
	next.unit = to;
	for (const field of LINEAR) {
		const group = next[field.tab];
		const raw = group[field.key];
		if (typeof raw !== "string") continue;
		const n = readNumber(raw);
		if (n === null) continue;
		group[field.key] = String(Number((n * factor).toFixed(digits)));
	}
	return next;
}
function req(value, label) {
	const n = readNumber(value);
	if (n === null) return `${label} needs a number.`;
	return n;
}
function shopOf(state) {
	const k = readNumber(state.kFactor);
	if (k === null) return "K-factor needs a number.";
	const mat = materialById(state.material);
	return {
		unit: state.unit,
		k,
		density: mat.density,
		material: mat.name
	};
}
function evaluate(state) {
	const shop = shopOf(state);
	if (typeof shop === "string") return {
		ok: false,
		error: shop
	};
	return withPlate(evaluateTab(state, shop), shop.unit);
}
function withPlate(result, unit) {
	if (!result.ok) return result;
	const plate = smallestPlate(result.pattern.exportGroups.map((group) => {
		const box = bboxOf(group.piece.outline);
		return {
			w: box.maxX - box.minX,
			h: box.maxY - box.minY
		};
	}), unit);
	return {
		ok: true,
		pattern: {
			...result.pattern,
			stats: [...result.pattern.stats, {
				label: "Common plate",
				value: plate.label
			}],
			notes: [...result.pattern.notes, plate.note]
		}
	};
}
function evaluateTab(state, shop) {
	if (state.tab === "cylinder") {
		const f = state.cylinder;
		const diameter = req(f.diameter, "Diameter");
		const length = req(f.length, "Length");
		const thickness = req(f.thickness, "Thickness");
		const allowance = req(f.allowance, "Seam allowance");
		const plate = f.plateWidth.trim() === "" ? 0 : readNumber(f.plateWidth);
		if (typeof diameter === "string") return {
			ok: false,
			error: diameter
		};
		if (typeof length === "string") return {
			ok: false,
			error: length
		};
		if (typeof thickness === "string") return {
			ok: false,
			error: thickness
		};
		if (typeof allowance === "string") return {
			ok: false,
			error: allowance
		};
		if (plate === null) return {
			ok: false,
			error: "Max course length needs a number, or leave it blank."
		};
		return calcCylinder({
			diameter,
			length,
			thickness,
			allowance,
			basis: f.basis,
			plateWidth: plate
		}, shop);
	}
	if (state.tab === "cone") {
		const f = state.cone;
		const large = req(f.large, "Large end");
		const small = req(f.small, "Small end");
		const height = req(f.height, "Height");
		const thickness = req(f.thickness, "Thickness");
		const allowance = req(f.allowance, "Seam allowance");
		const pieces = req(f.pieces, "Pieces");
		if (typeof large === "string") return {
			ok: false,
			error: large
		};
		if (typeof small === "string") return {
			ok: false,
			error: small
		};
		if (typeof height === "string") return {
			ok: false,
			error: height
		};
		if (typeof thickness === "string") return {
			ok: false,
			error: thickness
		};
		if (typeof allowance === "string") return {
			ok: false,
			error: allowance
		};
		if (typeof pieces === "string") return {
			ok: false,
			error: pieces
		};
		return calcCone({
			large,
			small,
			height,
			thickness,
			allowance,
			pieces,
			basis: f.basis
		}, shop);
	}
	if (state.tab === "auger") {
		const f = state.auger;
		const od = req(f.od, "Outside diameter");
		const id = req(f.id, "Shaft hole");
		const pitch = req(f.pitch, "Pitch");
		const thickness = req(f.thickness, "Thickness");
		const flights = req(f.flights, "Flights");
		if (typeof od === "string") return {
			ok: false,
			error: od
		};
		if (typeof id === "string") return {
			ok: false,
			error: id
		};
		if (typeof pitch === "string") return {
			ok: false,
			error: pitch
		};
		if (typeof thickness === "string") return {
			ok: false,
			error: thickness
		};
		if (typeof flights === "string") return {
			ok: false,
			error: flights
		};
		return calcAuger({
			od,
			id,
			pitch,
			thickness,
			flights
		}, shop);
	}
	if (state.tab === "transition") {
		const f = state.transition;
		const length = req(f.length, "Base length");
		const width = req(f.width, "Base width");
		const round = req(f.round, "Round");
		const height = req(f.height, "Height");
		const thickness = req(f.thickness, "Thickness");
		const segments = req(f.segments, "Arc steps");
		if (typeof length === "string") return {
			ok: false,
			error: length
		};
		if (typeof width === "string") return {
			ok: false,
			error: width
		};
		if (typeof round === "string") return {
			ok: false,
			error: round
		};
		if (typeof height === "string") return {
			ok: false,
			error: height
		};
		if (typeof thickness === "string") return {
			ok: false,
			error: thickness
		};
		if (typeof segments === "string") return {
			ok: false,
			error: segments
		};
		return calcTransition({
			length,
			width,
			round,
			height,
			thickness,
			basis: f.basis,
			segments,
			part: f.part
		}, shop);
	}
	const f = state.elbow;
	const diameter = req(f.diameter, "Diameter");
	const clr = req(f.clr, "Centerline radius");
	const angle = req(f.angle, "Bend angle");
	const gores = req(f.gores, "Gores");
	const thickness = req(f.thickness, "Thickness");
	const allowance = req(f.allowance, "Seam allowance");
	if (typeof diameter === "string") return {
		ok: false,
		error: diameter
	};
	if (typeof clr === "string") return {
		ok: false,
		error: clr
	};
	if (typeof angle === "string") return {
		ok: false,
		error: angle
	};
	if (typeof gores === "string") return {
		ok: false,
		error: gores
	};
	if (typeof thickness === "string") return {
		ok: false,
		error: thickness
	};
	if (typeof allowance === "string") return {
		ok: false,
		error: allowance
	};
	return calcElbow({
		diameter,
		clr,
		angle,
		gores,
		thickness,
		allowance,
		basis: f.basis,
		seam: f.seam
	}, shop);
}
function mergeSaved(raw) {
	if (!raw || typeof raw !== "object") return DEFAULT_STATE;
	const saved = raw;
	const savedT = saved.transition ?? {};
	const legacySide = typeof savedT.square === "string" ? savedT.square : void 0;
	const transition = {
		...DEFAULT_STATE.transition,
		...savedT,
		length: typeof savedT.length === "string" ? savedT.length : legacySide ?? DEFAULT_STATE.transition.length,
		width: typeof savedT.width === "string" ? savedT.width : legacySide ?? DEFAULT_STATE.transition.width
	};
	delete transition.square;
	const next = {
		...DEFAULT_STATE,
		...saved,
		mark: typeof saved.mark === "string" ? saved.mark.slice(0, 40) : "",
		cylinder: {
			...DEFAULT_STATE.cylinder,
			...saved.cylinder ?? {}
		},
		cone: {
			...DEFAULT_STATE.cone,
			...saved.cone ?? {}
		},
		auger: {
			...DEFAULT_STATE.auger,
			...saved.auger ?? {}
		},
		transition,
		elbow: {
			...DEFAULT_STATE.elbow,
			...saved.elbow ?? {}
		}
	};
	if (next.unit !== "mm" && next.unit !== "in") next.unit = "mm";
	if (next.material !== "mild" && next.material !== "ss" && next.material !== "alu") next.material = "mild";
	if (![
		"cylinder",
		"cone",
		"auger",
		"transition",
		"elbow"
	].includes(next.tab)) next.tab = "cylinder";
	for (const group of [
		next.cylinder,
		next.cone,
		next.transition,
		next.elbow
	]) if (group.basis !== "outside" && group.basis !== "inside") group.basis = "outside";
	if (![
		"quarter",
		"half",
		"half-cross",
		"full"
	].includes(next.transition.part)) next.transition.part = "half";
	if (![
		"throat",
		"cheek",
		"back"
	].includes(next.elbow.seam)) next.elbow.seam = "throat";
	if (typeof next.transition.folds !== "boolean") next.transition.folds = false;
	return next;
}
function n(v) {
	return v.toFixed(4);
}
function esc(value) {
	return value.replace(/[&<>"]/g, (ch) => {
		if (ch === "&") return "&amp;";
		if (ch === "<") return "&lt;";
		if (ch === ">") return "&gt;";
		return "&quot;";
	});
}
function pathOf(pts, close) {
	if (pts.length === 0) return "";
	const cmds = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${n(p.x)} ${n(-p.y)}`);
	return close ? `${cmds.join(" ")} Z` : cmds.join(" ");
}
/** Full-size SVG, Y-up geometry flipped into SVG space. 1 user unit = 1 mm or 1 inch. */
function buildSvg(options) {
	const pts = [];
	for (const piece of options.pieces) {
		pts.push(...piece.outline);
		if (options.includeFolds) for (const [a, b] of piece.folds ?? []) pts.push(a, b);
	}
	const box = pts.length ? bboxOf(pts.map((p) => ({
		x: p.x,
		y: -p.y
	}))) : {
		minX: 0,
		minY: 0,
		maxX: 1,
		maxY: 1
	};
	const span = Math.max(box.maxX - box.minX, box.maxY - box.minY, 1);
	const pad = span * .06;
	const minX = box.minX - pad;
	const minY = box.minY - pad;
	const width = box.maxX - box.minX + pad * 2;
	const height = box.maxY - box.minY + pad * 2;
	const font = span * .032;
	const cuts = options.pieces.map((piece) => pathOf(piece.outline, true)).filter(Boolean);
	const folds = options.includeFolds ? options.pieces.flatMap((piece) => (piece.folds ?? []).map(([a, b]) => pathOf([a, b], false))) : [];
	const labels = options.pieces.filter((piece) => piece.label).map((piece) => {
		const b = bboxOf(piece.outline);
		const x = (b.minX + b.maxX) / 2;
		const y = -((b.minY + b.maxY) / 2);
		return `<text x="${n(x)}" y="${n(y)}" text-anchor="middle" dominant-baseline="middle" font-family="sans-serif" font-size="${n(font)}" fill="#1c1a16">${esc(piece.label ?? "")}</text>`;
	});
	return [
		`<?xml version="1.0" encoding="UTF-8"?>`,
		`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${n(minX)} ${n(minY)} ${n(width)} ${n(height)}" fill="none">`,
		`<title>${esc(options.title)}</title>`,
		`<desc>Full size. 1 user unit = 1 ${options.unit}. Solid paths are the cut. Dashed paths are layout lines.</desc>`,
		`<g stroke="#1a1a1a" stroke-width="1.5" stroke-linejoin="round" vector-effect="non-scaling-stroke">`,
		...cuts.map((d) => `<path d="${d}"/>`),
		`</g>`,
		folds.length ? `<g stroke="#2c4c7c" stroke-width="1" stroke-dasharray="5 4" vector-effect="non-scaling-stroke">${folds.map((d) => `<path d="${d}"/>`).join("")}</g>` : "",
		...labels,
		`</svg>`,
		``
	].join("\n");
}
var STORAGE_KEY = "pattern-shop-v1";
var TABS = [
	{
		id: "cylinder",
		label: "Pipe"
	},
	{
		id: "cone",
		label: "Cone"
	},
	{
		id: "auger",
		label: "Auger"
	},
	{
		id: "transition",
		label: "Transition"
	},
	{
		id: "elbow",
		label: "Elbow"
	}
];
var HOW = {
	cylinder: {
		title: "How the pipe blank is figured",
		body: "Stretch-out is the neutral circumference, π × Dn, plus any lap you add for the long seam. Dn sits at fraction k of the wall, measured from the inside — 0.50 is mid-plate. The axial length does not stretch. A max course length splits the shell into equal rings."
	},
	cone: {
		title: "How the cone blank is figured",
		body: "Both ends become neutral circles. Slant height is the true length along the plate. Outer radius = large radius × slant ÷ (large − small). Sweep = (large circumference ÷ pieces + one lap) ÷ outer radius. A zero small end is a true cone and the blank runs to the apex."
	},
	auger: {
		title: "How the flight blank is figured",
		body: "A flight is flat plate wrapped into a helix, not a rolled shell, so thickness does not change the blank. Each edge keeps its helical length, √((πD)² + pitch²). The sector width is (OD − ID) ÷ 2. The gap is what you cut out of the ring. One blank is one pitch."
	},
	transition: {
		title: "How the transition is figured",
		body: "Concentric rectangle-to-round, or a square when the two sides match. The round is split into equal arc steps and each step is a triangle back to a corner. A half is seamed on the center of the sides you pick, and you cut two of them. Dashed lines are for laying out by hand — they stay off the cut unless you include layer FOLD."
	},
	elbow: {
		title: "How the lobsterback is figured",
		body: "These are straight pipe gores mitred together, not a smooth bent tube. End gores are half the angle of a middle gore. The length of each generator is (centerline radius ± neutral radius) × tan(half-angle). The curved edge is the unrolled miter. The straight edge on an end gore welds to straight pipe."
	}
};
function ticket(pattern, mark) {
	const lines = [
		...mark.trim() ? [`Mark: ${mark.trim()}`, ""] : [],
		...pattern.stats.map((stat) => `${stat.label}: ${stat.value}`),
		"",
		...pattern.notes
	];
	if (pattern.trueLengths?.length) {
		lines.push("", "True lengths");
		for (const row of pattern.trueLengths) lines.push(`${row.label}: ${row.value}`);
	}
	return lines.join("\n");
}
function fileSlug(mark, tab) {
	const cleaned = mark.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
	return cleaned ? `${cleaned}-${tab}` : tab;
}
function download(filename, text, type) {
	const blob = new Blob([text], { type });
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	document.body.appendChild(anchor);
	anchor.click();
	anchor.remove();
	URL.revokeObjectURL(url);
}
function rectangularBase(length, width) {
	const L = readNumber(length);
	const W = readNumber(width);
	if (L === null || W === null) return false;
	return Math.abs(L - W) > Math.max(Math.abs(L), Math.abs(W), 1) * 1e-4;
}
function PatternShop() {
	const [state, setState] = (0, import_react.useState)(DEFAULT_STATE);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) setState(mergeSaved(JSON.parse(raw)));
		} catch {}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
	}, [state, ready]);
	const result = (0, import_react.useMemo)(() => evaluate(state), [state]);
	const pattern = result.ok ? result.pattern : null;
	const error = result.ok ? null : result.error;
	const unit = state.unit;
	const setTab = (tab, patch) => {
		setState((current) => ({
			...current,
			[tab]: {
				...current[tab],
				...patch
			}
		}));
	};
	const exportDxf = () => {
		if (!pattern) return;
		const comment = [
			"Pattern Shop",
			state.mark.trim(),
			state.tab,
			...pattern.stats.map((stat) => `${stat.label}: ${stat.value}`)
		].filter(Boolean).join(" | ").slice(0, 240);
		const dxf = buildDxf({
			groups: pattern.exportGroups,
			unit,
			comment,
			includeFolds: state.tab === "transition" && state.transition.folds,
			gap: unit === "mm" ? 25 : 1
		});
		download(`${fileSlug(state.mark, state.tab)}.dxf`, dxf, "application/dxf");
	};
	const exportSvg = () => {
		if (!pattern) return;
		const gap = unit === "mm" ? 25 : 1;
		const svg = buildSvg({
			pieces: tileGroups(pattern.exportGroups, gap),
			unit,
			title: [state.mark.trim(), state.tab].filter(Boolean).join(" "),
			includeFolds: state.tab === "transition" && state.transition.folds
		});
		download(`${fileSlug(state.mark, state.tab)}.svg`, svg, "image/svg+xml");
	};
	const copyTicket = async () => {
		if (!pattern) return;
		const text = ticket(pattern, state.mark);
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	};
	const printSvg = (0, import_react.useMemo)(() => {
		if (!pattern) return "";
		return buildSvg({
			pieces: pattern.display,
			unit,
			title: [state.mark.trim() || "Pattern Shop", state.tab].filter(Boolean).join(" "),
			includeFolds: true
		});
	}, [
		pattern,
		unit,
		state.mark,
		state.tab
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-ink text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "ticket-print",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl leading-none tracking-wide",
					children: "Pattern Shop"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm",
					children: [
						state.mark.trim(),
						TABS.find((tab) => tab.id === state.tab)?.label,
						unit
					].filter(Boolean).join(" · ")
				}),
				pattern ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-4 grid grid-cols-2 gap-x-6 gap-y-1 text-sm",
						children: pattern.stats.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-3 border-b border-sheet-grid py-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: stat.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-right font-medium tabular-nums",
								children: stat.value
							})]
						}, stat.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ticket-drawing mt-4",
						dangerouslySetInnerHTML: { __html: printSvg }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-1 text-sm",
						children: pattern.notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, note))
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm",
					children: error
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-screen",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl leading-none tracking-wide text-fg",
								children: "Pattern Shop"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-mist",
								children: "Flat patterns for plate and pipe"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-36 shrink-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
										label: "Units",
										hideLabel: true,
										value: unit,
										options: [{
											value: "mm",
											label: "mm"
										}, {
											value: "in",
											label: "inch"
										}],
										onChange: (next) => setState((current) => convertUnits(current, next))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "line",
									onClick: exportSvg,
									disabled: !pattern,
									children: "SVG"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: exportDxf,
									disabled: !pattern,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Export DXF"]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-6xl overflow-x-auto px-4 sm:px-6",
						role: "tablist",
						"aria-label": "Pattern",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-max gap-1",
							children: TABS.map((tab) => {
								const on = state.tab === tab.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									role: "tab",
									"aria-selected": on,
									onClick: () => setState((current) => ({
										...current,
										tab: tab.id
									})),
									className: on ? "h-11 border-b-2 border-brass px-3 text-sm font-semibold text-brass" : "h-11 border-b-2 border-transparent px-3 text-sm font-semibold text-mist hover:text-fg",
									children: tab.label
								}, tab.id);
							})
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto grid max-w-6xl gap-6 px-4 py-5 sm:px-6 lg:grid-cols-12 lg:gap-8 lg:py-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-4 lg:col-span-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Job mark",
								value: state.mark,
								hint: "Stamped on the printout and written into the file.",
								onChange: (mark) => setState((current) => ({
									...current,
									mark: mark.slice(0, 40)
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobForm, {
								state,
								setTab
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Neutral axis, k",
									value: state.kFactor,
									suffix: "k",
									hint: "0.50 is mid-plate. Lower moves the axis toward the inside.",
									onChange: (kFactor) => setState((current) => ({
										...current,
										kFactor
									}))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
									label: "Metal, for weight",
									value: state.material,
									onChange: (material) => setState((current) => ({
										...current,
										material: material === "ss" || material === "alu" ? material : "mild"
									})),
									children: MATERIALS.map((material) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: material.id,
										children: material.name
									}, material.id))
								})]
							}),
							pattern ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								"aria-live": "polite",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-2 gap-3",
										children: pattern.stats.filter((stat) => stat.hero).map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-md border border-line bg-panel px-3 py-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs tracking-wide text-mist",
												children: stat.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 font-display text-2xl leading-none text-brass tabular-nums sm:text-3xl",
												children: stat.value
											})]
										}, stat.label))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
										className: "mt-3 divide-y divide-line rounded-md border border-line",
										children: pattern.stats.filter((stat) => !stat.hero).map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-baseline justify-between gap-3 px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
												className: "text-sm text-mist",
												children: stat.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
												className: "text-right text-sm font-medium text-fg tabular-nums",
												children: stat.value
											})]
										}, stat.label))
									}),
									pattern.trueLengths ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "mt-3 rounded-md border border-line px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
											className: "text-sm font-medium text-fg",
											children: "True lengths"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
											className: "mt-2 space-y-1",
											children: pattern.trueLengths.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between gap-3 text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-mist",
													children: row.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "tabular-nums text-fg",
													children: row.value
												})]
											}, row.label))
										})]
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-4 space-y-2",
										children: pattern.notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex gap-2 text-sm leading-snug text-mist",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1.5 size-1 shrink-0 rounded-full bg-brass",
												"aria-hidden": "true"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: note })]
										}, note))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 flex flex-wrap gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "line",
												onClick: copyTicket,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
													className: "size-4",
													"aria-hidden": "true"
												}), copied ? "Copied" : "Copy ticket"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "line",
												onClick: () => window.print(),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
													className: "size-4",
													"aria-hidden": "true"
												}), "Print"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "ghost",
												onClick: () => setState((current) => ({
													...current,
													[current.tab]: DEFAULT_STATE[current.tab]
												})),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
													className: "size-4",
													"aria-hidden": "true"
												}), "Reset"]
											})
										]
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-md border border-rust/40 bg-rust/10 px-3 py-3 text-sm text-fg",
								role: "alert",
								children: error
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "lg:col-span-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutSheet, {
								pattern,
								error,
								resetKey: `${state.tab}:${pattern ? "ok" : error}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "mt-4 rounded-md border border-line px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
									className: "text-sm font-medium text-fg",
									children: HOW[state.tab].title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-mist",
									children: HOW[state.tab].body
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs leading-relaxed text-mist",
								children: "Layouts are the neutral surface, full size, in the units on the ticket. They are a marking aid, not a checked shop drawing — tape the first piece before you cut the batch."
							})
						]
					})]
				})
			]
		})]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 36 36",
		className: "size-11 shrink-0",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "36",
				height: "36",
				rx: "6",
				className: "fill-panel stroke-line",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 30 7 16.5A13 13 0 0 1 29 16.5L18 30Z",
				className: "stroke-brass",
				fill: "none",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 22.5 11.5 16.8a7 7 0 0 1 13 0L18 22.5Z",
				className: "stroke-brass",
				fill: "none",
				strokeWidth: "1.6"
			})
		]
	});
}
function BasisField({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
		label: "Diameters are",
		value,
		onChange,
		options: [{
			value: "outside",
			label: "Outside"
		}, {
			value: "inside",
			label: "Inside"
		}]
	});
}
function JobForm({ state, setTab }) {
	const unit = state.unit;
	if (state.tab === "cylinder") {
		const f = state.cylinder;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CylinderSketch, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasisField, {
					value: f.basis,
					onChange: (basis) => setTab("cylinder", { basis })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Diameter",
							suffix: unit,
							value: f.diameter,
							onChange: (diameter) => setTab("cylinder", { diameter })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Axial length",
							suffix: unit,
							value: f.length,
							onChange: (length) => setTab("cylinder", { length })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Thickness",
							suffix: unit,
							value: f.thickness,
							onChange: (thickness) => setTab("cylinder", { thickness })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Seam allowance",
							suffix: unit,
							value: f.allowance,
							hint: "Added once, on the stretch-out.",
							onChange: (allowance) => setTab("cylinder", { allowance })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max length per course",
								suffix: unit,
								value: f.plateWidth,
								hint: "Blank for one piece. Splits the axis into equal rings.",
								onChange: (plateWidth) => setTab("cylinder", { plateWidth })
							})
						})
					]
				})
			]
		});
	}
	if (state.tab === "cone") {
		const f = state.cone;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConeSketch, {
					large: readNumber(f.large) ?? 1,
					small: readNumber(f.small) ?? 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasisField, {
					value: f.basis,
					onChange: (basis) => setTab("cone", { basis })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Large end",
							suffix: unit,
							value: f.large,
							onChange: (large) => setTab("cone", { large })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Small end",
							suffix: unit,
							value: f.small,
							hint: "Zero for a true cone.",
							onChange: (small) => setTab("cone", { small })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Vertical height",
							suffix: unit,
							value: f.height,
							onChange: (height) => setTab("cone", { height })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Thickness",
							suffix: unit,
							value: f.thickness,
							onChange: (thickness) => setTab("cone", { thickness })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Seam allowance",
							suffix: unit,
							value: f.allowance,
							hint: "Added to each piece.",
							onChange: (allowance) => setTab("cone", { allowance })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Pieces",
							value: f.pieces,
							onChange: (pieces) => setTab("cone", { pieces }),
							children: [
								"1",
								"2",
								"3",
								"4",
								"6"
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: n,
								children: n === "1" ? "1 — full" : n
							}, n))
						})
					]
				})
			]
		});
	}
	if (state.tab === "auger") {
		const f = state.auger;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AugerSketch, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: "Outside diameter and shaft hole are the finished flight. Thickness is weight only."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Outside diameter",
							suffix: unit,
							value: f.od,
							onChange: (od) => setTab("auger", { od })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Shaft hole",
							suffix: unit,
							value: f.id,
							onChange: (id) => setTab("auger", { id })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pitch",
							suffix: unit,
							value: f.pitch,
							hint: "Advance in one turn.",
							onChange: (pitch) => setTab("auger", { pitch })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Thickness",
							suffix: unit,
							value: f.thickness,
							onChange: (thickness) => setTab("auger", { thickness })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Flights to cut",
								value: f.flights,
								onChange: (flights) => setTab("auger", { flights })
							})
						})
					]
				})
			]
		});
	}
	if (state.tab === "transition") {
		const f = state.transition;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransitionSketch, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasisField, {
					value: f.basis,
					onChange: (basis) => setTab("transition", { basis })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
					label: rectangularBase(f.length, f.width) ? "Half seam through" : "Piece",
					value: rectangularBase(f.length, f.width) && f.part === "quarter" ? "half" : f.part,
					onChange: (part) => setTab("transition", { part }),
					options: rectangularBase(f.length, f.width) ? [
						{
							value: "half",
							label: "Lengths"
						},
						{
							value: "half-cross",
							label: "Widths"
						},
						{
							value: "full",
							label: "One piece"
						}
					] : [
						{
							value: "quarter",
							label: "Quarter"
						},
						{
							value: "half",
							label: "Half"
						},
						{
							value: "full",
							label: "Full"
						}
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-snug text-mist",
					children: rectangularBase(f.length, f.width) ? "Two identical halves. The seam runs through the middle of the sides you pick. One piece is the whole fitting." : "Equal sides are a square. Quarter and half patterns are cut on the side centers."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Base length",
							suffix: unit,
							value: f.length,
							onChange: (length) => setTab("transition", {
								length,
								...rectangularBase(length, f.width) && f.part === "quarter" ? { part: "half" } : {}
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Base width",
							suffix: unit,
							value: f.width,
							hint: "Match the length for a square.",
							onChange: (width) => setTab("transition", {
								width,
								...rectangularBase(f.length, width) && f.part === "quarter" ? { part: "half" } : {}
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Round diameter",
							suffix: unit,
							value: f.round,
							onChange: (round) => setTab("transition", { round })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Vertical height",
							suffix: unit,
							value: f.height,
							onChange: (height) => setTab("transition", { height })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Thickness",
							suffix: unit,
							value: f.thickness,
							onChange: (thickness) => setTab("transition", { thickness })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Arc steps per quarter",
							value: f.segments,
							onChange: (segments) => setTab("transition", { segments }),
							children: [
								"6",
								"8",
								"12",
								"16",
								"24"
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: n,
								children: n
							}, n))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-start gap-3 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-1 size-4 accent-brass",
						checked: f.folds,
						onChange: (event) => setTab("transition", { folds: event.target.checked })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Include layout lines in the export. On a DXF they sit on layer FOLD — leave that layer off the cutter." })]
				})
			]
		});
	}
	const f = state.elbow;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ElbowSketch, {
				angle: readNumber(f.angle) ?? 90,
				gores: readNumber(f.gores) ?? 5,
				clr: readNumber(f.clr) ?? 1,
				radius: (readNumber(f.diameter) ?? 1) / 2
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BasisField, {
				value: f.basis,
				onChange: (basis) => setTab("elbow", { basis })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
				label: "Long seam",
				value: f.seam,
				onChange: (seam) => setTab("elbow", { seam }),
				options: [
					{
						value: "throat",
						label: "Throat"
					},
					{
						value: "cheek",
						label: "Cheek"
					},
					{
						value: "back",
						label: "Back"
					}
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pipe diameter",
						suffix: unit,
						value: f.diameter,
						onChange: (diameter) => setTab("elbow", { diameter })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Centerline radius",
						suffix: unit,
						value: f.clr,
						onChange: (clr) => setTab("elbow", { clr })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bend angle",
						suffix: "°",
						value: f.angle,
						onChange: (angle) => setTab("elbow", { angle })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						label: "Gores",
						value: f.gores,
						onChange: (gores) => setTab("elbow", { gores }),
						children: [
							"2",
							"3",
							"4",
							"5",
							"6",
							"7",
							"8"
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: n,
							children: n
						}, n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Thickness",
						suffix: unit,
						value: f.thickness,
						onChange: (thickness) => setTab("elbow", { thickness })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Seam allowance",
						suffix: unit,
						value: f.allowance,
						hint: "Lap along the long seam.",
						onChange: (allowance) => setTab("elbow", { allowance })
					})
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatternShop, {});
}
//#endregion
export { Home as component };
