//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-JF2Hk5pP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D5ZMhmCC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D5ZMhmCC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BNpShORp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
